import { createClient } from '@supabase/supabase-js';


// Initialize database client
const supabaseUrl = 'https://fqxozrwhabwgxacvzgky.databasepad.com';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImE3MTdlYjYyLThiMjgtNDZmMC04ZGVhLWEyZDJkY2U2ODNlNyJ9.eyJwcm9qZWN0SWQiOiJmcXhvenJ3aGFid2d4YWN2emdreSIsInJvbGUiOiJhbm9uIiwiaWF0IjoxNzY2NjQ5NDMzLCJleHAiOjIwODIwMDk0MzMsImlzcyI6ImZhbW91cy5kYXRhYmFzZXBhZCIsImF1ZCI6ImZhbW91cy5jbGllbnRzIn0.Ob1GB66sDDKuR1C8bt_eTcXKjYcI--pjpY9p2RfuI_s';
const supabase = createClient(supabaseUrl, supabaseKey);


export { supabase };