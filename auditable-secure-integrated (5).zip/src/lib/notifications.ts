// Notification sound utility for Work.PWA
// Plays sounds for various actions across all roles

type NotificationSound = 'success' | 'warning' | 'error' | 'message' | 'task' | 'handover' | 'approval';

// Audio context for generating sounds
let audioContext: AudioContext | null = null;

const getAudioContext = (): AudioContext => {
  if (!audioContext) {
    audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
  }
  return audioContext;
};

// Generate different tones for different notification types
const soundConfigs: Record<NotificationSound, { frequency: number; duration: number; type: OscillatorType; volume: number }> = {
  success: { frequency: 880, duration: 0.15, type: 'sine', volume: 0.3 },
  warning: { frequency: 440, duration: 0.3, type: 'triangle', volume: 0.4 },
  error: { frequency: 220, duration: 0.4, type: 'sawtooth', volume: 0.3 },
  message: { frequency: 660, duration: 0.1, type: 'sine', volume: 0.25 },
  task: { frequency: 523, duration: 0.2, type: 'sine', volume: 0.35 },
  handover: { frequency: 784, duration: 0.25, type: 'sine', volume: 0.3 },
  approval: { frequency: 1047, duration: 0.15, type: 'sine', volume: 0.3 },
};

export const playNotificationSound = (type: NotificationSound = 'success'): void => {
  try {
    const ctx = getAudioContext();
    const config = soundConfigs[type];
    
    const oscillator = ctx.createOscillator();
    const gainNode = ctx.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(ctx.destination);
    
    oscillator.frequency.value = config.frequency;
    oscillator.type = config.type;
    
    gainNode.gain.setValueAtTime(config.volume, ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + config.duration);
    
    oscillator.start(ctx.currentTime);
    oscillator.stop(ctx.currentTime + config.duration);
    
    // For success, play a second higher note
    if (type === 'success' || type === 'approval') {
      setTimeout(() => {
        const osc2 = ctx.createOscillator();
        const gain2 = ctx.createGain();
        osc2.connect(gain2);
        gain2.connect(ctx.destination);
        osc2.frequency.value = config.frequency * 1.5;
        osc2.type = config.type;
        gain2.gain.setValueAtTime(config.volume, ctx.currentTime);
        gain2.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + config.duration);
        osc2.start(ctx.currentTime);
        osc2.stop(ctx.currentTime + config.duration);
      }, 100);
    }
  } catch (e) {
    console.log('Sound notification not available');
  }
};

// Play double beep for urgent notifications
export const playUrgentSound = (): void => {
  playNotificationSound('warning');
  setTimeout(() => playNotificationSound('warning'), 200);
  setTimeout(() => playNotificationSound('warning'), 400);
};

// Play success chime
export const playSuccessChime = (): void => {
  playNotificationSound('success');
};

// Play error sound
export const playErrorSound = (): void => {
  playNotificationSound('error');
};

// Play message received sound
export const playMessageSound = (): void => {
  playNotificationSound('message');
};

// Play task assigned sound
export const playTaskSound = (): void => {
  playNotificationSound('task');
};

// Play handover confirmation sound
export const playHandoverSound = (): void => {
  playNotificationSound('handover');
};

// Play approval sound
export const playApprovalSound = (): void => {
  playNotificationSound('approval');
};
