import { createRoot } from 'react-dom/client'
import App from './App.tsx'
import './index.css'

// Register Service Worker for PWA
if ('serviceWorker' in navigator) {
  window.addEventListener('load', async () => {
    try {
      const registration = await navigator.serviceWorker.register('/sw.js', {
        scope: '/'
      });
      
      console.log('[PWA] Service Worker registered:', registration.scope);
      
      // Check for updates
      registration.addEventListener('updatefound', () => {
        const newWorker = registration.installing;
        if (newWorker) {
          console.log('[PWA] New service worker installing...');
          
          newWorker.addEventListener('statechange', () => {
            if (newWorker.state === 'installed') {
              if (navigator.serviceWorker.controller) {
                // New content available
                console.log('[PWA] New content available, please refresh.');
                
                // Show update notification if supported
                if ('Notification' in window && Notification.permission === 'granted') {
                  registration.showNotification('Work.PWA Update', {
                    body: 'A new version is available. Refresh to update.',
                    icon: 'https://d64gsuwffb70l.cloudfront.net/694cee408ac262bea54de0c6_1766675329513_101a7961.jpg',
                    tag: 'update-notification',
                  });
                }
              } else {
                // Content cached for offline use
                console.log('[PWA] Content cached for offline use.');
              }
            }
          });
        }
      });

      // Handle controller change (when new SW takes over)
      navigator.serviceWorker.addEventListener('controllerchange', () => {
        console.log('[PWA] Controller changed, reloading...');
        // Optionally reload the page when new SW takes control
        // window.location.reload();
      });

    } catch (error) {
      console.error('[PWA] Service Worker registration failed:', error);
    }
  });
}

// Store the install prompt for later use
let deferredPrompt: any = null;

window.addEventListener('beforeinstallprompt', (e) => {
  console.log('[PWA] beforeinstallprompt event fired');
  e.preventDefault();
  deferredPrompt = e;
  (window as any).deferredPrompt = e;
});

window.addEventListener('appinstalled', () => {
  console.log('[PWA] App was installed');
  deferredPrompt = null;
  (window as any).deferredPrompt = null;
});

// Check if running as installed PWA
const isStandalone = window.matchMedia('(display-mode: standalone)').matches ||
  (window.navigator as any).standalone === true;

if (isStandalone) {
  console.log('[PWA] Running as installed PWA');
}

createRoot(document.getElementById("root")!).render(<App />);
