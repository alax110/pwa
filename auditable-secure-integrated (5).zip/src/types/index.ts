export type UserRole = 'admin' | 'branch_sales' | 'inventory' | 'cashier' | 'accounts' | 'noc' | 'engineer';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  branch_id?: string;
  phone?: string;
  area?: string;
  is_active: boolean;
  created_at: string;
}

export interface Branch {
  id: string;
  name: string;
  location?: string;
  is_active: boolean;
  created_at: string;
}

export interface Shopkeeper {
  id: string;
  name: string;
  phone?: string;
  balance: number;
  branch_id: string;
  created_by: string;
  is_active: boolean;
  created_at: string;
}

export interface Partner {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  revenue_share_percent: number;
  total_earnings: number;
  withdrawn: number;
  is_active: boolean;
  created_at: string;
}

export interface InventoryItem {
  id: string;
  name: string;
  sku?: string;
  category: string;
  unit_price: number;
  description?: string;
  is_active: boolean;
  created_at: string;
}

export interface Stock {
  id: string;
  item_id: string;
  branch_id: string;
  quantity: number;
  min_quantity: number;
  updated_at: string;
  item?: InventoryItem;
  branch?: Branch;
}

export interface Sale {
  id: string;
  sale_number: string;
  customer_name: string;
  customer_phone?: string;
  customer_address?: string;
  branch_id: string;
  created_by: string;
  shopkeeper_id?: string;
  amount: number;
  tax_amount: number;
  dev_amount: number;
  revenue_amount: number;
  is_paid: boolean;
  paid_at?: string;
  payment_method?: string;
  notes?: string;
  created_at: string;
  branch?: Branch;
  shopkeeper?: Shopkeeper;
}

export interface Task {
  id: string;
  task_number: string;
  task_type: 'installation' | 'complaint' | 'maintenance';
  title: string;
  description?: string;
  branch_id: string;
  sale_id?: string;
  assigned_to?: string;
  assigned_by: string;
  status: 'pending' | 'in_progress' | 'completed' | 'cancelled';
  priority: 'low' | 'normal' | 'high' | 'urgent';
  due_date?: string;
  deadline_hours?: number;
  completed_at?: string;
  notes?: string;
  created_at: string;
  branch?: Branch;
  assignee?: User;
}

export interface Complaint {
  id: string;
  complaint_number: string;
  customer_name: string;
  customer_phone?: string;
  customer_address?: string;
  branch_id: string;
  category: string;
  description: string;
  status: 'open' | 'assigned' | 'in_progress' | 'resolved' | 'closed';
  assigned_to?: string;
  priority: 'low' | 'normal' | 'high' | 'urgent';
  deadline_hours?: number;
  resolved_at?: string;
  created_by: string;
  created_at: string;
  branch?: Branch;
  assignee?: User;
}

export interface CashHandover {
  id: string;
  handover_number: string;
  branch_id: string;
  handed_by: string;
  received_by?: string;
  total_payable: number;
  amount: number;
  remaining_balance: number;
  status: 'pending' | 'confirmed' | 'discrepancy';
  confirmed_at?: string;
  notes?: string;
  created_at: string;
  branch?: Branch;
}

export interface PurchaseOrder {
  id: string;
  po_number: string;
  requested_by: string;
  branch_id?: string;
  status: 'pending' | 'approved' | 'rejected' | 'received';
  total_amount: number;
  approved_by?: string;
  approved_at?: string;
  notes?: string;
  items?: PurchaseOrderItem[];
  created_at: string;
}

export interface PurchaseOrderItem {
  id: string;
  po_id: string;
  item_id: string;
  quantity: number;
  unit_price: number;
  item?: InventoryItem;
}

export interface PenaltyRule {
  id: string;
  code: string;
  name: string;
  description?: string;
  amount: number;
  is_percentage: boolean;
  applies_to: UserRole[];
  is_active: boolean;
  created_at: string;
}

export interface BonusRule {
  id: string;
  code: string;
  name: string;
  description?: string;
  amount: number;
  is_percentage: boolean;
  applies_to: UserRole[];
  is_active: boolean;
  created_at: string;
}

export interface Penalty {
  id: string;
  user_id: string;
  rule_id: string;
  amount: number;
  reason: string;
  applied_by: string;
  task_id?: string;
  complaint_id?: string;
  created_at: string;
  user?: User;
  rule?: PenaltyRule;
}

export interface Bonus {
  id: string;
  user_id: string;
  rule_id: string;
  amount: number;
  reason: string;
  applied_by: string;
  created_at: string;
  user?: User;
  rule?: BonusRule;
}

export interface AuditLog {
  id: string;
  user_id: string;
  action: string;
  entity_type: string;
  entity_id?: string;
  old_data?: any;
  new_data?: any;
  ip_address?: string;
  created_at: string;
  user?: User;
}

export interface BudgetBucket {
  id: string;
  name: 'TAX' | 'DEV' | 'REVENUE';
  percentage: number;
  current_balance: number;
  created_at: string;
}

export interface Attendance {
  id: string;
  user_id: string;
  date: string;
  check_in: string;
  check_out?: string;
  status: 'present' | 'late' | 'absent';
  notes?: string;
  created_at: string;
  user?: User;
}

export interface Message {
  id: string;
  from_user_id: string;
  to_user_id?: string;
  to_role?: UserRole;
  message_type: 'text' | 'voice' | 'file';
  content: string;
  file_url?: string;
  is_read: boolean;
  created_at: string;
  from_user?: User;
  to_user?: User;
}

export interface Report {
  id: string;
  reported_by: string;
  reported_user_id: string;
  category: string;
  description: string;
  status: 'pending' | 'reviewed' | 'resolved' | 'dismissed';
  reviewed_by?: string;
  reviewed_at?: string;
  notes?: string;
  created_at: string;
  reporter?: User;
  reported_user?: User;
}

export interface StockRequest {
  id: string;
  requested_by: string;
  item_id: string;
  quantity: number;
  reason: string;
  status: 'pending' | 'approved' | 'rejected';
  approved_by?: string;
  approved_at?: string;
  created_at: string;
  item?: InventoryItem;
}
