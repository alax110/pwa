import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, UserRole } from '@/types';
import { supabase } from '@/lib/supabase';

interface AuthContextType {
  currentUser: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  hasRole: (roles: UserRole[]) => boolean;
  systemReset: () => Promise<{ success: boolean; error?: string }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const initializeAuth = async () => {
      // First, ensure admin is initialized with correct password
      try {
        await supabase.functions.invoke('auth', {
          body: { action: 'init_admin' }
        });
      } catch (e) {
        console.log('Admin init skipped');
      }

      // Then validate existing session
      const sessionToken = localStorage.getItem('workpwa_session');
      const savedUser = localStorage.getItem('workpwa_user');
      
      if (sessionToken && savedUser) {
        try {
          const { data } = await supabase.functions.invoke('auth', {
            body: { action: 'validate', session_token: sessionToken }
          });
          
          if (data?.success && data?.user) {
            setCurrentUser(data.user);
          } else {
            localStorage.removeItem('workpwa_session');
            localStorage.removeItem('workpwa_user');
          }
        } catch {
          // If validation fails, try using saved user
          try {
            setCurrentUser(JSON.parse(savedUser));
          } catch {
            localStorage.removeItem('workpwa_session');
            localStorage.removeItem('workpwa_user');
          }
        }
      }
      setLoading(false);
    };
    
    initializeAuth();
  }, []);

  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const { data, error } = await supabase.functions.invoke('auth', {
        body: { action: 'login', email, password }
      });

      if (error) {
        return { success: false, error: 'Connection error. Please try again.' };
      }

      if (data?.success && data?.user) {
        setCurrentUser(data.user);
        localStorage.setItem('workpwa_user', JSON.stringify(data.user));
        if (data.session_token) {
          localStorage.setItem('workpwa_session', data.session_token);
        }
        return { success: true };
      }

      return { success: false, error: data?.error || 'Login failed' };
    } catch (err) {
      console.error('Login error:', err);
      return { success: false, error: 'Connection error. Please try again.' };
    }
  };

  const logout = async () => {
    const sessionToken = localStorage.getItem('workpwa_session');
    
    if (sessionToken) {
      try {
        await supabase.functions.invoke('auth', {
          body: { action: 'logout', session_token: sessionToken }
        });
      } catch {
        // Ignore logout errors
      }
    }
    
    setCurrentUser(null);
    localStorage.removeItem('workpwa_user');
    localStorage.removeItem('workpwa_session');
  };

  const hasRole = (roles: UserRole[]): boolean => {
    if (!currentUser) return false;
    return roles.includes(currentUser.role);
  };

  const systemReset = async (): Promise<{ success: boolean; error?: string }> => {
    const sessionToken = localStorage.getItem('workpwa_session');
    
    if (!sessionToken) {
      return { success: false, error: 'Not authenticated' };
    }

    try {
      const { data, error } = await supabase.functions.invoke('auth', {
        body: { action: 'system_reset', session_token: sessionToken }
      });

      if (error) {
        return { success: false, error: 'Connection error' };
      }

      if (data?.success) {
        return { success: true };
      }

      return { success: false, error: data?.error || 'Reset failed' };
    } catch (err) {
      console.error('System reset error:', err);
      return { success: false, error: 'Connection error' };
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-cyan-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <div className="text-cyan-400">Loading Work.PWA...</div>
        </div>
      </div>
    );
  }

  return (
    <AuthContext.Provider value={{
      currentUser,
      isAuthenticated: !!currentUser,
      login,
      logout,
      hasRole,
      systemReset
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
