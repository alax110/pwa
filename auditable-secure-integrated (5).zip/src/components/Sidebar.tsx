import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { UserRole } from '@/types';
import {
  DashboardIcon, UsersIcon, MoneyIcon, InventoryIcon, TaskIcon,
  SalesIcon, BranchIcon, SettingsIcon, AuditIcon, PartnerIcon,
  ComplaintIcon, CashIcon, LogoutIcon, ShopIcon, NetworkIcon, MessageIcon
} from './ui/Icons';

const LOGO_URL = 'https://d64gsuwffb70l.cloudfront.net/694cee408ac262bea54de0c6_1766675329513_101a7961.jpg';

interface NavItem {
  id: string;
  label: string;
  icon: React.FC<{ className?: string; size?: number }>;
  roles: UserRole[];
}

const navItems: NavItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: DashboardIcon, roles: ['admin', 'branch_sales', 'inventory', 'cashier', 'accounts', 'noc', 'engineer'] },
  { id: 'messages', label: 'Messages', icon: MessageIcon, roles: ['admin', 'branch_sales', 'inventory', 'cashier', 'accounts', 'noc', 'engineer'] },
  { id: 'users', label: 'Users', icon: UsersIcon, roles: ['admin'] },
  { id: 'branches', label: 'Branches', icon: BranchIcon, roles: ['admin'] },
  { id: 'partners', label: 'Partners', icon: PartnerIcon, roles: ['admin', 'accounts'] },
  { id: 'rules', label: 'Penalty/Bonus Rules', icon: SettingsIcon, roles: ['admin'] },
  { id: 'sales', label: 'Sales', icon: SalesIcon, roles: ['admin', 'accounts'] },
  { id: 'shopkeepers', label: 'Shopkeepers', icon: ShopIcon, roles: ['branch_sales'] },
  { id: 'inventory', label: 'Inventory', icon: InventoryIcon, roles: ['admin', 'inventory'] },
  { id: 'stock', label: 'Stock Ledger', icon: InventoryIcon, roles: ['admin', 'inventory'] },
  { id: 'cashier', label: 'Cash Handover', icon: CashIcon, roles: ['cashier', 'branch_sales'] },
  { id: 'accounts', label: 'Accounts', icon: MoneyIcon, roles: ['accounts', 'admin'] },
  { id: 'complaints', label: 'Complaints', icon: ComplaintIcon, roles: ['noc', 'admin'] },
  { id: 'tasks', label: 'Tasks', icon: TaskIcon, roles: ['noc', 'engineer', 'branch_sales', 'admin'] },
  { id: 'audit', label: 'Audit Log', icon: AuditIcon, roles: ['admin'] },
];

interface SidebarProps {
  activeView: string;
  onViewChange: (view: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeView, onViewChange, isOpen, onClose }) => {
  const { currentUser, logout, hasRole } = useAuth();

  const filteredNavItems = navItems.filter(item => 
    currentUser && item.roles.includes(currentUser.role)
  );

  const getRoleBadgeColor = (role: UserRole) => {
    const colors: Record<UserRole, string> = {
      admin: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
      branch_sales: 'bg-green-500/20 text-green-400 border-green-500/30',
      inventory: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
      cashier: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
      accounts: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
      noc: 'bg-red-500/20 text-red-400 border-red-500/30',
      engineer: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
    };
    return colors[role] || colors.admin;
  };

  const formatRole = (role: UserRole) => {
    const labels: Record<UserRole, string> = {
      admin: 'Admin',
      branch_sales: 'Branch Sales',
      inventory: 'Inventory',
      cashier: 'Cashier',
      accounts: 'Accounts',
      noc: 'NOC',
      engineer: 'Engineer',
    };
    return labels[role] || 'User';
  };

  const getUserInitial = () => {
    if (currentUser?.name && typeof currentUser.name === 'string' && currentUser.name.length > 0) {
      return currentUser.name.charAt(0).toUpperCase();
    }
    return 'U';
  };

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <aside className={`
        fixed lg:static inset-y-0 left-0 z-50
        w-64 bg-slate-900 border-r border-slate-800
        transform transition-transform duration-300 ease-in-out
        ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        flex flex-col
      `}>
        {/* Logo */}
        <div className="p-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <img src={LOGO_URL} alt="Work.PWA" className="w-10 h-10 rounded-xl object-cover" />
            <div>
              <h1 className="text-lg font-bold text-white">Work.PWA</h1>
              <p className="text-xs text-slate-500">ISP Operations</p>
            </div>
          </div>
        </div>

        {/* User Info */}
        <div className="p-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center text-white font-bold">
              {getUserInitial()}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-white truncate">{currentUser?.name || 'User'}</p>
              <span className={`inline-block px-2 py-0.5 text-xs rounded-full border ${getRoleBadgeColor(currentUser?.role || 'admin')}`}>
                {formatRole(currentUser?.role || 'admin')}
              </span>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto p-3 space-y-1">
          {filteredNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onViewChange(item.id);
                  onClose();
                }}
                className={`
                  w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-all
                  ${isActive 
                    ? 'bg-gradient-to-r from-cyan-500/20 to-blue-600/20 text-cyan-400 border border-cyan-500/30' 
                    : 'text-slate-400 hover:bg-slate-800 hover:text-white'}
                `}
              >
                <Icon size={20} className={isActive ? 'text-cyan-400' : ''} />
                <span className="text-sm font-medium">{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Logout */}
        <div className="p-3 border-t border-slate-800">
          <button
            onClick={logout}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-400 hover:bg-red-500/10 hover:text-red-400 transition-all"
          >
            <LogoutIcon size={20} />
            <span className="text-sm font-medium">Sign Out</span>
          </button>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
