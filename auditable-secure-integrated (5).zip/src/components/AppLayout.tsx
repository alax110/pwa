import React from 'react';
import { AuthProvider, useAuth } from '@/contexts/AuthContext';
import LoginScreen from './LoginScreen';
import Dashboard from './Dashboard';

const AppContent: React.FC = () => {
  const { isAuthenticated } = useAuth();

  if (!isAuthenticated) {
    return <LoginScreen />;
  }

  return <Dashboard />;
};

const AppLayout: React.FC = () => {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
};

export default AppLayout;
