import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import Sidebar from './Sidebar';
import Header from './Header';
import AdminDashboard from './views/AdminDashboard';
import BranchSalesDashboard from './views/BranchSalesDashboard';
import CashierDashboard from './views/CashierDashboard';
import InventoryDashboard from './views/InventoryDashboard';
import NOCDashboard from './views/NOCDashboard';
import EngineerDashboard from './views/EngineerDashboard';
import AccountsDashboard from './views/AccountsDashboard';
import UsersView from './views/UsersView';
import BranchesView from './views/BranchesView';
import PartnersView from './views/PartnersView';
import RulesView from './views/RulesView';
import SalesView from './views/SalesView';
import ShopkeepersView from './views/ShopkeepersView';
import InventoryView from './views/InventoryView';
import StockLedgerView from './views/StockLedgerView';
import CashierView from './views/CashierView';
import AccountsView from './views/AccountsView';
import ComplaintsView from './views/ComplaintsView';
import TasksView from './views/TasksView';
import AuditLogView from './views/AuditLogView';
import MessagingView from './views/MessagingView';

const Dashboard: React.FC = () => {
  const { currentUser } = useAuth();
  const [activeView, setActiveView] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const getViewTitle = () => {
    const titles: Record<string, string> = {
      dashboard: 'Dashboard',
      users: 'Users Management',
      branches: 'Branches',
      partners: 'Partners',
      rules: 'Penalty/Bonus Rules',
      sales: 'Sales',
      shopkeepers: 'Shopkeepers',
      inventory: 'Inventory',
      stock: 'Stock Ledger',
      cashier: 'Cash Handover',
      accounts: 'Accounts',
      complaints: 'Complaints',
      tasks: 'Tasks',
      audit: 'Audit Log',
      messages: 'Messages',
    };
    return titles[activeView] || 'Dashboard';
  };

  const getRoleDashboard = () => {
    switch (currentUser?.role) {
      case 'admin':
        return <AdminDashboard />;
      case 'branch_sales':
        return <BranchSalesDashboard />;
      case 'cashier':
        return <CashierDashboard />;
      case 'inventory':
        return <InventoryDashboard />;
      case 'noc':
        return <NOCDashboard />;
      case 'engineer':
        return <EngineerDashboard />;
      case 'accounts':
        return <AccountsDashboard />;
      default:
        return <AdminDashboard />;
    }
  };

  const renderView = () => {
    switch (activeView) {
      case 'dashboard':
        return getRoleDashboard();
      case 'users':
        return <UsersView />;
      case 'branches':
        return <BranchesView />;
      case 'partners':
        return <PartnersView />;
      case 'rules':
        return <RulesView />;
      case 'sales':
        return <SalesView />;
      case 'shopkeepers':
        return <ShopkeepersView />;
      case 'inventory':
        return <InventoryView />;
      case 'stock':
        return <StockLedgerView />;
      case 'cashier':
        return <CashierView />;
      case 'accounts':
        return <AccountsView />;
      case 'complaints':
        return <ComplaintsView />;
      case 'tasks':
        return <TasksView />;
      case 'audit':
        return <AuditLogView />;
      case 'messages':
        return <MessagingView />;
      default:
        return getRoleDashboard();
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex">
      <Sidebar
        activeView={activeView}
        onViewChange={setActiveView}
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />
      
      <div className="flex-1 flex flex-col min-h-screen">
        <Header
          title={getViewTitle()}
          onMenuClick={() => setSidebarOpen(true)}
        />
        
        <main className="flex-1 p-4 lg:p-6 overflow-auto">
          {renderView()}
        </main>
      </div>
    </div>
  );
};

export default Dashboard;
