import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Branch, Sale, User } from '@/types';
import DataTable from '../DataTable';
import Modal from '../Modal';
import StatCard from '../StatCard';
import { PlusIcon, BranchIcon, EditIcon, MoneyIcon, UsersIcon } from '../ui/Icons';

const BranchesView: React.FC = () => {
  const [branches, setBranches] = useState<Branch[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBranch, setEditingBranch] = useState<Branch | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    location: '',
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [branchesRes, salesRes, usersRes] = await Promise.all([
        supabase.from('branches').select('*').order('name'),
        supabase.from('sales').select('*'),
        supabase.from('users').select('*'),
      ]);
      setBranches(branchesRes.data || []);
      setSales(salesRes.data || []);
      setUsers(usersRes.data || []);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingBranch) {
        await supabase.from('branches').update(formData).eq('id', editingBranch.id);
      } else {
        await supabase.from('branches').insert(formData);
      }
      setIsModalOpen(false);
      setEditingBranch(null);
      resetForm();
      fetchData();
    } catch (error) {
      console.error('Error saving branch:', error);
    }
  };

  const handleEdit = (branch: Branch) => {
    setEditingBranch(branch);
    setFormData({
      name: branch.name,
      location: branch.location || '',
    });
    setIsModalOpen(true);
  };

  const resetForm = () => {
    setFormData({ name: '', location: '' });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US').format(amount) + ' AFN';
  };

  const getBranchStats = (branchId: string) => {
    const branchSales = sales.filter(s => s.branch_id === branchId);
    const totalSales = branchSales.reduce((sum, s) => sum + parseFloat(String(s.amount)), 0);
    const paidSales = branchSales.filter(s => s.is_paid).reduce((sum, s) => sum + parseFloat(String(s.amount)), 0);
    const unpaidSales = branchSales.filter(s => !s.is_paid).reduce((sum, s) => sum + parseFloat(String(s.amount)), 0);
    const staffCount = users.filter(u => u.branch_id === branchId).length;
    return { totalSales, paidSales, unpaidSales, salesCount: branchSales.length, staffCount };
  };

  const totalRevenue = sales.reduce((sum, s) => sum + parseFloat(String(s.amount)), 0);

  const columns = [
    { key: 'name', label: 'Branch Name' },
    { key: 'location', label: 'Location' },
    { 
      key: 'staff', 
      label: 'Staff',
      render: (item: Branch) => getBranchStats(item.id).staffCount
    },
    { 
      key: 'sales', 
      label: 'Total Sales',
      render: (item: Branch) => formatCurrency(getBranchStats(item.id).totalSales)
    },
    { 
      key: 'collected', 
      label: 'Collected',
      render: (item: Branch) => (
        <span className="text-green-400">{formatCurrency(getBranchStats(item.id).paidSales)}</span>
      )
    },
    { 
      key: 'pending', 
      label: 'Pending',
      render: (item: Branch) => (
        <span className="text-orange-400">{formatCurrency(getBranchStats(item.id).unpaidSales)}</span>
      )
    },
    {
      key: 'actions',
      label: 'Actions',
      render: (item: Branch) => (
        <button
          onClick={(e) => { e.stopPropagation(); handleEdit(item); }}
          className="p-1.5 text-slate-400 hover:text-cyan-400 hover:bg-slate-700 rounded-lg transition-all"
        >
          <EditIcon size={16} />
        </button>
      )
    },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatCard
          title="Total Branches"
          value={branches.length}
          icon={<BranchIcon size={24} />}
          color="cyan"
        />
        <StatCard
          title="Total Staff"
          value={users.filter(u => u.branch_id).length}
          icon={<UsersIcon size={24} />}
          color="purple"
        />
        <StatCard
          title="Total Revenue"
          value={formatCurrency(totalRevenue)}
          icon={<MoneyIcon size={24} />}
          color="green"
        />
      </div>

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white">Branches</h2>
          <p className="text-sm text-slate-400">Manage company branches and locations</p>
        </div>
        <button
          onClick={() => { resetForm(); setEditingBranch(null); setIsModalOpen(true); }}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium rounded-xl hover:from-cyan-600 hover:to-blue-700 transition-all"
        >
          <PlusIcon size={20} />
          Add Branch
        </button>
      </div>

      {/* Branch Performance Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {branches.map(branch => {
          const stats = getBranchStats(branch.id);
          const collectionRate = stats.totalSales > 0 ? (stats.paidSales / stats.totalSales) * 100 : 0;
          return (
            <div key={branch.id} className="bg-slate-800/50 border border-slate-700 rounded-2xl p-5">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="font-semibold text-white">{branch.name}</h3>
                  <p className="text-sm text-slate-400">{branch.location}</p>
                </div>
                <div className="p-2 bg-cyan-500/20 rounded-xl">
                  <BranchIcon size={20} className="text-cyan-400" />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <p className="text-xs text-slate-500">Total Sales</p>
                  <p className="text-lg font-bold text-white">{formatCurrency(stats.totalSales)}</p>
                </div>
                <div>
                  <p className="text-xs text-slate-500">Staff</p>
                  <p className="text-lg font-bold text-white">{stats.staffCount}</p>
                </div>
              </div>
              
              <div className="mb-3">
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-400">Collection Rate</span>
                  <span className={collectionRate >= 80 ? 'text-green-400' : collectionRate >= 50 ? 'text-yellow-400' : 'text-red-400'}>
                    {collectionRate.toFixed(1)}%
                  </span>
                </div>
                <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                  <div 
                    className={`h-full rounded-full ${
                      collectionRate >= 80 ? 'bg-green-500' : collectionRate >= 50 ? 'bg-yellow-500' : 'bg-red-500'
                    }`}
                    style={{ width: `${collectionRate}%` }}
                  />
                </div>
              </div>
              
              <div className="flex justify-between text-sm">
                <span className="text-green-400">Collected: {formatCurrency(stats.paidSales)}</span>
                <span className="text-orange-400">Pending: {formatCurrency(stats.unpaidSales)}</span>
              </div>
            </div>
          );
        })}
      </div>

      <DataTable
        columns={columns}
        data={branches}
        searchable
        searchPlaceholder="Search branches..."
        emptyMessage="No branches found"
      />

      {/* Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => { setIsModalOpen(false); setEditingBranch(null); }}
        title={editingBranch ? 'Edit Branch' : 'Add New Branch'}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Branch Name *</label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              required
              placeholder="e.g., Main Branch - Kabul"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Location</label>
            <input
              type="text"
              value={formData.location}
              onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              placeholder="e.g., Kabul City Center"
            />
          </div>
          
          <div className="flex justify-end gap-3 pt-4">
            <button
              type="button"
              onClick={() => { setIsModalOpen(false); setEditingBranch(null); }}
              className="px-4 py-2 text-slate-400 hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium rounded-xl hover:from-cyan-600 hover:to-blue-700 transition-all"
            >
              {editingBranch ? 'Update' : 'Create'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default BranchesView;
