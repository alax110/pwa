import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Shopkeeper, Sale } from '@/types';
import DataTable from '../DataTable';
import Modal from '../Modal';
import StatCard from '../StatCard';
import { PlusIcon, ShopIcon, MoneyIcon, AlertIcon, PrintIcon } from '../ui/Icons';

const ShopkeepersView: React.FC = () => {
  const { currentUser } = useAuth();
  const [shopkeepers, setShopkeepers] = useState<Shopkeeper[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      let shopkeepersQuery = supabase.from('shopkeepers').select('*').order('name');
      
      if (currentUser?.branch_id) {
        shopkeepersQuery = shopkeepersQuery.eq('branch_id', currentUser.branch_id);
      }

      const [shopkeepersRes, salesRes] = await Promise.all([
        shopkeepersQuery,
        supabase.from('sales').select('*'),
      ]);

      setShopkeepers(shopkeepersRes.data || []);
      setSales(salesRes.data || []);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await supabase.from('shopkeepers').insert({
        name: formData.name,
        phone: formData.phone,
        balance: 0,
        branch_id: currentUser?.branch_id,
        created_by: currentUser?.id,
      });

      setIsModalOpen(false);
      resetForm();
      fetchData();
    } catch (error) {
      console.error('Error creating shopkeeper:', error);
    }
  };

  const resetForm = () => {
    setFormData({ name: '', phone: '' });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US').format(amount) + ' AFN';
  };

  const getShopkeeperStats = (shopkeeperId: string) => {
    const skSales = sales.filter(s => s.shopkeeper_id === shopkeeperId);
    const totalSales = skSales.reduce((sum, s) => sum + parseFloat(String(s.amount)), 0);
    const paidSales = skSales.filter(s => s.is_paid).reduce((sum, s) => sum + parseFloat(String(s.amount)), 0);
    const unpaidSales = skSales.filter(s => !s.is_paid).reduce((sum, s) => sum + parseFloat(String(s.amount)), 0);
    return { totalSales, paidSales, unpaidSales, count: skSales.length };
  };

  const totalOwed = shopkeepers.reduce((sum, sk) => {
    return sum + getShopkeeperStats(sk.id).unpaidSales;
  }, 0);

  const columns = [
    { key: 'name', label: 'Shopkeeper Name' },
    { key: 'phone', label: 'Phone' },
    { 
      key: 'total_sales', 
      label: 'Total Sales',
      render: (item: Shopkeeper) => formatCurrency(getShopkeeperStats(item.id).totalSales)
    },
    { 
      key: 'collected', 
      label: 'Collected',
      render: (item: Shopkeeper) => (
        <span className="text-green-400">{formatCurrency(getShopkeeperStats(item.id).paidSales)}</span>
      )
    },
    { 
      key: 'owed', 
      label: 'Owed',
      render: (item: Shopkeeper) => {
        const owed = getShopkeeperStats(item.id).unpaidSales;
        return (
          <span className={owed > 0 ? 'text-orange-400 font-medium' : 'text-slate-400'}>
            {formatCurrency(owed)}
          </span>
        );
      }
    },
    {
      key: 'actions',
      label: 'Actions',
      render: (item: Shopkeeper) => (
        <button
          onClick={(e) => { e.stopPropagation(); window.print(); }}
          className="p-1.5 text-slate-400 hover:text-cyan-400 hover:bg-slate-700 rounded-lg transition-all"
          title="Print Bill"
        >
          <PrintIcon size={16} />
        </button>
      )
    },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatCard
          title="Total Shopkeepers"
          value={shopkeepers.length}
          icon={<ShopIcon size={24} />}
          color="cyan"
        />
        <StatCard
          title="Total Owed"
          value={formatCurrency(totalOwed)}
          subtitle="Unpaid balances"
          icon={<AlertIcon size={24} />}
          color={totalOwed > 0 ? 'orange' : 'green'}
        />
        <StatCard
          title="Active This Month"
          value={shopkeepers.filter(sk => getShopkeeperStats(sk.id).count > 0).length}
          icon={<MoneyIcon size={24} />}
          color="green"
        />
      </div>

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white">Shopkeepers</h2>
          <p className="text-sm text-slate-400">Manage your reseller network</p>
        </div>
        <button
          onClick={() => { resetForm(); setIsModalOpen(true); }}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium rounded-xl hover:from-cyan-600 hover:to-blue-700 transition-all"
        >
          <PlusIcon size={20} />
          Add Shopkeeper
        </button>
      </div>

      {/* Info Box */}
      <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-4">
        <p className="text-sm text-slate-400">
          <span className="text-white font-medium">Note:</span> Shopkeepers are NOT system users. 
          They are resellers whose sales are tracked under your responsibility. 
          Even if a shopkeeper sells, YOU are responsible for collection.
        </p>
      </div>

      {/* Shopkeeper Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {shopkeepers.map(sk => {
          const stats = getShopkeeperStats(sk.id);
          return (
            <div key={sk.id} className="bg-slate-800/50 border border-slate-700 rounded-2xl p-5">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="font-semibold text-white">{sk.name}</h3>
                  <p className="text-sm text-slate-400">{sk.phone || 'No phone'}</p>
                </div>
                <div className="p-2 bg-purple-500/20 rounded-xl">
                  <ShopIcon size={20} className="text-purple-400" />
                </div>
              </div>
              
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm text-slate-400">Total Sales</span>
                  <span className="text-sm font-medium text-white">{formatCurrency(stats.totalSales)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-slate-400">Collected</span>
                  <span className="text-sm font-medium text-green-400">{formatCurrency(stats.paidSales)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-slate-400">Owed</span>
                  <span className={`text-sm font-medium ${stats.unpaidSales > 0 ? 'text-orange-400' : 'text-slate-400'}`}>
                    {formatCurrency(stats.unpaidSales)}
                  </span>
                </div>
              </div>
              
              {stats.unpaidSales > 0 && (
                <button
                  onClick={() => window.print()}
                  className="w-full mt-4 py-2 bg-orange-500/20 text-orange-400 text-sm font-medium rounded-xl hover:bg-orange-500/30 transition-all flex items-center justify-center gap-2"
                >
                  <PrintIcon size={16} />
                  Print Collection Bill
                </button>
              )}
            </div>
          );
        })}
      </div>

      <DataTable
        columns={columns}
        data={shopkeepers}
        searchable
        searchPlaceholder="Search shopkeepers..."
        emptyMessage="No shopkeepers found"
      />

      {/* Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Add New Shopkeeper"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="bg-slate-800 border border-slate-700 rounded-xl p-4 mb-4">
            <p className="text-sm text-slate-400">
              Shopkeepers are resellers who sell on your behalf. 
              Their sales will be tracked under your branch and you are responsible for collecting payments.
            </p>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Shopkeeper Name *</label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              required
              placeholder="e.g., Ali Mobile Shop"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Phone</label>
            <input
              type="tel"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              placeholder="+93700000000"
            />
          </div>
          
          <div className="flex justify-end gap-3 pt-4">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 text-slate-400 hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium rounded-xl hover:from-cyan-600 hover:to-blue-700 transition-all"
            >
              Add Shopkeeper
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default ShopkeepersView;
