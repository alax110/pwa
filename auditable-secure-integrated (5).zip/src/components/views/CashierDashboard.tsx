import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { playSuccessChime, playHandoverSound } from '@/lib/notifications';
import StatCard from '../StatCard';
import Modal from '../Modal';
import { MoneyIcon, CashIcon, CheckIcon, AlertIcon, TrendUpIcon, TrendDownIcon } from '../ui/Icons';

interface CashHandover {
  id: string;
  handover_number: string;
  branch_id: string;
  handed_by: string;
  amount: number;
  total_payable: number;
  status: string;
  confirmed_at: string;
  created_at: string;
  branch?: { name: string };
  hander?: { name: string };
}

interface MonthlyTransaction {
  date: string;
  type: 'in' | 'out';
  description: string;
  amount: number;
  reference: string;
}

const CashierDashboard: React.FC = () => {
  const { currentUser } = useAuth();
  const [loading, setLoading] = useState(true);
  const [pendingHandovers, setPendingHandovers] = useState<CashHandover[]>([]);
  const [confirmedHandovers, setConfirmedHandovers] = useState<CashHandover[]>([]);
  const [monthlyHistory, setMonthlyHistory] = useState<MonthlyTransaction[]>([]);
  const [totalCashReceived, setTotalCashReceived] = useState(0);
  const [todayReceived, setTodayReceived] = useState(0);
  
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);
  const [selectedHandover, setSelectedHandover] = useState<CashHandover | null>(null);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US').format(amount) + ' AFN';
  };

  const fetchData = async () => {
    setLoading(true);
    try {
      const today = new Date().toISOString().split('T')[0];
      const monthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString();

      // Fetch pending handovers
      const { data: pendingData } = await supabase
        .from('cash_handovers')
        .select('*, branch:branches(name), hander:users!cash_handovers_handed_by_fkey(name)')
        .eq('status', 'pending')
        .order('created_at', { ascending: false });
      setPendingHandovers(pendingData || []);

      // Fetch confirmed handovers this month
      const { data: confirmedData } = await supabase
        .from('cash_handovers')
        .select('*, branch:branches(name), hander:users!cash_handovers_handed_by_fkey(name)')
        .eq('status', 'confirmed')
        .gte('confirmed_at', monthStart)
        .order('confirmed_at', { ascending: false });
      setConfirmedHandovers(confirmedData || []);

      // Calculate totals
      const totalReceived = (confirmedData || []).reduce((sum, h) => sum + Number(h.amount), 0);
      setTotalCashReceived(totalReceived);

      const todayConfirmed = (confirmedData || []).filter(h => 
        new Date(h.confirmed_at).toISOString().split('T')[0] === today
      );
      setTodayReceived(todayConfirmed.reduce((sum, h) => sum + Number(h.amount), 0));

      // Build monthly history
      const history: MonthlyTransaction[] = (confirmedData || []).map(h => ({
        date: h.confirmed_at,
        type: 'in' as const,
        description: `Cash from ${h.hander?.name || 'Branch Sales'} - ${h.branch?.name || 'Branch'}`,
        amount: Number(h.amount),
        reference: h.handover_number,
      }));
      setMonthlyHistory(history);

    } catch (error) {
      console.error('Error fetching data:', error);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchData();

    // Subscribe to real-time updates
    const channel = supabase
      .channel('cashier-updates')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'cash_handovers' }, () => {
        fetchData();
        playHandoverSound();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const handleConfirmHandover = async () => {
    if (!selectedHandover) return;
    
    try {
      const userId = currentUser?.id || 'dddddddd-dddd-dddd-dddd-dddddddddddd';

      await supabase
        .from('cash_handovers')
        .update({ 
          status: 'confirmed', 
          confirmed_at: new Date().toISOString(),
          received_by: userId
        })
        .eq('id', selectedHandover.id);

      // Create notification for the sales person
      await supabase.from('notifications').insert({
        user_id: selectedHandover.handed_by,
        title: 'Handover Confirmed',
        message: `Your cash handover ${selectedHandover.handover_number} of ${formatCurrency(Number(selectedHandover.amount))} has been confirmed by Cashier.`,
        type: 'success',
      });

      await supabase.from('audit_logs').insert({
        user_id: userId,
        action: 'CONFIRM_HANDOVER',
        entity_type: 'cash_handover',
        entity_id: selectedHandover.id,
        new_data: { handover_number: selectedHandover.handover_number, amount: selectedHandover.amount }
      });

      playSuccessChime();
      setIsConfirmModalOpen(false);
      setSelectedHandover(null);
      fetchData();
    } catch (error) {
      console.error('Error confirming handover:', error);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-green-600/20 to-emerald-600/20 border border-green-500/30 rounded-2xl p-6">
        <h2 className="text-2xl font-bold text-white">Cashier Dashboard</h2>
        <p className="text-slate-400 mt-1">Receive and confirm cash handovers. All features are read-only except confirmation.</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Cash Received"
          value={formatCurrency(totalCashReceived)}
          subtitle="This month"
          icon={<CashIcon size={24} />}
          color="green"
        />
        <StatCard
          title="Today's Received"
          value={formatCurrency(todayReceived)}
          subtitle="Confirmed today"
          icon={<MoneyIcon size={24} />}
          color="cyan"
        />
        <StatCard
          title="Pending Handovers"
          value={pendingHandovers.length}
          subtitle="Awaiting confirmation"
          icon={<AlertIcon size={24} />}
          color={pendingHandovers.length > 0 ? 'yellow' : 'green'}
        />
        <StatCard
          title="Confirmed Today"
          value={confirmedHandovers.filter(h => 
            new Date(h.confirmed_at).toDateString() === new Date().toDateString()
          ).length}
          subtitle="Transactions"
          icon={<CheckIcon size={24} />}
          color="purple"
        />
      </div>

      {/* Pending Handovers - Action Required */}
      {pendingHandovers.length > 0 && (
        <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-yellow-500/30">
            <h3 className="font-semibold text-yellow-400">Pending Handovers - Confirm Receipt</h3>
          </div>
          <div className="divide-y divide-yellow-500/20">
            {pendingHandovers.map(handover => (
              <div key={handover.id} className="p-4 flex items-center justify-between">
                <div>
                  <p className="font-medium text-white">{handover.handover_number}</p>
                  <p className="text-sm text-slate-400">
                    From: {handover.hander?.name || 'Branch Sales'} • {handover.branch?.name || 'Branch'}
                  </p>
                  <p className="text-xs text-slate-500">{new Date(handover.created_at).toLocaleString()}</p>
                </div>
                <div className="flex items-center gap-3">
                  <p className="font-bold text-yellow-400">{formatCurrency(Number(handover.amount))}</p>
                  <button
                    onClick={() => { setSelectedHandover(handover); setIsConfirmModalOpen(true); }}
                    className="px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700"
                  >
                    Confirm Receipt
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Monthly History */}
      <div className="bg-slate-800/50 border border-slate-700 rounded-2xl overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-700 flex items-center justify-between">
          <h3 className="font-semibold text-white">Monthly Cash History</h3>
          <span className="text-sm text-slate-400">
            {new Date().toLocaleString('default', { month: 'long', year: 'numeric' })}
          </span>
        </div>
        <div className="divide-y divide-slate-700/50 max-h-96 overflow-y-auto">
          {monthlyHistory.length === 0 ? (
            <p className="p-4 text-slate-400 text-center">No transactions this month</p>
          ) : (
            monthlyHistory.map((tx, idx) => (
              <div key={idx} className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                    tx.type === 'in' ? 'bg-green-500/20' : 'bg-red-500/20'
                  }`}>
                    {tx.type === 'in' ? (
                      <TrendUpIcon size={20} className="text-green-400" />
                    ) : (
                      <TrendDownIcon size={20} className="text-red-400" />
                    )}
                  </div>
                  <div>
                    <p className="font-medium text-white">{tx.reference}</p>
                    <p className="text-sm text-slate-400">{tx.description}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className={`font-bold ${tx.type === 'in' ? 'text-green-400' : 'text-red-400'}`}>
                    {tx.type === 'in' ? '+' : '-'}{formatCurrency(tx.amount)}
                  </p>
                  <p className="text-xs text-slate-500">{new Date(tx.date).toLocaleDateString()}</p>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Recent Confirmed */}
      <div className="bg-slate-800/50 border border-slate-700 rounded-2xl overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-700">
          <h3 className="font-semibold text-white">Recently Confirmed</h3>
        </div>
        <div className="divide-y divide-slate-700/50">
          {confirmedHandovers.slice(0, 5).length === 0 ? (
            <p className="p-4 text-slate-400 text-center">No confirmed handovers yet</p>
          ) : (
            confirmedHandovers.slice(0, 5).map(handover => (
              <div key={handover.id} className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-green-500/20 rounded-xl flex items-center justify-center">
                    <CheckIcon size={20} className="text-green-400" />
                  </div>
                  <div>
                    <p className="font-medium text-white">{handover.handover_number}</p>
                    <p className="text-sm text-slate-400">
                      {handover.hander?.name} • {handover.branch?.name}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-green-400">+{formatCurrency(Number(handover.amount))}</p>
                  <p className="text-xs text-slate-500">{new Date(handover.confirmed_at).toLocaleString()}</p>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Info Box */}
      <div className="bg-slate-800/30 border border-slate-700 rounded-xl p-4">
        <h4 className="font-medium text-white mb-2">Cashier Responsibilities</h4>
        <ul className="text-sm text-slate-400 space-y-1">
          <li>• Receive physical cash from Branch Sales personnel</li>
          <li>• Verify the amount matches the handover receipt</li>
          <li>• Sign the receipt and confirm in the system</li>
          <li>• All other features are read-only for audit purposes</li>
        </ul>
      </div>

      {/* Confirm Handover Modal */}
      <Modal isOpen={isConfirmModalOpen} onClose={() => { setIsConfirmModalOpen(false); setSelectedHandover(null); }} title="Confirm Cash Receipt">
        {selectedHandover && (
          <div className="space-y-4">
            <div className="bg-slate-800 border border-slate-700 rounded-xl p-4 space-y-3">
              <div className="flex justify-between">
                <span className="text-slate-400">Handover Number:</span>
                <span className="text-white font-medium">{selectedHandover.handover_number}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">From:</span>
                <span className="text-white">{selectedHandover.hander?.name || 'Branch Sales'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Branch:</span>
                <span className="text-white">{selectedHandover.branch?.name || 'Branch'}</span>
              </div>
              <div className="flex justify-between border-t border-slate-700 pt-3">
                <span className="text-slate-400">Amount:</span>
                <span className="text-green-400 font-bold text-xl">{formatCurrency(Number(selectedHandover.amount))}</span>
              </div>
            </div>
            
            <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-xl p-3 text-sm text-yellow-400">
              Please verify you have received the physical cash before confirming.
            </div>
            
            <div className="flex gap-3">
              <button
                onClick={() => { setIsConfirmModalOpen(false); setSelectedHandover(null); }}
                className="flex-1 py-3 bg-slate-700 text-white font-medium rounded-xl hover:bg-slate-600"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmHandover}
                className="flex-1 py-3 bg-green-600 text-white font-medium rounded-xl hover:bg-green-700 flex items-center justify-center gap-2"
              >
                <CheckIcon size={20} />
                Confirm Receipt
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default CashierDashboard;
