import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Sale, Branch, Shopkeeper, User } from '@/types';
import DataTable from '../DataTable';
import Modal from '../Modal';
import StatCard from '../StatCard';
import { PlusIcon, PrintIcon, MoneyIcon, AlertIcon, SalesIcon, CheckIcon } from '../ui/Icons';

const SalesView: React.FC = () => {
  const { currentUser } = useAuth();
  const [sales, setSales] = useState<Sale[]>([]);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [shopkeepers, setShopkeepers] = useState<Shopkeeper[]>([]);
  const [engineers, setEngineers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    customer_name: '',
    customer_phone: '',
    customer_address: '',
    amount: '',
    shopkeeper_id: '',
    is_paid: false,
    payment_method: 'cash',
    notes: '',
    assign_engineer: '',
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      let salesQuery = supabase.from('sales').select('*').order('created_at', { ascending: false });
      
      // Filter by branch for branch_sales role
      if (currentUser?.role === 'branch_sales' && currentUser.branch_id) {
        salesQuery = salesQuery.eq('branch_id', currentUser.branch_id);
      }

      const [salesRes, branchesRes, shopkeepersRes, engineersRes] = await Promise.all([
        salesQuery,
        supabase.from('branches').select('*'),
        supabase.from('shopkeepers').select('*'),
        supabase.from('users').select('*').eq('role', 'engineer'),
      ]);

      setSales(salesRes.data || []);
      setBranches(branchesRes.data || []);
      setShopkeepers(shopkeepersRes.data || []);
      setEngineers(engineersRes.data || []);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const generateSaleNumber = () => {
    const date = new Date();
    const year = date.getFullYear();
    const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    return `SL-${year}-${random}`;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const amount = parseFloat(formData.amount);
      const taxAmount = amount * 0.10;
      const devAmount = amount * 0.20;
      const revenueAmount = amount * 0.70;

      const saleData = {
        sale_number: generateSaleNumber(),
        customer_name: formData.customer_name,
        customer_phone: formData.customer_phone,
        customer_address: formData.customer_address,
        branch_id: currentUser?.branch_id || branches[0]?.id,
        created_by: currentUser?.id,
        shopkeeper_id: formData.shopkeeper_id || null,
        amount,
        tax_amount: taxAmount,
        dev_amount: devAmount,
        revenue_amount: revenueAmount,
        is_paid: formData.is_paid,
        paid_at: formData.is_paid ? new Date().toISOString() : null,
        payment_method: formData.is_paid ? formData.payment_method : null,
        notes: formData.notes,
      };

      const { data: newSale, error } = await supabase.from('sales').insert(saleData).select().single();
      
      if (error) throw error;

      // Update budget buckets if paid
      if (formData.is_paid) {
        await Promise.all([
          supabase.rpc('increment_bucket', { bucket_name: 'TAX', inc_amount: taxAmount }),
          supabase.rpc('increment_bucket', { bucket_name: 'DEV', inc_amount: devAmount }),
          supabase.rpc('increment_bucket', { bucket_name: 'REVENUE', inc_amount: revenueAmount }),
        ]).catch(() => {
          // RPC might not exist, that's okay
        });
      }

      // Create installation task if engineer assigned
      if (formData.assign_engineer && newSale) {
        await supabase.from('tasks').insert({
          task_number: `TSK-${Date.now()}`,
          task_type: 'installation',
          title: `New Connection - ${formData.customer_name}`,
          description: `Install connection at ${formData.customer_address}`,
          branch_id: currentUser?.branch_id || branches[0]?.id,
          sale_id: newSale.id,
          assigned_to: formData.assign_engineer,
          assigned_by: currentUser?.id,
          status: 'pending',
          priority: 'normal',
        });
      }

      setIsModalOpen(false);
      resetForm();
      fetchData();
    } catch (error) {
      console.error('Error creating sale:', error);
    }
  };

  const resetForm = () => {
    setFormData({
      customer_name: '',
      customer_phone: '',
      customer_address: '',
      amount: '',
      shopkeeper_id: '',
      is_paid: false,
      payment_method: 'cash',
      notes: '',
      assign_engineer: '',
    });
  };

  const handleMarkPaid = async (sale: Sale) => {
    try {
      await supabase
        .from('sales')
        .update({ is_paid: true, paid_at: new Date().toISOString() })
        .eq('id', sale.id);
      fetchData();
    } catch (error) {
      console.error('Error updating sale:', error);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US').format(amount) + ' AFN';
  };

  const paidSales = sales.filter(s => s.is_paid);
  const unpaidSales = sales.filter(s => !s.is_paid);
  const totalPaid = paidSales.reduce((sum, s) => sum + parseFloat(String(s.amount)), 0);
  const totalUnpaid = unpaidSales.reduce((sum, s) => sum + parseFloat(String(s.amount)), 0);

  const columns = [
    { key: 'sale_number', label: 'Sale #' },
    { key: 'customer_name', label: 'Customer' },
    { key: 'customer_phone', label: 'Phone' },
    { 
      key: 'amount', 
      label: 'Amount',
      render: (item: Sale) => formatCurrency(parseFloat(String(item.amount)))
    },
    { 
      key: 'is_paid', 
      label: 'Status',
      render: (item: Sale) => (
        <span className={`px-2 py-1 text-xs rounded-full border ${
          item.is_paid 
            ? 'bg-green-500/20 text-green-400 border-green-500/30' 
            : 'bg-orange-500/20 text-orange-400 border-orange-500/30'
        }`}>
          {item.is_paid ? 'Paid' : 'Unpaid'}
        </span>
      )
    },
    {
      key: 'created_at',
      label: 'Date',
      render: (item: Sale) => new Date(item.created_at).toLocaleDateString()
    },
    {
      key: 'actions',
      label: 'Actions',
      render: (item: Sale) => (
        <div className="flex items-center gap-2">
          {!item.is_paid && (
            <button
              onClick={(e) => { e.stopPropagation(); handleMarkPaid(item); }}
              className="p-1.5 text-slate-400 hover:text-green-400 hover:bg-slate-700 rounded-lg transition-all"
              title="Mark as Paid"
            >
              <CheckIcon size={16} />
            </button>
          )}
          <button
            onClick={(e) => { e.stopPropagation(); window.print(); }}
            className="p-1.5 text-slate-400 hover:text-cyan-400 hover:bg-slate-700 rounded-lg transition-all"
            title="Print Bill"
          >
            <PrintIcon size={16} />
          </button>
        </div>
      )
    },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatCard
          title="Total Sales"
          value={formatCurrency(totalPaid + totalUnpaid)}
          icon={<SalesIcon size={24} />}
          color="cyan"
        />
        <StatCard
          title="Paid Sales"
          value={formatCurrency(totalPaid)}
          subtitle={`${paidSales.length} transactions`}
          icon={<MoneyIcon size={24} />}
          color="green"
        />
        <StatCard
          title="Unpaid Sales"
          value={formatCurrency(totalUnpaid)}
          subtitle={`${unpaidSales.length} pending`}
          icon={<AlertIcon size={24} />}
          color="orange"
        />
      </div>

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white">Sales</h2>
          <p className="text-sm text-slate-400">Create and manage customer sales</p>
        </div>
        <button
          onClick={() => { resetForm(); setIsModalOpen(true); }}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium rounded-xl hover:from-cyan-600 hover:to-blue-700 transition-all"
        >
          <PlusIcon size={20} />
          New Sale
        </button>
      </div>

      {/* Revenue Split Info */}
      <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-4">
        <p className="text-sm text-slate-400">
          <span className="text-white font-medium">Auto Revenue Split:</span> Every sale automatically splits into 
          <span className="text-red-400"> 10% TAX</span>, 
          <span className="text-blue-400"> 20% DEV</span>, 
          <span className="text-green-400"> 70% REVENUE</span>
        </p>
      </div>

      <DataTable
        columns={columns}
        data={sales}
        searchable
        searchPlaceholder="Search sales..."
        emptyMessage="No sales found"
      />

      {/* New Sale Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Create New Sale"
        size="lg"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Customer Name *</label>
              <input
                type="text"
                value={formData.customer_name}
                onChange={(e) => setFormData({ ...formData, customer_name: e.target.value })}
                className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Phone</label>
              <input
                type="tel"
                value={formData.customer_phone}
                onChange={(e) => setFormData({ ...formData, customer_phone: e.target.value })}
                className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Address</label>
            <input
              type="text"
              value={formData.customer_address}
              onChange={(e) => setFormData({ ...formData, customer_address: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Amount (AFN) *</label>
              <input
                type="number"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                required
                min="0"
              />
              {formData.amount && (
                <div className="mt-2 text-xs text-slate-500">
                  Split: TAX {(parseFloat(formData.amount) * 0.1).toFixed(0)} | 
                  DEV {(parseFloat(formData.amount) * 0.2).toFixed(0)} | 
                  REV {(parseFloat(formData.amount) * 0.7).toFixed(0)}
                </div>
              )}
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Shopkeeper (Optional)</label>
              <select
                value={formData.shopkeeper_id}
                onChange={(e) => setFormData({ ...formData, shopkeeper_id: e.target.value })}
                className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              >
                <option value="">Direct Sale</option>
                {shopkeepers.map((sk) => (
                  <option key={sk.id} value={sk.id}>{sk.name}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Assign Engineer</label>
              <select
                value={formData.assign_engineer}
                onChange={(e) => setFormData({ ...formData, assign_engineer: e.target.value })}
                className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              >
                <option value="">No Installation Task</option>
                {engineers.map((eng) => (
                  <option key={eng.id} value={eng.id}>{eng.name}</option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Payment Method</label>
              <select
                value={formData.payment_method}
                onChange={(e) => setFormData({ ...formData, payment_method: e.target.value })}
                className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              >
                <option value="cash">Cash</option>
                <option value="bank">Bank Transfer</option>
                <option value="mobile">Mobile Money</option>
              </select>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Notes</label>
            <textarea
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              rows={2}
            />
          </div>
          
          <div className="flex items-center gap-3">
            <input
              type="checkbox"
              id="is_paid"
              checked={formData.is_paid}
              onChange={(e) => setFormData({ ...formData, is_paid: e.target.checked })}
              className="w-4 h-4 rounded border-slate-600 bg-slate-800 text-cyan-500 focus:ring-cyan-500"
            />
            <label htmlFor="is_paid" className="text-sm text-slate-300">Mark as Paid</label>
          </div>
          
          <div className="flex justify-end gap-3 pt-4">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 text-slate-400 hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium rounded-xl hover:from-cyan-600 hover:to-blue-700 transition-all"
            >
              Create Sale
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default SalesView;
