import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { playSuccessChime, playErrorSound, playTaskSound } from '@/lib/notifications';
import StatCard from '../StatCard';
import Modal from '../Modal';
import { InventoryIcon, AlertIcon, BranchIcon, PlusIcon, CheckIcon } from '../ui/Icons';

interface InventoryItem {
  id: string;
  name: string;
  sku: string;
  category: string;
  unit_price: number;
}

interface Stock {
  id: string;
  item_id: string;
  quantity: number;
  min_quantity: number;
  item?: InventoryItem;
}

interface Branch {
  id: string;
  name: string;
}

interface StockIssue {
  id: string;
  item_id: string;
  branch_id: string;
  quantity: number;
  issued_by: string;
  created_at: string;
  item?: InventoryItem;
  branch?: Branch;
}

interface ApprovedPO {
  id: string;
  po_number: string;
  items_description: string;
  total_amount: number;
  approved_at: string;
  status: string;
}

const InventoryDashboard: React.FC = () => {
  const { currentUser } = useAuth();
  const [loading, setLoading] = useState(true);
  const [stock, setStock] = useState<Stock[]>([]);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [recentIssues, setRecentIssues] = useState<StockIssue[]>([]);
  const [approvedPOs, setApprovedPOs] = useState<ApprovedPO[]>([]);
  const [lowStockItems, setLowStockItems] = useState<Stock[]>([]);
  
  const [isIssueModalOpen, setIsIssueModalOpen] = useState(false);
  const [isRequestModalOpen, setIsRequestModalOpen] = useState(false);
  const [isAddStockModalOpen, setIsAddStockModalOpen] = useState(false);
  const [selectedPO, setSelectedPO] = useState<ApprovedPO | null>(null);

  const [issueForm, setIssueForm] = useState({ item_id: '', branch_id: '', quantity: '' });
  const [requestForm, setRequestForm] = useState({ item_name: '', quantity: '', reason: '' });
  const [addStockForm, setAddStockForm] = useState({ item_id: '', quantity: '' });

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US').format(amount) + ' AFN';
  };

  const fetchData = async () => {
    setLoading(true);
    try {
      // Fetch stock with items
      const { data: stockData } = await supabase
        .from('stock')
        .select('*, item:inventory_items(*)');
      setStock(stockData || []);

      // Find low stock items
      const lowStock = (stockData || []).filter(s => s.quantity <= s.min_quantity);
      setLowStockItems(lowStock);

      // Fetch branches
      const { data: branchesData } = await supabase
        .from('branches')
        .select('*')
        .eq('is_active', true);
      setBranches(branchesData || []);

      // Fetch recent stock issues
      const { data: issuesData } = await supabase
        .from('stock_issues')
        .select('*, item:inventory_items(name), branch:branches(name)')
        .order('created_at', { ascending: false })
        .limit(10);
      setRecentIssues(issuesData || []);

      // Fetch approved POs ready for inventory
      const { data: posData } = await supabase
        .from('purchase_orders')
        .select('*')
        .eq('status', 'approved')
        .order('approved_at', { ascending: false });
      setApprovedPOs(posData || []);

    } catch (error) {
      console.error('Error fetching data:', error);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchData();

    // Subscribe to real-time updates
    const channel = supabase
      .channel('inventory-updates')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'purchase_orders' }, (payload) => {
        if (payload.new && (payload.new as any).status === 'approved') {
          playTaskSound();
        }
        fetchData();
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'stock' }, () => {
        fetchData();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const totalItems = stock.reduce((sum, s) => sum + s.quantity, 0);
  const uniqueItems = stock.length;

  const handleIssueStock = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const quantity = parseInt(issueForm.quantity);
      const stockItem = stock.find(s => s.item_id === issueForm.item_id);
      
      if (!stockItem || stockItem.quantity < quantity) {
        playErrorSound();
        alert('Insufficient stock!');
        return;
      }

      const userId = currentUser?.id || 'cccccccc-cccc-cccc-cccc-cccccccccccc';

      // Create stock issue record
      const { error: issueError } = await supabase.from('stock_issues').insert({
        item_id: issueForm.item_id,
        branch_id: issueForm.branch_id,
        quantity: quantity,
        issued_by: userId,
      });

      if (issueError) throw issueError;

      // Update stock quantity
      await supabase
        .from('stock')
        .update({ quantity: stockItem.quantity - quantity })
        .eq('id', stockItem.id);

      await supabase.from('audit_logs').insert({
        user_id: userId,
        action: 'ISSUE_STOCK',
        entity_type: 'stock',
        new_data: { 
          item: stockItem.item?.name, 
          branch_id: issueForm.branch_id, 
          quantity 
        }
      });

      playSuccessChime();
      setIsIssueModalOpen(false);
      setIssueForm({ item_id: '', branch_id: '', quantity: '' });
      fetchData();
    } catch (error) {
      console.error('Error issuing stock:', error);
      playErrorSound();
    }
  };

  const handleRequestStock = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const userId = currentUser?.id || 'cccccccc-cccc-cccc-cccc-cccccccccccc';

      const { error } = await supabase.from('stock_requests').insert({
        requested_by: userId,
        item_name: requestForm.item_name,
        quantity: parseInt(requestForm.quantity),
        reason: requestForm.reason,
        status: 'pending',
      });

      if (error) throw error;

      // Notify Accounts
      await supabase.from('notifications').insert({
        user_id: 'eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee',
        title: 'Stock Request from Inventory',
        message: `Inventory requests ${requestForm.quantity}x ${requestForm.item_name}. Reason: ${requestForm.reason}`,
        type: 'task',
      });

      await supabase.from('audit_logs').insert({
        user_id: userId,
        action: 'REQUEST_STOCK',
        entity_type: 'stock_request',
        new_data: { item: requestForm.item_name, quantity: requestForm.quantity, reason: requestForm.reason }
      });

      playSuccessChime();
      setIsRequestModalOpen(false);
      setRequestForm({ item_name: '', quantity: '', reason: '' });
      alert('Stock request sent to Accounts. They will create a PO for Admin approval.');
    } catch (error) {
      console.error('Error requesting stock:', error);
      playErrorSound();
    }
  };

  const handleAddFromPO = async (po: ApprovedPO) => {
    setSelectedPO(po);
    setIsAddStockModalOpen(true);
  };

  const handleConfirmAddStock = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPO) return;

    try {
      const userId = currentUser?.id || 'cccccccc-cccc-cccc-cccc-cccccccccccc';
      const quantity = parseInt(addStockForm.quantity);

      // Update stock if item exists, otherwise create new
      const existingStock = stock.find(s => s.item_id === addStockForm.item_id);
      
      if (existingStock) {
        await supabase
          .from('stock')
          .update({ quantity: existingStock.quantity + quantity })
          .eq('id', existingStock.id);
      }

      // Mark PO as received
      await supabase
        .from('purchase_orders')
        .update({ status: 'received' })
        .eq('id', selectedPO.id);

      // Update purchase history
      await supabase
        .from('purchase_history')
        .update({ added_to_inventory: true })
        .eq('po_id', selectedPO.id);

      await supabase.from('audit_logs').insert({
        user_id: userId,
        action: 'ADD_STOCK_FROM_PO',
        entity_type: 'stock',
        new_data: { po_number: selectedPO.po_number, quantity }
      });

      playSuccessChime();
      setIsAddStockModalOpen(false);
      setSelectedPO(null);
      setAddStockForm({ item_id: '', quantity: '' });
      fetchData();
    } catch (error) {
      console.error('Error adding stock:', error);
      playErrorSound();
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-purple-600/20 to-blue-600/20 border border-purple-500/30 rounded-2xl p-6">
        <h2 className="text-2xl font-bold text-white">Inventory Dashboard</h2>
        <p className="text-slate-400 mt-1">Manage stock levels and issue items to branches. No money handling.</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Items"
          value={totalItems}
          subtitle={`${uniqueItems} unique items`}
          icon={<InventoryIcon size={24} />}
          color="cyan"
        />
        <StatCard
          title="Low Stock"
          value={lowStockItems.length}
          subtitle="Need restock"
          icon={<AlertIcon size={24} />}
          color={lowStockItems.length > 0 ? 'red' : 'green'}
        />
        <StatCard
          title="Branches"
          value={branches.length}
          subtitle="Active branches"
          icon={<BranchIcon size={24} />}
          color="purple"
        />
        <StatCard
          title="Approved POs"
          value={approvedPOs.length}
          subtitle="Ready to add"
          icon={<CheckIcon size={24} />}
          color={approvedPOs.length > 0 ? 'yellow' : 'green'}
        />
      </div>

      {/* Approved POs - Add to Inventory */}
      {approvedPOs.length > 0 && (
        <div className="bg-green-500/10 border border-green-500/30 rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-green-500/30">
            <h3 className="font-semibold text-green-400">Approved POs - Add Items to Inventory</h3>
          </div>
          <div className="divide-y divide-green-500/20">
            {approvedPOs.map(po => (
              <div key={po.id} className="p-4 flex items-center justify-between">
                <div>
                  <p className="font-medium text-white">{po.po_number}</p>
                  <p className="text-sm text-slate-400">{po.items_description}</p>
                  <p className="text-xs text-slate-500">Approved: {new Date(po.approved_at).toLocaleDateString()}</p>
                </div>
                <div className="flex items-center gap-3">
                  <p className="font-bold text-green-400">{formatCurrency(Number(po.total_amount))}</p>
                  <button
                    onClick={() => handleAddFromPO(po)}
                    className="px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700"
                  >
                    Add to Stock
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex flex-wrap gap-3">
        <button
          onClick={() => setIsIssueModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium rounded-xl hover:opacity-90"
        >
          <BranchIcon size={20} />
          Issue to Branch
        </button>
        <button
          onClick={() => setIsRequestModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-orange-500 to-red-600 text-white font-medium rounded-xl hover:opacity-90"
        >
          <PlusIcon size={20} />
          Request Stock
        </button>
      </div>

      {/* Low Stock Alert */}
      {lowStockItems.length > 0 && (
        <div className="bg-red-500/10 border border-red-500/30 rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-red-500/30">
            <h3 className="font-semibold text-red-400">Low Stock Alert - Request Restock</h3>
          </div>
          <div className="divide-y divide-red-500/20">
            {lowStockItems.map(item => (
              <div key={item.id} className="p-4 flex items-center justify-between">
                <div>
                  <p className="font-medium text-white">{item.item?.name}</p>
                  <p className="text-sm text-slate-400">SKU: {item.item?.sku}</p>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <p className="font-bold text-red-400">{item.quantity} left</p>
                    <p className="text-xs text-slate-500">Min: {item.min_quantity}</p>
                  </div>
                  <button
                    onClick={() => {
                      setRequestForm({ 
                        item_name: item.item?.name || '', 
                        quantity: String(item.min_quantity * 2), 
                        reason: 'Low stock alert' 
                      });
                      setIsRequestModalOpen(true);
                    }}
                    className="px-3 py-1.5 bg-orange-600 text-white text-sm rounded-lg hover:bg-orange-700"
                  >
                    Request
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Current Stock */}
      <div className="bg-slate-800/50 border border-slate-700 rounded-2xl overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-700">
          <h3 className="font-semibold text-white">Current Stock</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-800">
              <tr>
                <th className="text-left p-4 text-slate-300 font-medium">Item</th>
                <th className="text-left p-4 text-slate-300 font-medium">SKU</th>
                <th className="text-left p-4 text-slate-300 font-medium">Category</th>
                <th className="text-right p-4 text-slate-300 font-medium">Quantity</th>
                <th className="text-right p-4 text-slate-300 font-medium">Min Qty</th>
                <th className="text-center p-4 text-slate-300 font-medium">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700/50">
              {stock.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-4 text-center text-slate-400">No stock items</td>
                </tr>
              ) : (
                stock.map(item => (
                  <tr key={item.id}>
                    <td className="p-4 text-white font-medium">{item.item?.name}</td>
                    <td className="p-4 text-slate-400">{item.item?.sku}</td>
                    <td className="p-4 text-slate-400">{item.item?.category}</td>
                    <td className="p-4 text-right text-white font-bold">{item.quantity}</td>
                    <td className="p-4 text-right text-slate-400">{item.min_quantity}</td>
                    <td className="p-4 text-center">
                      <span className={`px-2 py-1 text-xs rounded-full ${
                        item.quantity <= item.min_quantity 
                          ? 'bg-red-500/20 text-red-400' 
                          : item.quantity <= item.min_quantity * 2
                          ? 'bg-yellow-500/20 text-yellow-400'
                          : 'bg-green-500/20 text-green-400'
                      }`}>
                        {item.quantity <= item.min_quantity ? 'Low' : item.quantity <= item.min_quantity * 2 ? 'Medium' : 'Good'}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Recent Issues */}
      <div className="bg-slate-800/50 border border-slate-700 rounded-2xl overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-700">
          <h3 className="font-semibold text-white">Recent Stock Issues</h3>
        </div>
        <div className="divide-y divide-slate-700/50">
          {recentIssues.length === 0 ? (
            <p className="p-4 text-slate-400 text-center">No recent issues</p>
          ) : (
            recentIssues.map(issue => (
              <div key={issue.id} className="p-4 flex items-center justify-between">
                <div>
                  <p className="font-medium text-white">{issue.item?.name}</p>
                  <p className="text-sm text-slate-400">To: {issue.branch?.name}</p>
                </div>
                <div className="text-right">
                  <p className="font-bold text-cyan-400">{issue.quantity} units</p>
                  <p className="text-xs text-slate-500">{new Date(issue.created_at).toLocaleDateString()}</p>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Issue Stock Modal */}
      <Modal isOpen={isIssueModalOpen} onClose={() => setIsIssueModalOpen(false)} title="Issue Stock to Branch">
        <form onSubmit={handleIssueStock} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Item *</label>
            <select
              value={issueForm.item_id}
              onChange={(e) => setIssueForm({ ...issueForm, item_id: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white"
              required
            >
              <option value="">Select Item</option>
              {stock.filter(s => s.quantity > 0).map(s => (
                <option key={s.item_id} value={s.item_id}>
                  {s.item?.name} ({s.quantity} available)
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Branch *</label>
            <select
              value={issueForm.branch_id}
              onChange={(e) => setIssueForm({ ...issueForm, branch_id: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white"
              required
            >
              <option value="">Select Branch</option>
              {branches.map(b => (
                <option key={b.id} value={b.id}>{b.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Quantity *</label>
            <input
              type="number"
              value={issueForm.quantity}
              onChange={(e) => setIssueForm({ ...issueForm, quantity: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white"
              required
              min="1"
            />
          </div>
          <div className="flex justify-end gap-3 pt-4">
            <button type="button" onClick={() => setIsIssueModalOpen(false)} className="px-4 py-2 text-slate-400">Cancel</button>
            <button type="submit" className="px-6 py-2 bg-cyan-600 text-white font-medium rounded-xl hover:bg-cyan-700">Issue Stock</button>
          </div>
        </form>
      </Modal>

      {/* Request Stock Modal */}
      <Modal isOpen={isRequestModalOpen} onClose={() => setIsRequestModalOpen(false)} title="Request Stock from Accounts">
        <form onSubmit={handleRequestStock} className="space-y-4">
          <div className="bg-slate-800 border border-slate-700 rounded-xl p-3 text-sm text-slate-400">
            This request will be sent to Accounts who will create a Purchase Order for Admin approval.
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Item Name *</label>
            <input
              type="text"
              value={requestForm.item_name}
              onChange={(e) => setRequestForm({ ...requestForm, item_name: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white"
              required
              placeholder="e.g., ONU Device"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Quantity *</label>
            <input
              type="number"
              value={requestForm.quantity}
              onChange={(e) => setRequestForm({ ...requestForm, quantity: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white"
              required
              min="1"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Reason *</label>
            <textarea
              value={requestForm.reason}
              onChange={(e) => setRequestForm({ ...requestForm, reason: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white"
              required
              rows={2}
              placeholder="e.g., Low stock, new branch opening"
            />
          </div>
          <div className="flex justify-end gap-3 pt-4">
            <button type="button" onClick={() => setIsRequestModalOpen(false)} className="px-4 py-2 text-slate-400">Cancel</button>
            <button type="submit" className="px-6 py-2 bg-orange-600 text-white font-medium rounded-xl hover:bg-orange-700">Send Request</button>
          </div>
        </form>
      </Modal>

      {/* Add Stock from PO Modal */}
      <Modal isOpen={isAddStockModalOpen} onClose={() => { setIsAddStockModalOpen(false); setSelectedPO(null); }} title="Add Items to Inventory">
        {selectedPO && (
          <form onSubmit={handleConfirmAddStock} className="space-y-4">
            <div className="bg-slate-800 border border-slate-700 rounded-xl p-4">
              <p className="text-white font-medium">{selectedPO.po_number}</p>
              <p className="text-slate-400 text-sm">{selectedPO.items_description}</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Select Item to Add *</label>
              <select
                value={addStockForm.item_id}
                onChange={(e) => setAddStockForm({ ...addStockForm, item_id: e.target.value })}
                className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white"
                required
              >
                <option value="">Select Item</option>
                {stock.map(s => (
                  <option key={s.item_id} value={s.item_id}>{s.item?.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Quantity Received *</label>
              <input
                type="number"
                value={addStockForm.quantity}
                onChange={(e) => setAddStockForm({ ...addStockForm, quantity: e.target.value })}
                className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white"
                required
                min="1"
              />
            </div>
            <div className="flex justify-end gap-3 pt-4">
              <button type="button" onClick={() => { setIsAddStockModalOpen(false); setSelectedPO(null); }} className="px-4 py-2 text-slate-400">Cancel</button>
              <button type="submit" className="px-6 py-2 bg-green-600 text-white font-medium rounded-xl hover:bg-green-700">Add to Stock</button>
            </div>
          </form>
        )}
      </Modal>
    </div>
  );
};

export default InventoryDashboard;
