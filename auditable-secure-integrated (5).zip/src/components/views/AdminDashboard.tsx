import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { playApprovalSound, playErrorSound, playSuccessChime } from '@/lib/notifications';
import StatCard from '../StatCard';
import Modal from '../Modal';
import { 
  MoneyIcon, UsersIcon, SalesIcon, 
  BranchIcon, TaskIcon, AlertIcon, TrendUpIcon, CheckIcon, PartnerIcon, PrintIcon
} from '../ui/Icons';

interface PurchaseOrder {
  id: string;
  po_number: string;
  requested_by: string;
  bucket_name: string;
  status: string;
  total_amount: number;
  items_description: string;
  notes: string;
  created_at: string;
  requester?: { name: string };
}

interface Report {
  id: string;
  reported_by: string;
  reported_user_id: string;
  category: string;
  description: string;
  status: string;
  created_at: string;
  reporter?: { name: string };
  reported_user?: { name: string };
}

const AdminDashboard: React.FC = () => {
  const { systemReset } = useAuth();
  const [loading, setLoading] = useState(true);
  const [resetting, setResetting] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [resetConfirmText, setResetConfirmText] = useState('');
  const [stats, setStats] = useState({
    totalSales: 0,
    paidSales: 0,
    unpaidSales: 0,
    totalUsers: 0,
    totalBranches: 0,
    pendingTasks: 0,
    openComplaints: 0,
    taxBucket: 0,
    devBucket: 0,
    revenueBucket: 0,
  });
  const [pendingPOs, setPendingPOs] = useState<PurchaseOrder[]>([]);
  const [reports, setReports] = useState<Report[]>([]);
  const [recentSales, setRecentSales] = useState<any[]>([]);
  const [recentTasks, setRecentTasks] = useState<any[]>([]);
  const [activities, setActivities] = useState<any[]>([]);
  const [isPODetailOpen, setIsPODetailOpen] = useState(false);
  const [selectedPO, setSelectedPO] = useState<PurchaseOrder | null>(null);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US').format(amount) + ' AFN';
  };



  const fetchData = async () => {
    setLoading(true);
    try {
      // Fetch budget buckets
      const { data: buckets } = await supabase.from('budget_buckets').select('*');
      const taxBucket = buckets?.find(b => b.name === 'TAX')?.current_balance || 0;
      const devBucket = buckets?.find(b => b.name === 'DEV')?.current_balance || 0;
      const revenueBucket = buckets?.find(b => b.name === 'REVENUE')?.current_balance || 0;

      // Fetch sales stats
      const { data: sales } = await supabase.from('sales').select('amount, is_paid');
      const totalSales = sales?.reduce((sum, s) => sum + Number(s.amount), 0) || 0;
      const paidSales = sales?.filter(s => s.is_paid).reduce((sum, s) => sum + Number(s.amount), 0) || 0;
      const unpaidSales = totalSales - paidSales;

      // Fetch counts
      const { count: userCount } = await supabase.from('users').select('*', { count: 'exact', head: true });
      const { count: branchCount } = await supabase.from('branches').select('*', { count: 'exact', head: true });
      const { count: taskCount } = await supabase.from('tasks').select('*', { count: 'exact', head: true }).eq('status', 'pending');
      const { count: complaintCount } = await supabase.from('complaints').select('*', { count: 'exact', head: true }).in('status', ['open', 'assigned', 'in_progress']);

      setStats({
        totalSales,
        paidSales,
        unpaidSales,
        totalUsers: userCount || 0,
        totalBranches: branchCount || 0,
        pendingTasks: taskCount || 0,
        openComplaints: complaintCount || 0,
        taxBucket: Number(taxBucket),
        devBucket: Number(devBucket),
        revenueBucket: Number(revenueBucket),
      });

      // Fetch pending POs from Accounts
      const { data: pos } = await supabase
        .from('purchase_orders')
        .select('*, requester:users!purchase_orders_requested_by_fkey(name)')
        .eq('status', 'pending')
        .order('created_at', { ascending: false });
      setPendingPOs(pos || []);

      // Fetch pending reports
      const { data: reps } = await supabase
        .from('reports')
        .select('*, reporter:users!reports_reported_by_fkey(name), reported_user:users!reports_reported_user_id_fkey(name)')
        .eq('status', 'pending')
        .order('created_at', { ascending: false });
      setReports(reps || []);

      // Fetch recent sales
      const { data: recentSalesData } = await supabase
        .from('sales')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(5);
      setRecentSales(recentSalesData || []);

      // Fetch recent tasks
      const { data: recentTasksData } = await supabase
        .from('tasks')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(5);
      setRecentTasks(recentTasksData || []);

      // Fetch recent activities from audit_logs
      const { data: logsData } = await supabase
        .from('audit_logs')
        .select('*, user:users(name)')
        .order('created_at', { ascending: false })
        .limit(10);
      setActivities(logsData || []);

    } catch (error) {
      console.error('Error fetching data:', error);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
    
    // Subscribe to real-time updates
    const channel = supabase
      .channel('admin-updates')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'purchase_orders' }, () => {
        fetchData();
        playSuccessChime();
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'sales' }, () => {
        fetchData();
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'reports' }, () => {
        fetchData();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const handleApprovePO = async (po: PurchaseOrder) => {
    try {
      // Get current bucket balance
      const { data: bucket } = await supabase
        .from('budget_buckets')
        .select('*')
        .eq('name', po.bucket_name)
        .single();

      if (!bucket || Number(bucket.current_balance) < po.total_amount) {
        playErrorSound();
        alert(`Insufficient balance in ${po.bucket_name} bucket! Available: ${formatCurrency(Number(bucket?.current_balance || 0))}`);
        return;
      }

      // Deduct from bucket
      const newBalance = Number(bucket.current_balance) - po.total_amount;
      await supabase
        .from('budget_buckets')
        .update({ current_balance: newBalance })
        .eq('name', po.bucket_name);

      // Update PO status
      await supabase
        .from('purchase_orders')
        .update({ 
          status: 'approved', 
          approved_at: new Date().toISOString(),
          approved_by: 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
        })
        .eq('id', po.id);

      // Add to purchase history
      await supabase.from('purchase_history').insert({
        po_id: po.id,
        bucket_name: po.bucket_name,
        amount: po.total_amount,
        items_description: po.items_description,
        approved_by: 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
      });

      // Log the action
      await supabase.from('audit_logs').insert({
        user_id: 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
        action: 'APPROVE_PO',
        entity_type: 'purchase_order',
        entity_id: po.id,
        new_data: { status: 'approved', bucket_deducted: po.bucket_name, amount: po.total_amount }
      });

      // Create notification for Inventory
      await supabase.from('notifications').insert({
        user_id: 'cccccccc-cccc-cccc-cccc-cccccccccccc',
        title: 'PO Approved',
        message: `Purchase Order ${po.po_number} has been approved. Please add items to inventory.`,
        type: 'po',
        entity_type: 'purchase_order',
        entity_id: po.id,
      });

      playApprovalSound();
      setIsPODetailOpen(false);
      setSelectedPO(null);
      fetchData();
    } catch (error) {
      console.error('Error approving PO:', error);
      playErrorSound();
    }
  };

  const handleRejectPO = async (poId: string) => {
    try {
      await supabase
        .from('purchase_orders')
        .update({ status: 'rejected' })
        .eq('id', poId);

      await supabase.from('audit_logs').insert({
        user_id: 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
        action: 'REJECT_PO',
        entity_type: 'purchase_order',
        entity_id: poId,
      });

      playErrorSound();
      setIsPODetailOpen(false);
      setSelectedPO(null);
      fetchData();
    } catch (error) {
      console.error('Error rejecting PO:', error);
    }
  };

  const handleReviewReport = async (reportId: string, action: 'approve' | 'dismiss') => {
    try {
      await supabase
        .from('reports')
        .update({ 
          status: action === 'approve' ? 'resolved' : 'dismissed',
          reviewed_at: new Date().toISOString(),
          reviewed_by: 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
        })
        .eq('id', reportId);

      if (action === 'approve') {
        playSuccessChime();
      }
      fetchData();
      fetchData();
    } catch (error) {
      console.error('Error reviewing report:', error);
    }
  };

  const handleSystemReset = async () => {
    if (resetConfirmText !== 'RESET SYSTEM') {
      alert('Please type "RESET SYSTEM" to confirm');
      return;
    }
    
    setResetting(true);
    const result = await systemReset();
    setResetting(false);
    
    if (result.success) {
      alert('System has been reset to zero. All data except admin account has been deleted.');
      setShowResetConfirm(false);
      setResetConfirmText('');
      fetchData();
    } else {
      alert('Reset failed: ' + (result.error || 'Unknown error'));
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Admin Welcome Banner */}
      <div className="bg-gradient-to-r from-purple-600/20 to-cyan-600/20 border border-purple-500/30 rounded-2xl p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-white">Admin Control Center</h2>
            <p className="text-slate-400 mt-1">Full system oversight. All activities are logged and auditable.</p>
          </div>
          <button
            onClick={() => setShowResetConfirm(true)}
            className="px-4 py-2 bg-red-600/20 border border-red-500/50 text-red-400 rounded-xl hover:bg-red-600/30 transition-all flex items-center gap-2"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
            System Reset
          </button>
        </div>
      </div>



      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Sales"
          value={formatCurrency(stats.totalSales)}
          icon={<SalesIcon size={24} />}
          color="cyan"
        />
        <StatCard
          title="Paid Sales"
          value={formatCurrency(stats.paidSales)}
          icon={<MoneyIcon size={24} />}
          color="green"
        />
        <StatCard
          title="Unpaid Sales"
          value={formatCurrency(stats.unpaidSales)}
          icon={<AlertIcon size={24} />}
          color="orange"
        />
        <StatCard
          title="Active Users"
          value={stats.totalUsers}
          icon={<UsersIcon size={24} />}
          color="purple"
        />
      </div>

      {/* Budget Buckets */}
      <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Budget Buckets (Auto-Split from Sales)</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-slate-900 rounded-xl p-4 border border-red-500/30">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm text-slate-400">TAX (10%)</span>
              <span className="text-xs px-2 py-1 bg-red-500/20 text-red-400 rounded-full">Government</span>
            </div>
            <p className="text-2xl font-bold text-red-400">{formatCurrency(stats.taxBucket)}</p>
          </div>
          
          <div className="bg-slate-900 rounded-xl p-4 border border-blue-500/30">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm text-slate-400">DEV (20%)</span>
              <span className="text-xs px-2 py-1 bg-blue-500/20 text-blue-400 rounded-full">Development</span>
            </div>
            <p className="text-2xl font-bold text-blue-400">{formatCurrency(stats.devBucket)}</p>
          </div>
          
          <div className="bg-slate-900 rounded-xl p-4 border border-green-500/30">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm text-slate-400">REVENUE (70%)</span>
              <span className="text-xs px-2 py-1 bg-green-500/20 text-green-400 rounded-full">Partners</span>
            </div>
            <p className="text-2xl font-bold text-green-400">{formatCurrency(stats.revenueBucket)}</p>
          </div>
        </div>
      </div>

      {/* Pending PO Approvals from Accounts */}
      {pendingPOs.length > 0 && (
        <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-yellow-500/30">
            <h3 className="font-semibold text-yellow-400">Pending Purchase Orders from Accounts - Requires Your Approval</h3>
          </div>
          <div className="divide-y divide-yellow-500/20">
            {pendingPOs.map(po => (
              <div key={po.id} className="p-4 flex items-center justify-between">
                <div>
                  <p className="font-medium text-white">{po.po_number}</p>
                  <p className="text-sm text-slate-400">{po.items_description || po.notes}</p>
                  <div className="flex gap-2 mt-1">
                    <span className="text-xs px-2 py-0.5 bg-slate-700 text-slate-300 rounded">
                      From: {po.requester?.name || 'Accounts'}
                    </span>
                    <span className={`text-xs px-2 py-0.5 rounded ${
                      po.bucket_name === 'TAX' ? 'bg-red-500/20 text-red-400' :
                      po.bucket_name === 'DEV' ? 'bg-blue-500/20 text-blue-400' :
                      'bg-green-500/20 text-green-400'
                    }`}>
                      Bucket: {po.bucket_name}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <p className="font-bold text-yellow-400">{formatCurrency(po.total_amount)}</p>
                  <button
                    onClick={() => { setSelectedPO(po); setIsPODetailOpen(true); }}
                    className="px-4 py-2 bg-cyan-600 text-white text-sm font-medium rounded-lg hover:bg-cyan-700"
                  >
                    Review
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Staff Reports */}
      {reports.length > 0 && (
        <div className="bg-orange-500/10 border border-orange-500/30 rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-orange-500/30">
            <h3 className="font-semibold text-orange-400">Staff Reports - Review Required</h3>
          </div>
          <div className="divide-y divide-orange-500/20">
            {reports.map(report => (
              <div key={report.id} className="p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-medium text-white">
                      {report.reporter?.name} reported {report.reported_user?.name}
                    </p>
                    <p className="text-sm text-slate-400 mt-1">{report.description}</p>
                    <p className="text-xs text-slate-500 mt-2">{new Date(report.created_at).toLocaleString()}</p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleReviewReport(report.id, 'approve')}
                      className="px-3 py-1.5 bg-green-600 text-white text-sm rounded-lg hover:bg-green-700"
                    >
                      Apply Penalty
                    </button>
                    <button
                      onClick={() => handleReviewReport(report.id, 'dismiss')}
                      className="px-3 py-1.5 bg-slate-600 text-white text-sm rounded-lg hover:bg-slate-700"
                    >
                      Dismiss
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quick Stats Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-4 flex items-center gap-4">
          <div className="p-3 bg-purple-500/20 rounded-xl">
            <BranchIcon size={24} className="text-purple-400" />
          </div>
          <div>
            <p className="text-2xl font-bold text-white">{stats.totalBranches}</p>
            <p className="text-sm text-slate-400">Branches</p>
          </div>
        </div>
        
        <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-4 flex items-center gap-4">
          <div className="p-3 bg-yellow-500/20 rounded-xl">
            <TaskIcon size={24} className="text-yellow-400" />
          </div>
          <div>
            <p className="text-2xl font-bold text-white">{stats.pendingTasks}</p>
            <p className="text-sm text-slate-400">Pending Tasks</p>
          </div>
        </div>
        
        <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-4 flex items-center gap-4">
          <div className="p-3 bg-red-500/20 rounded-xl">
            <AlertIcon size={24} className="text-red-400" />
          </div>
          <div>
            <p className="text-2xl font-bold text-white">{stats.openComplaints}</p>
            <p className="text-sm text-slate-400">Open Complaints</p>
          </div>
        </div>
        
        <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-4 flex items-center gap-4">
          <div className="p-3 bg-cyan-500/20 rounded-xl">
            <TrendUpIcon size={24} className="text-cyan-400" />
          </div>
          <div>
            <p className="text-2xl font-bold text-white">{pendingPOs.length}</p>
            <p className="text-sm text-slate-400">Pending POs</p>
          </div>
        </div>
      </div>

      {/* Recent Activity Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-slate-800/50 border border-slate-700 rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-700">
            <h3 className="font-semibold text-white">Recent Sales</h3>
          </div>
          <div className="divide-y divide-slate-700/50">
            {recentSales.length === 0 ? (
              <p className="p-4 text-slate-400 text-center">No sales yet</p>
            ) : (
              recentSales.map((sale) => (
                <div key={sale.id} className="p-4 flex items-center justify-between">
                  <div>
                    <p className="font-medium text-white">{sale.sale_number}</p>
                    <p className="text-sm text-slate-400">{sale.customer_name}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-white">{formatCurrency(Number(sale.amount))}</p>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${
                      sale.is_paid ? 'bg-green-500/20 text-green-400' : 'bg-orange-500/20 text-orange-400'
                    }`}>
                      {sale.is_paid ? 'Paid' : 'Unpaid'}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
        
        <div className="bg-slate-800/50 border border-slate-700 rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-700">
            <h3 className="font-semibold text-white">Recent Activities</h3>
          </div>
          <div className="divide-y divide-slate-700/50 max-h-80 overflow-y-auto">
            {activities.length === 0 ? (
              <p className="p-4 text-slate-400 text-center">No activities yet</p>
            ) : (
              activities.map((activity) => (
                <div key={activity.id} className="p-4">
                  <div className="flex items-center gap-2">
                    <span className="text-cyan-400 font-medium">{activity.user?.name || 'System'}</span>
                    <span className="text-slate-400">{activity.action}</span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    {activity.entity_type} • {new Date(activity.created_at).toLocaleString()}
                  </p>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* PO Review Modal */}
      <Modal isOpen={isPODetailOpen} onClose={() => setIsPODetailOpen(false)} title="Review Purchase Order">
        {selectedPO && (
          <div className="space-y-4">
            <div className="bg-slate-800 border border-slate-700 rounded-xl p-4 space-y-3">
              <div className="flex justify-between">
                <span className="text-slate-400">PO Number:</span>
                <span className="text-white font-medium">{selectedPO.po_number}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Requested By:</span>
                <span className="text-white">{selectedPO.requester?.name || 'Accounts'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Items:</span>
                <span className="text-white">{selectedPO.items_description || selectedPO.notes}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Budget Bucket:</span>
                <span className={`font-medium ${
                  selectedPO.bucket_name === 'TAX' ? 'text-red-400' :
                  selectedPO.bucket_name === 'DEV' ? 'text-blue-400' :
                  'text-green-400'
                }`}>{selectedPO.bucket_name}</span>
              </div>
              <div className="flex justify-between border-t border-slate-700 pt-3">
                <span className="text-slate-400">Total Amount:</span>
                <span className="text-cyan-400 font-bold text-lg">{formatCurrency(selectedPO.total_amount)}</span>
              </div>
            </div>
            
            <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-xl p-3 text-sm text-yellow-400">
              Approving will deduct {formatCurrency(selectedPO.total_amount)} from the {selectedPO.bucket_name} bucket.
            </div>
            
            <div className="flex gap-3">
              <button
                onClick={() => handleApprovePO(selectedPO)}
                className="flex-1 py-3 bg-green-600 text-white font-medium rounded-xl hover:bg-green-700 transition-all flex items-center justify-center gap-2"
              >
                <CheckIcon size={20} />
                Approve PO
              </button>
              <button
                onClick={() => handleRejectPO(selectedPO.id)}
                className="flex-1 py-3 bg-red-600 text-white font-medium rounded-xl hover:bg-red-700 transition-all"
              >
                Reject PO
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* System Reset Confirmation Modal */}
      <Modal isOpen={showResetConfirm} onClose={() => { setShowResetConfirm(false); setResetConfirmText(''); }} title="System Reset">
        <div className="space-y-4">
          <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-4">
            <p className="text-red-400 font-medium mb-2">Warning: This action cannot be undone!</p>
            <p className="text-slate-400 text-sm">
              This will delete ALL data including:
            </p>
            <ul className="text-slate-400 text-sm mt-2 list-disc list-inside space-y-1">
              <li>All users (except admin)</li>
              <li>All branches</li>
              <li>All sales records</li>
              <li>All inventory items</li>
              <li>All tasks and complaints</li>
              <li>All audit logs</li>
              <li>Reset all budget buckets to zero</li>
            </ul>
          </div>
          
          <div>
            <label className="block text-sm text-slate-400 mb-2">
              Type <span className="text-red-400 font-mono">RESET SYSTEM</span> to confirm:
            </label>
            <input
              type="text"
              value={resetConfirmText}
              onChange={(e) => setResetConfirmText(e.target.value)}
              className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-red-500"
              placeholder="RESET SYSTEM"
            />
          </div>
          
          <div className="flex gap-3">
            <button
              onClick={() => { setShowResetConfirm(false); setResetConfirmText(''); }}
              className="flex-1 py-3 bg-slate-700 text-white font-medium rounded-xl hover:bg-slate-600"
            >
              Cancel
            </button>
            <button
              onClick={handleSystemReset}
              disabled={resetting || resetConfirmText !== 'RESET SYSTEM'}
              className="flex-1 py-3 bg-red-600 text-white font-medium rounded-xl hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {resetting ? 'Resetting...' : 'Reset System'}
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default AdminDashboard;
