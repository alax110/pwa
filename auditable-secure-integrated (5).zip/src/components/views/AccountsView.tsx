import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Sale, CashHandover, BudgetBucket, Partner, User } from '@/types';
import StatCard from '../StatCard';
import DataTable from '../DataTable';
import { MoneyIcon, TrendUpIcon, AlertIcon, CheckIcon, PartnerIcon } from '../ui/Icons';

const AccountsView: React.FC = () => {
  const [sales, setSales] = useState<Sale[]>([]);
  const [handovers, setHandovers] = useState<CashHandover[]>([]);
  const [buckets, setBuckets] = useState<BudgetBucket[]>([]);
  const [partners, setPartners] = useState<Partner[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'overview' | 'reconciliation' | 'partners'>('overview');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [salesRes, handoversRes, bucketsRes, partnersRes, usersRes] = await Promise.all([
        supabase.from('sales').select('*').order('created_at', { ascending: false }),
        supabase.from('cash_handovers').select('*').order('created_at', { ascending: false }),
        supabase.from('budget_buckets').select('*'),
        supabase.from('partners').select('*'),
        supabase.from('users').select('*'),
      ]);

      setSales(salesRes.data || []);
      setHandovers(handoversRes.data || []);
      setBuckets(bucketsRes.data || []);
      setPartners(partnersRes.data || []);
      setUsers(usersRes.data || []);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US').format(amount) + ' AFN';
  };

  const getUserName = (id: string) => users.find(u => u.id === id)?.name || '-';

  // Calculate totals
  const totalSales = sales.reduce((sum, s) => sum + parseFloat(String(s.amount)), 0);
  const paidSales = sales.filter(s => s.is_paid).reduce((sum, s) => sum + parseFloat(String(s.amount)), 0);
  const unpaidSales = sales.filter(s => !s.is_paid).reduce((sum, s) => sum + parseFloat(String(s.amount)), 0);
  
  const confirmedHandovers = handovers.filter(h => h.status === 'confirmed');
  const totalConfirmed = confirmedHandovers.reduce((sum, h) => sum + parseFloat(String(h.amount)), 0);
  
  const taxBucket = buckets.find(b => b.name === 'TAX');
  const devBucket = buckets.find(b => b.name === 'DEV');
  const revenueBucket = buckets.find(b => b.name === 'REVENUE');

  // Reconciliation check
  const discrepancy = paidSales - totalConfirmed;

  const salesColumns = [
    { key: 'sale_number', label: 'Sale #' },
    { key: 'customer_name', label: 'Customer' },
    { 
      key: 'amount', 
      label: 'Amount',
      render: (item: Sale) => formatCurrency(parseFloat(String(item.amount)))
    },
    { 
      key: 'tax_amount', 
      label: 'TAX (10%)',
      render: (item: Sale) => <span className="text-red-400">{formatCurrency(parseFloat(String(item.tax_amount)))}</span>
    },
    { 
      key: 'dev_amount', 
      label: 'DEV (20%)',
      render: (item: Sale) => <span className="text-blue-400">{formatCurrency(parseFloat(String(item.dev_amount)))}</span>
    },
    { 
      key: 'revenue_amount', 
      label: 'REV (70%)',
      render: (item: Sale) => <span className="text-green-400">{formatCurrency(parseFloat(String(item.revenue_amount)))}</span>
    },
    { 
      key: 'is_paid', 
      label: 'Status',
      render: (item: Sale) => (
        <span className={`px-2 py-1 text-xs rounded-full border ${
          item.is_paid 
            ? 'bg-green-500/20 text-green-400 border-green-500/30' 
            : 'bg-orange-500/20 text-orange-400 border-orange-500/30'
        }`}>
          {item.is_paid ? 'Paid' : 'Unpaid'}
        </span>
      )
    },
  ];

  const partnerColumns = [
    { key: 'name', label: 'Partner' },
    { 
      key: 'revenue_share_percent', 
      label: 'Share %',
      render: (item: Partner) => `${item.revenue_share_percent}%`
    },
    { 
      key: 'total_earnings', 
      label: 'Total Earnings',
      render: (item: Partner) => formatCurrency(parseFloat(String(item.total_earnings)))
    },
    { 
      key: 'withdrawn', 
      label: 'Withdrawn',
      render: (item: Partner) => formatCurrency(parseFloat(String(item.withdrawn)))
    },
    { 
      key: 'balance', 
      label: 'Balance',
      render: (item: Partner) => {
        const balance = parseFloat(String(item.total_earnings)) - parseFloat(String(item.withdrawn));
        return <span className="font-medium text-green-400">{formatCurrency(balance)}</span>;
      }
    },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Tabs */}
      <div className="flex gap-2 border-b border-slate-700 pb-4">
        {(['overview', 'reconciliation', 'partners'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 rounded-xl font-medium transition-all capitalize ${
              activeTab === tab
                ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {activeTab === 'overview' && (
        <>
          {/* Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard
              title="Total Revenue"
              value={formatCurrency(totalSales)}
              icon={<MoneyIcon size={24} />}
              color="cyan"
              trend={{ value: 15, isPositive: true }}
            />
            <StatCard
              title="Collected"
              value={formatCurrency(paidSales)}
              icon={<CheckIcon size={24} />}
              color="green"
            />
            <StatCard
              title="Outstanding"
              value={formatCurrency(unpaidSales)}
              icon={<AlertIcon size={24} />}
              color="orange"
            />
            <StatCard
              title="Cash Confirmed"
              value={formatCurrency(totalConfirmed)}
              icon={<CashIcon size={24} />}
              color="purple"
            />
          </div>

          {/* Budget Buckets */}
          <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Budget Buckets</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-slate-900 rounded-xl p-5 border border-red-500/30">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-sm text-slate-400">TAX Bucket</p>
                    <p className="text-xs text-slate-500">10% of all sales</p>
                  </div>
                  <span className="px-2 py-1 text-xs bg-red-500/20 text-red-400 rounded-full">Government</span>
                </div>
                <p className="text-3xl font-bold text-white mb-2">
                  {formatCurrency(parseFloat(String(taxBucket?.current_balance || 0)))}
                </p>
                <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-red-500 to-red-600 rounded-full" style={{ width: '10%' }} />
                </div>
              </div>
              
              <div className="bg-slate-900 rounded-xl p-5 border border-blue-500/30">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-sm text-slate-400">DEV Bucket</p>
                    <p className="text-xs text-slate-500">20% of all sales</p>
                  </div>
                  <span className="px-2 py-1 text-xs bg-blue-500/20 text-blue-400 rounded-full">Development</span>
                </div>
                <p className="text-3xl font-bold text-white mb-2">
                  {formatCurrency(parseFloat(String(devBucket?.current_balance || 0)))}
                </p>
                <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-blue-500 to-blue-600 rounded-full" style={{ width: '20%' }} />
                </div>
              </div>
              
              <div className="bg-slate-900 rounded-xl p-5 border border-green-500/30">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-sm text-slate-400">REVENUE Bucket</p>
                    <p className="text-xs text-slate-500">70% of all sales</p>
                  </div>
                  <span className="px-2 py-1 text-xs bg-green-500/20 text-green-400 rounded-full">Partners</span>
                </div>
                <p className="text-3xl font-bold text-white mb-2">
                  {formatCurrency(parseFloat(String(revenueBucket?.current_balance || 0)))}
                </p>
                <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-green-500 to-green-600 rounded-full" style={{ width: '70%' }} />
                </div>
              </div>
            </div>
          </div>

          {/* Sales with Split */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Sales Revenue Split</h3>
            <DataTable
              columns={salesColumns}
              data={sales.slice(0, 10)}
              emptyMessage="No sales data"
            />
          </div>
        </>
      )}

      {activeTab === 'reconciliation' && (
        <>
          {/* Reconciliation Status */}
          <div className={`p-6 rounded-2xl border ${
            Math.abs(discrepancy) < 1 
              ? 'bg-green-500/10 border-green-500/30' 
              : 'bg-red-500/10 border-red-500/30'
          }`}>
            <div className="flex items-center gap-4">
              {Math.abs(discrepancy) < 1 ? (
                <CheckIcon size={32} className="text-green-400" />
              ) : (
                <AlertIcon size={32} className="text-red-400" />
              )}
              <div>
                <h3 className="text-lg font-semibold text-white">
                  {Math.abs(discrepancy) < 1 ? 'Reconciliation Complete' : 'Discrepancy Detected'}
                </h3>
                <p className="text-sm text-slate-400">
                  Paid Sales: {formatCurrency(paidSales)} | Cash Confirmed: {formatCurrency(totalConfirmed)}
                </p>
                {Math.abs(discrepancy) >= 1 && (
                  <p className="text-sm text-red-400 mt-1">
                    Difference: {formatCurrency(Math.abs(discrepancy))} {discrepancy > 0 ? '(Cash Missing)' : '(Excess Cash)'}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Comparison Table */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-4">
              <h4 className="font-medium text-white mb-4">Paid Sales</h4>
              <div className="space-y-2">
                {sales.filter(s => s.is_paid).slice(0, 8).map(sale => (
                  <div key={sale.id} className="flex items-center justify-between py-2 border-b border-slate-700/50">
                    <div>
                      <p className="text-sm text-white">{sale.sale_number}</p>
                      <p className="text-xs text-slate-500">{sale.customer_name}</p>
                    </div>
                    <span className="text-sm font-medium text-green-400">
                      {formatCurrency(parseFloat(String(sale.amount)))}
                    </span>
                  </div>
                ))}
              </div>
              <div className="mt-4 pt-4 border-t border-slate-700 flex justify-between">
                <span className="font-medium text-white">Total Paid</span>
                <span className="font-bold text-green-400">{formatCurrency(paidSales)}</span>
              </div>
            </div>

            <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-4">
              <h4 className="font-medium text-white mb-4">Confirmed Cash Handovers</h4>
              <div className="space-y-2">
                {confirmedHandovers.slice(0, 8).map(handover => (
                  <div key={handover.id} className="flex items-center justify-between py-2 border-b border-slate-700/50">
                    <div>
                      <p className="text-sm text-white">{handover.handover_number}</p>
                      <p className="text-xs text-slate-500">{getUserName(handover.handed_by)}</p>
                    </div>
                    <span className="text-sm font-medium text-cyan-400">
                      {formatCurrency(parseFloat(String(handover.amount)))}
                    </span>
                  </div>
                ))}
              </div>
              <div className="mt-4 pt-4 border-t border-slate-700 flex justify-between">
                <span className="font-medium text-white">Total Confirmed</span>
                <span className="font-bold text-cyan-400">{formatCurrency(totalConfirmed)}</span>
              </div>
            </div>
          </div>
        </>
      )}

      {activeTab === 'partners' && (
        <>
          {/* Partner Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <StatCard
              title="Total Partners"
              value={partners.length}
              icon={<PartnerIcon size={24} />}
              color="purple"
            />
            <StatCard
              title="Total Distributed"
              value={formatCurrency(partners.reduce((sum, p) => sum + parseFloat(String(p.total_earnings)), 0))}
              icon={<MoneyIcon size={24} />}
              color="green"
            />
            <StatCard
              title="Pending Withdrawals"
              value={formatCurrency(partners.reduce((sum, p) => sum + (parseFloat(String(p.total_earnings)) - parseFloat(String(p.withdrawn))), 0))}
              icon={<TrendUpIcon size={24} />}
              color="cyan"
            />
          </div>

          {/* Partner Revenue Share */}
          <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Revenue Distribution (70% Bucket)</h3>
            <div className="space-y-4">
              {partners.map(partner => {
                const balance = parseFloat(String(partner.total_earnings)) - parseFloat(String(partner.withdrawn));
                return (
                  <div key={partner.id} className="bg-slate-900 rounded-xl p-4 border border-slate-700">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <p className="font-medium text-white">{partner.name}</p>
                        <p className="text-sm text-slate-400">{partner.email}</p>
                      </div>
                      <span className="px-3 py-1 bg-purple-500/20 text-purple-400 rounded-full text-sm font-medium">
                        {partner.revenue_share_percent}% Share
                      </span>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div>
                        <p className="text-xs text-slate-500">Total Earned</p>
                        <p className="text-lg font-bold text-white">{formatCurrency(parseFloat(String(partner.total_earnings)))}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500">Withdrawn</p>
                        <p className="text-lg font-bold text-slate-400">{formatCurrency(parseFloat(String(partner.withdrawn)))}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500">Available</p>
                        <p className="text-lg font-bold text-green-400">{formatCurrency(balance)}</p>
                      </div>
                    </div>
                    <div className="mt-3 h-2 bg-slate-700 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full" 
                        style={{ width: `${partner.revenue_share_percent}%` }} 
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <DataTable
            columns={partnerColumns}
            data={partners}
            emptyMessage="No partners configured"
          />
        </>
      )}
    </div>
  );
};

export default AccountsView;

const CashIcon: React.FC<{ size?: number; className?: string }> = ({ size = 24, className = '' }) => (
  <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="1" y="4" width="22" height="16" rx="2" ry="2" />
    <circle cx="12" cy="12" r="3" />
  </svg>
);
