import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { InventoryItem, Branch, User } from '@/types';
import DataTable from '../DataTable';
import StatCard from '../StatCard';
import { InventoryIcon, TrendUpIcon, TrendDownIcon, CalendarIcon } from '../ui/Icons';

interface LedgerEntry {
  id: string;
  item_id: string;
  branch_id: string;
  movement_type: 'IN' | 'OUT';
  quantity: number;
  reference_type?: string;
  reference_id?: string;
  notes?: string;
  performed_by?: string;
  created_at: string;
}

const StockLedgerView: React.FC = () => {
  const [ledger, setLedger] = useState<LedgerEntry[]>([]);
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterItem, setFilterItem] = useState('');
  const [filterBranch, setFilterBranch] = useState('');
  const [filterType, setFilterType] = useState('');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [ledgerRes, itemsRes, branchesRes, usersRes] = await Promise.all([
        supabase.from('stock_ledger').select('*').order('created_at', { ascending: false }),
        supabase.from('inventory_items').select('*'),
        supabase.from('branches').select('*'),
        supabase.from('users').select('*'),
      ]);
      setLedger(ledgerRes.data || []);
      setItems(itemsRes.data || []);
      setBranches(branchesRes.data || []);
      setUsers(usersRes.data || []);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getItemName = (id: string) => items.find(i => i.id === id)?.name || '-';
  const getBranchName = (id: string) => branches.find(b => b.id === id)?.name || '-';
  const getUserName = (id: string) => users.find(u => u.id === id)?.name || 'System';

  const filteredLedger = ledger.filter(entry => {
    if (filterItem && entry.item_id !== filterItem) return false;
    if (filterBranch && entry.branch_id !== filterBranch) return false;
    if (filterType && entry.movement_type !== filterType) return false;
    return true;
  });

  const totalIn = ledger.filter(l => l.movement_type === 'IN').reduce((sum, l) => sum + l.quantity, 0);
  const totalOut = ledger.filter(l => l.movement_type === 'OUT').reduce((sum, l) => sum + l.quantity, 0);
  const todayMovements = ledger.filter(l => 
    new Date(l.created_at).toDateString() === new Date().toDateString()
  ).length;

  const columns = [
    {
      key: 'created_at',
      label: 'Date/Time',
      render: (item: LedgerEntry) => (
        <div>
          <p className="text-sm text-white">{new Date(item.created_at).toLocaleDateString()}</p>
          <p className="text-xs text-slate-500">{new Date(item.created_at).toLocaleTimeString()}</p>
        </div>
      )
    },
    {
      key: 'movement_type',
      label: 'Type',
      render: (item: LedgerEntry) => (
        <span className={`px-2 py-1 text-xs rounded-full border flex items-center gap-1 w-fit ${
          item.movement_type === 'IN' 
            ? 'bg-green-500/20 text-green-400 border-green-500/30' 
            : 'bg-red-500/20 text-red-400 border-red-500/30'
        }`}>
          {item.movement_type === 'IN' ? <TrendUpIcon size={12} /> : <TrendDownIcon size={12} />}
          {item.movement_type}
        </span>
      )
    },
    {
      key: 'item_id',
      label: 'Item',
      render: (item: LedgerEntry) => getItemName(item.item_id)
    },
    {
      key: 'quantity',
      label: 'Quantity',
      render: (item: LedgerEntry) => (
        <span className={`font-medium ${
          item.movement_type === 'IN' ? 'text-green-400' : 'text-red-400'
        }`}>
          {item.movement_type === 'IN' ? '+' : '-'}{item.quantity}
        </span>
      )
    },
    {
      key: 'branch_id',
      label: 'Branch',
      render: (item: LedgerEntry) => getBranchName(item.branch_id)
    },
    {
      key: 'reference_type',
      label: 'Reference',
      render: (item: LedgerEntry) => (
        <span className="text-xs text-slate-400">
          {item.reference_type || 'Manual'}
        </span>
      )
    },
    {
      key: 'performed_by',
      label: 'By',
      render: (item: LedgerEntry) => getUserName(item.performed_by || '')
    },
    {
      key: 'notes',
      label: 'Notes',
      render: (item: LedgerEntry) => (
        <span className="text-xs text-slate-500 truncate max-w-[150px] block">
          {item.notes || '-'}
        </span>
      )
    },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <StatCard
          title="Total Movements"
          value={ledger.length}
          icon={<InventoryIcon size={24} />}
          color="cyan"
        />
        <StatCard
          title="Stock In"
          value={totalIn}
          subtitle="Units received"
          icon={<TrendUpIcon size={24} />}
          color="green"
        />
        <StatCard
          title="Stock Out"
          value={totalOut}
          subtitle="Units issued"
          icon={<TrendDownIcon size={24} />}
          color="red"
        />
        <StatCard
          title="Today's Movements"
          value={todayMovements}
          icon={<CalendarIcon size={24} />}
          color="purple"
        />
      </div>

      {/* Header & Filters */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white">Stock Ledger</h2>
          <p className="text-sm text-slate-400">Complete history of all stock movements</p>
        </div>
        
        <div className="flex flex-wrap gap-3">
          <select
            value={filterItem}
            onChange={(e) => setFilterItem(e.target.value)}
            className="px-4 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500"
          >
            <option value="">All Items</option>
            {items.map(item => (
              <option key={item.id} value={item.id}>{item.name}</option>
            ))}
          </select>
          
          <select
            value={filterBranch}
            onChange={(e) => setFilterBranch(e.target.value)}
            className="px-4 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500"
          >
            <option value="">All Branches</option>
            {branches.map(branch => (
              <option key={branch.id} value={branch.id}>{branch.name}</option>
            ))}
          </select>
          
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="px-4 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500"
          >
            <option value="">All Types</option>
            <option value="IN">Stock In</option>
            <option value="OUT">Stock Out</option>
          </select>
        </div>
      </div>

      {/* Info Box */}
      <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-xl p-4">
        <p className="text-sm text-cyan-400">
          <span className="font-medium">Full Stock Traceability:</span> Every item movement is recorded here. 
          If an item leaves inventory, there must be a ledger entry. No missing stock, no unexplained losses.
        </p>
      </div>

      {/* Summary by Item */}
      <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Movement Summary by Item</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {items.slice(0, 6).map(item => {
            const itemLedger = ledger.filter(l => l.item_id === item.id);
            const inQty = itemLedger.filter(l => l.movement_type === 'IN').reduce((sum, l) => sum + l.quantity, 0);
            const outQty = itemLedger.filter(l => l.movement_type === 'OUT').reduce((sum, l) => sum + l.quantity, 0);
            return (
              <div key={item.id} className="bg-slate-900 rounded-xl p-4 border border-slate-700">
                <h4 className="font-medium text-white mb-3">{item.name}</h4>
                <div className="flex justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <TrendUpIcon size={14} className="text-green-400" />
                    <span className="text-green-400">+{inQty}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <TrendDownIcon size={14} className="text-red-400" />
                    <span className="text-red-400">-{outQty}</span>
                  </div>
                  <div>
                    <span className="text-slate-400">Net: </span>
                    <span className={inQty - outQty >= 0 ? 'text-green-400' : 'text-red-400'}>
                      {inQty - outQty >= 0 ? '+' : ''}{inQty - outQty}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <DataTable
        columns={columns}
        data={filteredLedger}
        searchable
        searchPlaceholder="Search ledger..."
        emptyMessage="No stock movements found"
      />
    </div>
  );
};

export default StockLedgerView;
