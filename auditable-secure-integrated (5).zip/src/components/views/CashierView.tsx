import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { CashHandover, Branch, User } from '@/types';
import DataTable from '../DataTable';
import Modal from '../Modal';
import StatCard from '../StatCard';
import { PlusIcon, CashIcon, CheckIcon, AlertIcon, PrintIcon } from '../ui/Icons';

const CashierView: React.FC = () => {
  const { currentUser } = useAuth();
  const [handovers, setHandovers] = useState<CashHandover[]>([]);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    amount: '',
    branch_id: '',
    notes: '',
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [handoversRes, branchesRes, usersRes] = await Promise.all([
        supabase.from('cash_handovers').select('*').order('created_at', { ascending: false }),
        supabase.from('branches').select('*'),
        supabase.from('users').select('*'),
      ]);

      setHandovers(handoversRes.data || []);
      setBranches(branchesRes.data || []);
      setUsers(usersRes.data || []);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await supabase.from('cash_handovers').insert({
        handover_number: `CH-${Date.now()}`,
        branch_id: formData.branch_id || currentUser?.branch_id,
        handed_by: currentUser?.id,
        amount: parseFloat(formData.amount),
        status: 'pending',
        notes: formData.notes,
      });

      setIsModalOpen(false);
      resetForm();
      fetchData();
    } catch (error) {
      console.error('Error creating handover:', error);
    }
  };

  const handleConfirm = async (handover: CashHandover) => {
    try {
      await supabase
        .from('cash_handovers')
        .update({
          status: 'confirmed',
          received_by: currentUser?.id,
          confirmed_at: new Date().toISOString(),
        })
        .eq('id', handover.id);
      fetchData();
    } catch (error) {
      console.error('Error confirming handover:', error);
    }
  };

  const handleDiscrepancy = async (handover: CashHandover) => {
    const notes = prompt('Enter discrepancy notes:');
    if (notes) {
      try {
        await supabase
          .from('cash_handovers')
          .update({
            status: 'discrepancy',
            received_by: currentUser?.id,
            notes: `${handover.notes || ''}\nDISCREPANCY: ${notes}`,
          })
          .eq('id', handover.id);
        fetchData();
      } catch (error) {
        console.error('Error marking discrepancy:', error);
      }
    }
  };

  const resetForm = () => {
    setFormData({
      amount: '',
      branch_id: '',
      notes: '',
    });
  };

  const getUserName = (id: string) => {
    return users.find(u => u.id === id)?.name || '-';
  };

  const getBranchName = (id: string) => {
    return branches.find(b => b.id === id)?.name || '-';
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US').format(amount) + ' AFN';
  };

  const pendingHandovers = handovers.filter(h => h.status === 'pending');
  const confirmedHandovers = handovers.filter(h => h.status === 'confirmed');
  const discrepancyHandovers = handovers.filter(h => h.status === 'discrepancy');
  
  const totalPending = pendingHandovers.reduce((sum, h) => sum + parseFloat(String(h.amount)), 0);
  const totalConfirmed = confirmedHandovers.reduce((sum, h) => sum + parseFloat(String(h.amount)), 0);

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      pending: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
      confirmed: 'bg-green-500/20 text-green-400 border-green-500/30',
      discrepancy: 'bg-red-500/20 text-red-400 border-red-500/30',
    };
    return colors[status] || colors.pending;
  };

  const columns = [
    { key: 'handover_number', label: 'Handover #' },
    { 
      key: 'branch_id', 
      label: 'Branch',
      render: (item: CashHandover) => getBranchName(item.branch_id)
    },
    { 
      key: 'handed_by', 
      label: 'Handed By',
      render: (item: CashHandover) => getUserName(item.handed_by)
    },
    { 
      key: 'amount', 
      label: 'Amount',
      render: (item: CashHandover) => (
        <span className="font-medium text-white">{formatCurrency(parseFloat(String(item.amount)))}</span>
      )
    },
    { 
      key: 'status', 
      label: 'Status',
      render: (item: CashHandover) => (
        <span className={`px-2 py-1 text-xs rounded-full border ${getStatusColor(item.status)}`}>
          {item.status}
        </span>
      )
    },
    {
      key: 'created_at',
      label: 'Date',
      render: (item: CashHandover) => new Date(item.created_at).toLocaleDateString()
    },
    {
      key: 'actions',
      label: 'Actions',
      render: (item: CashHandover) => (
        <div className="flex items-center gap-2">
          {item.status === 'pending' && currentUser?.role === 'cashier' && (
            <>
              <button
                onClick={(e) => { e.stopPropagation(); handleConfirm(item); }}
                className="px-2 py-1 text-xs bg-green-500/20 text-green-400 rounded-lg hover:bg-green-500/30 transition-all"
              >
                Confirm
              </button>
              <button
                onClick={(e) => { e.stopPropagation(); handleDiscrepancy(item); }}
                className="px-2 py-1 text-xs bg-red-500/20 text-red-400 rounded-lg hover:bg-red-500/30 transition-all"
              >
                Discrepancy
              </button>
            </>
          )}
          <button
            onClick={(e) => { e.stopPropagation(); window.print(); }}
            className="p-1.5 text-slate-400 hover:text-cyan-400 hover:bg-slate-700 rounded-lg transition-all"
          >
            <PrintIcon size={16} />
          </button>
        </div>
      )
    },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <StatCard
          title="Total Handovers"
          value={handovers.length}
          icon={<CashIcon size={24} />}
          color="cyan"
        />
        <StatCard
          title="Pending"
          value={formatCurrency(totalPending)}
          subtitle={`${pendingHandovers.length} waiting`}
          icon={<AlertIcon size={24} />}
          color="yellow"
        />
        <StatCard
          title="Confirmed Today"
          value={formatCurrency(totalConfirmed)}
          subtitle={`${confirmedHandovers.length} confirmed`}
          icon={<CheckIcon size={24} />}
          color="green"
        />
        <StatCard
          title="Discrepancies"
          value={discrepancyHandovers.length}
          icon={<AlertIcon size={24} />}
          color={discrepancyHandovers.length > 0 ? 'red' : 'green'}
        />
      </div>

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white">Cash Handover</h2>
          <p className="text-sm text-slate-400">
            {currentUser?.role === 'cashier' 
              ? 'Receive and confirm cash from branches' 
              : 'Submit cash handover to cashier'}
          </p>
        </div>
        {currentUser?.role === 'branch_sales' && (
          <button
            onClick={() => { resetForm(); setIsModalOpen(true); }}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium rounded-xl hover:from-cyan-600 hover:to-blue-700 transition-all"
          >
            <PlusIcon size={20} />
            New Handover
          </button>
        )}
      </div>

      {/* Pending Queue for Cashier */}
      {currentUser?.role === 'cashier' && pendingHandovers.length > 0 && (
        <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-2xl p-4">
          <h3 className="text-lg font-semibold text-yellow-400 mb-4">Pending Cash Queue</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {pendingHandovers.map(handover => (
              <div key={handover.id} className="bg-slate-900 border border-slate-700 rounded-xl p-4">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <p className="text-sm text-slate-400">{handover.handover_number}</p>
                    <p className="text-lg font-bold text-white">{formatCurrency(parseFloat(String(handover.amount)))}</p>
                  </div>
                  <span className="px-2 py-1 text-xs bg-yellow-500/20 text-yellow-400 rounded-full">Pending</span>
                </div>
                <p className="text-sm text-slate-400 mb-1">From: {getUserName(handover.handed_by)}</p>
                <p className="text-sm text-slate-400 mb-3">Branch: {getBranchName(handover.branch_id)}</p>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleConfirm(handover)}
                    className="flex-1 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700 transition-all"
                  >
                    Confirm Receipt
                  </button>
                  <button
                    onClick={() => handleDiscrepancy(handover)}
                    className="px-3 py-2 bg-red-600/20 text-red-400 text-sm font-medium rounded-lg hover:bg-red-600/30 transition-all"
                  >
                    Issue
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <DataTable
        columns={columns}
        data={handovers}
        searchable
        searchPlaceholder="Search handovers..."
        emptyMessage="No cash handovers found"
      />

      {/* New Handover Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Create Cash Handover"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="bg-slate-800 border border-slate-700 rounded-xl p-4 mb-4">
            <p className="text-sm text-slate-400">
              Create a cash handover receipt to submit to the cashier. 
              The cashier will verify and confirm the received amount.
            </p>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Amount (AFN) *</label>
            <input
              type="number"
              value={formData.amount}
              onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              required
              min="0"
              placeholder="Enter cash amount"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Branch</label>
            <select
              value={formData.branch_id}
              onChange={(e) => setFormData({ ...formData, branch_id: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
            >
              <option value="">Current Branch</option>
              {branches.map((branch) => (
                <option key={branch.id} value={branch.id}>{branch.name}</option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Notes</label>
            <textarea
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              rows={3}
              placeholder="Any additional notes..."
            />
          </div>
          
          <div className="flex justify-end gap-3 pt-4">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 text-slate-400 hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium rounded-xl hover:from-cyan-600 hover:to-blue-700 transition-all"
            >
              Create Handover
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default CashierView;
