import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { playSuccessChime, playTaskSound } from '@/lib/notifications';
import StatCard from '../StatCard';
import Modal from '../Modal';
import { TaskIcon, AlertIcon, CheckIcon, ClockIcon } from '../ui/Icons';

const EngineerDashboard: React.FC = () => {
  const { currentUser } = useAuth();
  const [loading, setLoading] = useState(true);
  const [isCheckedIn, setIsCheckedIn] = useState(false);
  const [myComplaints, setMyComplaints] = useState<any[]>([]);
  const [myTasks, setMyTasks] = useState<any[]>([]);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [reportForm, setReportForm] = useState({ reported_user_id: '', category: '', description: '' });
  const [nocUsers, setNocUsers] = useState<any[]>([]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const userId = currentUser?.id || '00000000-0000-0000-0000-000000000001';
      const today = new Date().toISOString().split('T')[0];
      const { data: attendance } = await supabase.from('attendance').select('*').eq('user_id', userId).eq('date', today).single();
      setIsCheckedIn(!!attendance);
      const { data: complaints } = await supabase.from('complaints').select('*').eq('assigned_to', userId).in('status', ['assigned', 'in_progress']).order('created_at', { ascending: false });
      setMyComplaints(complaints || []);
      const { data: tasks } = await supabase.from('tasks').select('*').eq('assigned_to', userId).in('status', ['pending', 'in_progress']).order('created_at', { ascending: false });
      setMyTasks(tasks || []);
      const { data: nocs } = await supabase.from('users').select('*').eq('role', 'noc');
      setNocUsers(nocs || []);
    } catch (error) { console.error('Error:', error); }
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
    const channel = supabase.channel('engineer-updates')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'complaints' }, () => { fetchData(); playTaskSound(); })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'tasks' }, () => { fetchData(); playTaskSound(); })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [currentUser]);

  const handleCheckIn = async () => {
    try {
      const userId = currentUser?.id || '00000000-0000-0000-0000-000000000001';
      const now = new Date();
      const isLate = now.getHours() >= 8 && now.getMinutes() > 15;
      await supabase.from('attendance').insert({ user_id: userId, date: now.toISOString().split('T')[0], check_in: now.toISOString(), status: isLate ? 'late' : 'present' });
      playSuccessChime();
      setIsCheckedIn(true);
      fetchData();
    } catch (error) { console.error('Error:', error); }
  };

  const handleCompleteComplaint = async (complaint: any) => {
    try {
      await supabase.from('complaints').update({ status: 'resolved', resolved_at: new Date().toISOString() }).eq('id', complaint.id);
      playSuccessChime();
      fetchData();
    } catch (error) { console.error('Error:', error); }
  };

  const handleCompleteTask = async (task: any) => {
    try {
      await supabase.from('tasks').update({ status: 'completed', completed_at: new Date().toISOString() }).eq('id', task.id);
      playSuccessChime();
      fetchData();
    } catch (error) { console.error('Error:', error); }
  };

  const handleReportNOC = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await supabase.from('reports').insert({ reported_by: currentUser?.id || '00000000-0000-0000-0000-000000000001', reported_user_id: reportForm.reported_user_id, category: reportForm.category, description: reportForm.description });
      playSuccessChime();
      setIsReportModalOpen(false);
      setReportForm({ reported_user_id: '', category: '', description: '' });
      alert('Report submitted to Admin for review.');
    } catch (error) { console.error('Error:', error); }
  };

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-500"></div></div>;

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-blue-600/20 to-indigo-600/20 border border-blue-500/30 rounded-2xl p-6">
        <div className="flex items-center justify-between">
          <div><h2 className="text-2xl font-bold text-white">Engineer Dashboard</h2><p className="text-slate-400 mt-1">Mark attendance, complete tasks and complaints.</p></div>
          {!isCheckedIn ? (
            <button onClick={handleCheckIn} className="px-6 py-3 bg-green-600 text-white font-medium rounded-xl hover:bg-green-700 flex items-center gap-2"><ClockIcon size={20} />Check In (8:00 AM)</button>
          ) : (
            <span className="px-4 py-2 bg-green-500/20 text-green-400 rounded-xl flex items-center gap-2"><CheckIcon size={20} />Checked In</span>
          )}
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="My Complaints" value={myComplaints.length} subtitle="Assigned to me" icon={<AlertIcon size={24} />} color={myComplaints.length > 0 ? 'orange' : 'green'} />
        <StatCard title="My Tasks" value={myTasks.length} subtitle="Pending" icon={<TaskIcon size={24} />} color={myTasks.length > 0 ? 'yellow' : 'green'} />
        <StatCard title="Area" value={currentUser?.area || 'Zone A'} subtitle="My coverage" icon={<ClockIcon size={24} />} color="purple" />
        <StatCard title="Status" value={isCheckedIn ? 'Active' : 'Not Checked In'} subtitle="Today" icon={<CheckIcon size={24} />} color={isCheckedIn ? 'green' : 'red'} />
      </div>
      {myComplaints.length > 0 && (
        <div className="bg-orange-500/10 border border-orange-500/30 rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-orange-500/30"><h3 className="font-semibold text-orange-400">My Complaints - Resolve Before Deadline</h3></div>
          <div className="divide-y divide-orange-500/20">
            {myComplaints.map(complaint => (
              <div key={complaint.id} className="p-4 flex items-center justify-between">
                <div>
                  <p className="font-medium text-white">{complaint.complaint_number}</p>
                  <p className="text-sm text-slate-400">{complaint.customer_name} - {complaint.category}</p>
                  <p className="text-xs text-red-400">Deadline: {complaint.deadline_hours}h | Penalty: {complaint.penalty_amount} AFN</p>
                </div>
                <div className="flex items-center gap-2">
                  <button onClick={() => handleCompleteComplaint(complaint)} className="px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700">Mark Resolved</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      {myTasks.length > 0 && (
        <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-yellow-500/30"><h3 className="font-semibold text-yellow-400">My Tasks</h3></div>
          <div className="divide-y divide-yellow-500/20">
            {myTasks.map(task => (
              <div key={task.id} className="p-4 flex items-center justify-between">
                <div>
                  <p className="font-medium text-white">{task.task_number}</p>
                  <p className="text-sm text-slate-400">{task.title}</p>
                  <p className="text-xs text-slate-500">{task.task_type}</p>
                </div>
                <button onClick={() => handleCompleteTask(task)} className="px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700">Complete</button>
              </div>
            ))}
          </div>
        </div>
      )}
      <div className="flex gap-3">
        <button onClick={() => setIsReportModalOpen(true)} className="px-4 py-2.5 bg-red-600 text-white font-medium rounded-xl hover:bg-red-700">Report NOC Issue</button>
      </div>
      <Modal isOpen={isReportModalOpen} onClose={() => setIsReportModalOpen(false)} title="Report NOC Issue">
        <form onSubmit={handleReportNOC} className="space-y-4">
          <div><label className="block text-sm font-medium text-slate-300 mb-2">NOC Person *</label><select value={reportForm.reported_user_id} onChange={(e) => setReportForm({ ...reportForm, reported_user_id: e.target.value })} className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white" required><option value="">Select NOC</option>{nocUsers.map(n => <option key={n.id} value={n.id}>{n.name}</option>)}</select></div>
          <div><label className="block text-sm font-medium text-slate-300 mb-2">Category *</label><select value={reportForm.category} onChange={(e) => setReportForm({ ...reportForm, category: e.target.value })} className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white" required><option value="">Select</option><option value="wrong_assignment">Wrong Area Assignment</option><option value="unrealistic_deadline">Unrealistic Deadline</option><option value="other">Other</option></select></div>
          <div><label className="block text-sm font-medium text-slate-300 mb-2">Description *</label><textarea value={reportForm.description} onChange={(e) => setReportForm({ ...reportForm, description: e.target.value })} className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white" required rows={3} /></div>
          <div className="flex justify-end gap-3 pt-4"><button type="button" onClick={() => setIsReportModalOpen(false)} className="px-4 py-2 text-slate-400">Cancel</button><button type="submit" className="px-6 py-2 bg-red-600 text-white font-medium rounded-xl hover:bg-red-700">Submit Report</button></div>
        </form>
      </Modal>
    </div>
  );
};

export default EngineerDashboard;
