import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Task, User, Branch } from '@/types';
import DataTable from '../DataTable';
import Modal from '../Modal';
import StatCard from '../StatCard';
import { PlusIcon, TaskIcon, CheckIcon, AlertIcon } from '../ui/Icons';

const TasksView: React.FC = () => {
  const { currentUser } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [engineers, setEngineers] = useState<User[]>([]);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [formData, setFormData] = useState({
    task_type: 'installation' as 'installation' | 'complaint' | 'maintenance',
    title: '',
    description: '',
    branch_id: '',
    assigned_to: '',
    priority: 'normal' as 'low' | 'normal' | 'high' | 'urgent',
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      let tasksQuery = supabase.from('tasks').select('*').order('created_at', { ascending: false });
      
      // Filter by assigned_to for engineers
      if (currentUser?.role === 'engineer') {
        tasksQuery = tasksQuery.eq('assigned_to', currentUser.id);
      }

      const [tasksRes, engineersRes, branchesRes] = await Promise.all([
        tasksQuery,
        supabase.from('users').select('*').eq('role', 'engineer'),
        supabase.from('branches').select('*'),
      ]);

      setTasks(tasksRes.data || []);
      setEngineers(engineersRes.data || []);
      setBranches(branchesRes.data || []);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await supabase.from('tasks').insert({
        task_number: `TSK-${Date.now()}`,
        task_type: formData.task_type,
        title: formData.title,
        description: formData.description,
        branch_id: formData.branch_id || currentUser?.branch_id,
        assigned_to: formData.assigned_to || null,
        assigned_by: currentUser?.id,
        status: 'pending',
        priority: formData.priority,
      });

      setIsModalOpen(false);
      resetForm();
      fetchData();
    } catch (error) {
      console.error('Error creating task:', error);
    }
  };

  const handleStatusChange = async (task: Task, newStatus: string) => {
    try {
      const updateData: any = { status: newStatus };
      if (newStatus === 'completed') {
        updateData.completed_at = new Date().toISOString();
      }
      
      await supabase.from('tasks').update(updateData).eq('id', task.id);
      fetchData();
    } catch (error) {
      console.error('Error updating task:', error);
    }
  };

  const resetForm = () => {
    setFormData({
      task_type: 'installation',
      title: '',
      description: '',
      branch_id: '',
      assigned_to: '',
      priority: 'normal',
    });
  };

  const getEngineerName = (id: string) => {
    return engineers.find(e => e.id === id)?.name || 'Unassigned';
  };

  const getBranchName = (id: string) => {
    return branches.find(b => b.id === id)?.name || '-';
  };

  const pendingTasks = tasks.filter(t => t.status === 'pending');
  const inProgressTasks = tasks.filter(t => t.status === 'in_progress');
  const completedTasks = tasks.filter(t => t.status === 'completed');

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      pending: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
      in_progress: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
      completed: 'bg-green-500/20 text-green-400 border-green-500/30',
      cancelled: 'bg-red-500/20 text-red-400 border-red-500/30',
    };
    return colors[status] || colors.pending;
  };

  const getPriorityColor = (priority: string) => {
    const colors: Record<string, string> = {
      low: 'text-slate-400',
      normal: 'text-blue-400',
      high: 'text-orange-400',
      urgent: 'text-red-400',
    };
    return colors[priority] || colors.normal;
  };

  const columns = [
    { key: 'task_number', label: 'Task #' },
    { key: 'title', label: 'Title' },
    { 
      key: 'task_type', 
      label: 'Type',
      render: (item: Task) => (
        <span className="capitalize">{item.task_type}</span>
      )
    },
    { 
      key: 'priority', 
      label: 'Priority',
      render: (item: Task) => (
        <span className={`capitalize font-medium ${getPriorityColor(item.priority)}`}>
          {item.priority}
        </span>
      )
    },
    { 
      key: 'assigned_to', 
      label: 'Assigned To',
      render: (item: Task) => getEngineerName(item.assigned_to || '')
    },
    { 
      key: 'status', 
      label: 'Status',
      render: (item: Task) => (
        <span className={`px-2 py-1 text-xs rounded-full border ${getStatusColor(item.status)}`}>
          {item.status.replace('_', ' ')}
        </span>
      )
    },
    {
      key: 'actions',
      label: 'Actions',
      render: (item: Task) => (
        <div className="flex items-center gap-2">
          {item.status === 'pending' && (
            <button
              onClick={(e) => { e.stopPropagation(); handleStatusChange(item, 'in_progress'); }}
              className="px-2 py-1 text-xs bg-blue-500/20 text-blue-400 rounded-lg hover:bg-blue-500/30 transition-all"
            >
              Start
            </button>
          )}
          {item.status === 'in_progress' && (
            <button
              onClick={(e) => { e.stopPropagation(); handleStatusChange(item, 'completed'); }}
              className="px-2 py-1 text-xs bg-green-500/20 text-green-400 rounded-lg hover:bg-green-500/30 transition-all"
            >
              Complete
            </button>
          )}
        </div>
      )
    },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <StatCard
          title="Total Tasks"
          value={tasks.length}
          icon={<TaskIcon size={24} />}
          color="cyan"
        />
        <StatCard
          title="Pending"
          value={pendingTasks.length}
          icon={<AlertIcon size={24} />}
          color="yellow"
        />
        <StatCard
          title="In Progress"
          value={inProgressTasks.length}
          icon={<TaskIcon size={24} />}
          color="blue"
        />
        <StatCard
          title="Completed"
          value={completedTasks.length}
          icon={<CheckIcon size={24} />}
          color="green"
        />
      </div>

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white">Tasks</h2>
          <p className="text-sm text-slate-400">Manage installation and maintenance tasks</p>
        </div>
        {(currentUser?.role === 'noc' || currentUser?.role === 'branch_sales' || currentUser?.role === 'admin') && (
          <button
            onClick={() => { resetForm(); setIsModalOpen(true); }}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium rounded-xl hover:from-cyan-600 hover:to-blue-700 transition-all"
          >
            <PlusIcon size={20} />
            New Task
          </button>
        )}
      </div>

      {/* Task Board View */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Pending */}
        <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-4">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
            <h3 className="font-medium text-white">Pending ({pendingTasks.length})</h3>
          </div>
          <div className="space-y-3">
            {pendingTasks.slice(0, 5).map(task => (
              <div key={task.id} className="bg-slate-900 border border-slate-700 rounded-xl p-3">
                <div className="flex items-start justify-between mb-2">
                  <span className="text-xs text-slate-500">{task.task_number}</span>
                  <span className={`text-xs font-medium ${getPriorityColor(task.priority)}`}>
                    {task.priority}
                  </span>
                </div>
                <p className="text-sm text-white font-medium mb-2">{task.title}</p>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-400">{getEngineerName(task.assigned_to || '')}</span>
                  <button
                    onClick={() => handleStatusChange(task, 'in_progress')}
                    className="text-xs text-blue-400 hover:text-blue-300"
                  >
                    Start
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* In Progress */}
        <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-4">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-3 h-3 bg-blue-400 rounded-full"></div>
            <h3 className="font-medium text-white">In Progress ({inProgressTasks.length})</h3>
          </div>
          <div className="space-y-3">
            {inProgressTasks.slice(0, 5).map(task => (
              <div key={task.id} className="bg-slate-900 border border-slate-700 rounded-xl p-3">
                <div className="flex items-start justify-between mb-2">
                  <span className="text-xs text-slate-500">{task.task_number}</span>
                  <span className={`text-xs font-medium ${getPriorityColor(task.priority)}`}>
                    {task.priority}
                  </span>
                </div>
                <p className="text-sm text-white font-medium mb-2">{task.title}</p>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-400">{getEngineerName(task.assigned_to || '')}</span>
                  <button
                    onClick={() => handleStatusChange(task, 'completed')}
                    className="text-xs text-green-400 hover:text-green-300"
                  >
                    Complete
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Completed */}
        <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-4">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-3 h-3 bg-green-400 rounded-full"></div>
            <h3 className="font-medium text-white">Completed ({completedTasks.length})</h3>
          </div>
          <div className="space-y-3">
            {completedTasks.slice(0, 5).map(task => (
              <div key={task.id} className="bg-slate-900 border border-slate-700 rounded-xl p-3 opacity-75">
                <div className="flex items-start justify-between mb-2">
                  <span className="text-xs text-slate-500">{task.task_number}</span>
                  <CheckIcon size={14} className="text-green-400" />
                </div>
                <p className="text-sm text-white font-medium mb-2">{task.title}</p>
                <span className="text-xs text-slate-400">{getEngineerName(task.assigned_to || '')}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Full Table */}
      <DataTable
        columns={columns}
        data={tasks}
        searchable
        searchPlaceholder="Search tasks..."
        emptyMessage="No tasks found"
      />

      {/* New Task Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Create New Task"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Task Type</label>
            <select
              value={formData.task_type}
              onChange={(e) => setFormData({ ...formData, task_type: e.target.value as any })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
            >
              <option value="installation">Installation</option>
              <option value="complaint">Complaint</option>
              <option value="maintenance">Maintenance</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Title *</label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Description</label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              rows={3}
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Assign To</label>
              <select
                value={formData.assigned_to}
                onChange={(e) => setFormData({ ...formData, assigned_to: e.target.value })}
                className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              >
                <option value="">Unassigned</option>
                {engineers.map((eng) => (
                  <option key={eng.id} value={eng.id}>{eng.name}</option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Priority</label>
              <select
                value={formData.priority}
                onChange={(e) => setFormData({ ...formData, priority: e.target.value as any })}
                className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              >
                <option value="low">Low</option>
                <option value="normal">Normal</option>
                <option value="high">High</option>
                <option value="urgent">Urgent</option>
              </select>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Branch</label>
            <select
              value={formData.branch_id}
              onChange={(e) => setFormData({ ...formData, branch_id: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
            >
              <option value="">Select Branch</option>
              {branches.map((branch) => (
                <option key={branch.id} value={branch.id}>{branch.name}</option>
              ))}
            </select>
          </div>
          
          <div className="flex justify-end gap-3 pt-4">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 text-slate-400 hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium rounded-xl hover:from-cyan-600 hover:to-blue-700 transition-all"
            >
              Create Task
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default TasksView;
