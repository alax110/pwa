import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { User, Message, UserRole } from '@/types';
import Modal from '../Modal';
import { SendIcon, UsersIcon, AlertIcon } from '../ui/Icons';
import { supabase } from '@/lib/supabase';
import { playMessageSound } from '@/lib/notifications';

const MessagingView: React.FC = () => {
  const { currentUser } = useAuth();

  const [users, setUsers] = useState<User[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [selectedRole, setSelectedRole] = useState<UserRole | null>(null);
  const [messageText, setMessageText] = useState('');
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [reportForm, setReportForm] = useState({ user_id: '', category: '', description: '' });

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const realtimeRef = useRef<any>(null);
  const lastMessageRef = useRef<string | null>(null);

  // ===============================
  // SCROLL
  // ===============================
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [messages]);

  // ===============================
  // LOAD USERS
  // ===============================
  useEffect(() => {
    if (!currentUser) return;

    const loadUsers = async () => {
      const { data } = await supabase
        .from('users')
        .select('*')
        .eq('is_active', true);

      if (data) setUsers(data);
    };

    loadUsers();
  }, [currentUser?.id]);

  // ===============================
  // LOAD MESSAGES (ONCE)
  // ===============================
  useEffect(() => {
    if (!currentUser) return;

    const loadMessages = async () => {
      const { data } = await supabase
        .from('messages')
        .select('*')
        .order('created_at', { ascending: true });

      if (data) {
        setMessages(data);
        lastMessageRef.current =
          data.length > 0 ? data[data.length - 1].created_at : null;
      }
    };

    loadMessages();
  }, [currentUser?.id]);

  // ===============================
  // REALTIME SUBSCRIPTION (SAFE)
  // ===============================
  useEffect(() => {
    if (!currentUser || realtimeRef.current) return;

    realtimeRef.current = supabase
      .channel('messages-realtime')
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'messages' },
        payload => {
          const msg = payload.new as Message;

          setMessages(prev => {
            if (prev.some(m => m.id === msg.id)) return prev;
            return [...prev, msg];
          });

          if (
            msg.from_user_id !== currentUser.id &&
            msg.created_at !== lastMessageRef.current
          ) {
            playMessageSound();
          }

          lastMessageRef.current = msg.created_at;
        }
      )
      .subscribe();

    return () => {
      if (realtimeRef.current) {
        supabase.removeChannel(realtimeRef.current);
        realtimeRef.current = null;
      }
    };
  }, [currentUser?.id]);

  // ===============================
  // SEND MESSAGE
  // ===============================
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim() || !currentUser) return;

    await supabase.from('messages').insert([
      {
        from_user_id: currentUser.id,
        to_user_id: selectedUser?.id ?? null,
        to_role: selectedRole ?? null,
        message_type: 'text',
        content: messageText,
        is_read: false,
      },
    ]);

    setMessageText('');
  };

  // ===============================
  // HELPERS
  // ===============================
  const getUserName = (id: string) =>
    users.find(u => u.id === id)?.name || 'Unknown';

  const getRoleLabel = (role: UserRole) =>
    ({
      admin: 'Admin',
      branch_sales: 'Branch Sales',
      inventory: 'Inventory',
      cashier: 'Cashier',
      accounts: 'Accounts',
      noc: 'NOC',
      engineer: 'Engineer',
    }[role]);

  const roles: UserRole[] = [
    'admin',
    'branch_sales',
    'inventory',
    'cashier',
    'accounts',
    'noc',
    'engineer',
  ];

  const getConversationMessages = () => {
    if (selectedUser) {
      return messages.filter(
        m =>
          (m.from_user_id === currentUser?.id && m.to_user_id === selectedUser.id) ||
          (m.from_user_id === selectedUser.id && m.to_user_id === currentUser?.id)
      );
    }
    if (selectedRole) {
      return messages.filter(m => m.to_role === selectedRole);
    }
    return [];
  };

  // ===============================
  // UI
  // ===============================
  return (
    <div className="h-[calc(100vh-180px)] flex gap-4">
      {/* SIDEBAR */}
      <div className="w-80 bg-slate-800/50 border border-slate-700 rounded-2xl flex flex-col">
        <div className="p-4 border-b border-slate-700 font-semibold text-white">
          Messages
        </div>

        <div className="p-3 border-b border-slate-700">
          <p className="text-xs text-slate-400 uppercase mb-2">Broadcast</p>
          <div className="flex flex-wrap gap-2">
            {roles
              .filter(r => r !== currentUser?.role)
              .map(role => (
                <button
                  key={role}
                  onClick={() => {
                    setSelectedRole(role);
                    setSelectedUser(null);
                  }}
                  className="px-2 py-1 text-xs bg-slate-700 rounded hover:bg-cyan-600"
                >
                  {getRoleLabel(role)}
                </button>
              ))}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          {users
            .filter(u => u.id !== currentUser?.id)
            .map(user => (
              <button
                key={user.id}
                onClick={() => {
                  setSelectedUser(user);
                  setSelectedRole(null);
                }}
                className="w-full p-3 text-left hover:bg-slate-700"
              >
                <div className="font-medium text-white">{user.name}</div>
                <div className="text-xs text-slate-400">{getRoleLabel(user.role)}</div>
              </button>
            ))}
        </div>
      </div>

      {/* CHAT */}
      <div className="flex-1 bg-slate-800/50 border border-slate-700 rounded-2xl flex flex-col">
        {(selectedUser || selectedRole) ? (
          <>
            <div className="p-4 border-b border-slate-700 font-semibold text-white">
              {selectedUser ? selectedUser.name : `Broadcast: ${getRoleLabel(selectedRole!)}`}
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {getConversationMessages().map(msg => {
                const mine = msg.from_user_id === currentUser?.id;
                return (
                  <div key={msg.id} className={`flex ${mine ? 'justify-end' : 'justify-start'}`}>
                    <div className={`px-4 py-2 rounded-xl ${mine ? 'bg-cyan-600' : 'bg-slate-700'}`}>
                      {!mine && (
                        <div className="text-xs text-cyan-400">
                          {getUserName(msg.from_user_id)}
                        </div>
                      )}
                      <div className="text-sm text-white">{msg.content}</div>
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>

            <form onSubmit={handleSendMessage} className="p-4 border-t border-slate-700 flex gap-3">
              <input
                value={messageText}
                onChange={e => setMessageText(e.target.value)}
                className="flex-1 px-4 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white"
                placeholder="Type a message..."
              />
              <button className="px-4 bg-cyan-600 rounded-xl text-white">
                <SendIcon size={20} />
              </button>
            </form>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-slate-400">
            Select a conversation
          </div>
        )}
      </div>
    </div>
  );
};

export default MessagingView;
