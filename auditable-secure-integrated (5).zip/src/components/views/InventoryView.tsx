import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { InventoryItem, Stock, Branch } from '@/types';
import DataTable from '../DataTable';
import Modal from '../Modal';
import StatCard from '../StatCard';
import { PlusIcon, EditIcon, InventoryIcon, AlertIcon } from '../ui/Icons';

const InventoryView: React.FC = () => {
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [stock, setStock] = useState<Stock[]>([]);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isStockModalOpen, setIsStockModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    sku: '',
    category: 'Network Equipment',
    unit_price: '',
    description: '',
  });
  const [stockFormData, setStockFormData] = useState({
    item_id: '',
    branch_id: '',
    quantity: '',
    movement_type: 'IN' as 'IN' | 'OUT',
    notes: '',
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [itemsRes, stockRes, branchesRes] = await Promise.all([
        supabase.from('inventory_items').select('*').order('name'),
        supabase.from('stock').select('*'),
        supabase.from('branches').select('*'),
      ]);
      setItems(itemsRes.data || []);
      setStock(stockRes.data || []);
      setBranches(branchesRes.data || []);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const data = {
        name: formData.name,
        sku: formData.sku,
        category: formData.category,
        unit_price: parseFloat(formData.unit_price) || 0,
        description: formData.description,
      };

      if (editingItem) {
        await supabase.from('inventory_items').update(data).eq('id', editingItem.id);
      } else {
        await supabase.from('inventory_items').insert(data);
      }
      
      setIsModalOpen(false);
      setEditingItem(null);
      resetForm();
      fetchData();
    } catch (error) {
      console.error('Error saving item:', error);
    }
  };

  const handleStockMovement = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const quantity = parseInt(stockFormData.quantity);
      
      // Check if stock record exists
      const existingStock = stock.find(
        s => s.item_id === stockFormData.item_id && s.branch_id === stockFormData.branch_id
      );

      if (existingStock) {
        const newQuantity = stockFormData.movement_type === 'IN' 
          ? existingStock.quantity + quantity 
          : existingStock.quantity - quantity;
        
        if (newQuantity < 0) {
          alert('Insufficient stock!');
          return;
        }
        
        await supabase
          .from('stock')
          .update({ quantity: newQuantity, updated_at: new Date().toISOString() })
          .eq('id', existingStock.id);
      } else if (stockFormData.movement_type === 'IN') {
        await supabase.from('stock').insert({
          item_id: stockFormData.item_id,
          branch_id: stockFormData.branch_id,
          quantity,
        });
      } else {
        alert('Cannot issue stock that does not exist!');
        return;
      }

      // Create ledger entry
      await supabase.from('stock_ledger').insert({
        item_id: stockFormData.item_id,
        branch_id: stockFormData.branch_id,
        movement_type: stockFormData.movement_type,
        quantity,
        reference_type: 'ADJUSTMENT',
        notes: stockFormData.notes,
      });

      setIsStockModalOpen(false);
      resetStockForm();
      fetchData();
    } catch (error) {
      console.error('Error updating stock:', error);
    }
  };

  const handleEdit = (item: InventoryItem) => {
    setEditingItem(item);
    setFormData({
      name: item.name,
      sku: item.sku || '',
      category: item.category,
      unit_price: String(item.unit_price),
      description: item.description || '',
    });
    setIsModalOpen(true);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      sku: '',
      category: 'Network Equipment',
      unit_price: '',
      description: '',
    });
  };

  const resetStockForm = () => {
    setStockFormData({
      item_id: '',
      branch_id: '',
      quantity: '',
      movement_type: 'IN',
      notes: '',
    });
  };

  const getStockForItem = (itemId: string) => {
    return stock.filter(s => s.item_id === itemId).reduce((sum, s) => sum + s.quantity, 0);
  };

  const getStockByBranch = (itemId: string, branchId: string) => {
    const s = stock.find(st => st.item_id === itemId && st.branch_id === branchId);
    return s?.quantity || 0;
  };

  const totalItems = items.length;
  const lowStockItems = items.filter(item => getStockForItem(item.id) < 10).length;
  const totalStockValue = items.reduce((sum, item) => {
    return sum + (getStockForItem(item.id) * parseFloat(String(item.unit_price)));
  }, 0);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US').format(amount) + ' AFN';
  };

  const columns = [
    { key: 'name', label: 'Item Name' },
    { key: 'sku', label: 'SKU' },
    { key: 'category', label: 'Category' },
    { 
      key: 'unit_price', 
      label: 'Unit Price',
      render: (item: InventoryItem) => formatCurrency(parseFloat(String(item.unit_price)))
    },
    { 
      key: 'stock', 
      label: 'Total Stock',
      render: (item: InventoryItem) => {
        const qty = getStockForItem(item.id);
        return (
          <span className={`font-medium ${qty < 10 ? 'text-red-400' : qty < 20 ? 'text-yellow-400' : 'text-green-400'}`}>
            {qty}
          </span>
        );
      }
    },
    {
      key: 'actions',
      label: 'Actions',
      render: (item: InventoryItem) => (
        <button
          onClick={(e) => { e.stopPropagation(); handleEdit(item); }}
          className="p-1.5 text-slate-400 hover:text-cyan-400 hover:bg-slate-700 rounded-lg transition-all"
        >
          <EditIcon size={16} />
        </button>
      )
    },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatCard
          title="Total Items"
          value={totalItems}
          icon={<InventoryIcon size={24} />}
          color="cyan"
        />
        <StatCard
          title="Low Stock Items"
          value={lowStockItems}
          subtitle="Below 10 units"
          icon={<AlertIcon size={24} />}
          color={lowStockItems > 0 ? 'red' : 'green'}
        />
        <StatCard
          title="Stock Value"
          value={formatCurrency(totalStockValue)}
          icon={<InventoryIcon size={24} />}
          color="purple"
        />
      </div>

      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white">Inventory</h2>
          <p className="text-sm text-slate-400">Manage items and stock levels</p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={() => { resetStockForm(); setIsStockModalOpen(true); }}
            className="flex items-center gap-2 px-4 py-2 bg-slate-700 text-white font-medium rounded-xl hover:bg-slate-600 transition-all"
          >
            <PlusIcon size={20} />
            Stock Movement
          </button>
          <button
            onClick={() => { resetForm(); setEditingItem(null); setIsModalOpen(true); }}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium rounded-xl hover:from-cyan-600 hover:to-blue-700 transition-all"
          >
            <PlusIcon size={20} />
            Add Item
          </button>
        </div>
      </div>

      {/* Stock by Branch */}
      {branches.length > 0 && items.length > 0 && (
        <div className="bg-slate-800/50 border border-slate-700 rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-700">
            <h3 className="font-medium text-white">Stock by Branch</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-700">
                  <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400 uppercase">Item</th>
                  {branches.map(branch => (
                    <th key={branch.id} className="px-4 py-3 text-left text-xs font-semibold text-slate-400 uppercase">
                      {branch.name ? branch.name.split(' - ')[0] : 'Branch'}
                    </th>

                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700/50">
                {items.slice(0, 6).map(item => (
                  <tr key={item.id}>
                    <td className="px-4 py-3 text-sm text-white">{item.name}</td>
                    {branches.map(branch => {
                      const qty = getStockByBranch(item.id, branch.id);
                      return (
                        <td key={branch.id} className="px-4 py-3 text-sm">
                          <span className={`font-medium ${qty < 10 ? 'text-red-400' : qty < 20 ? 'text-yellow-400' : 'text-green-400'}`}>
                            {qty}
                          </span>
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <DataTable
        columns={columns}
        data={items}
        searchable
        searchPlaceholder="Search items..."
        emptyMessage="No inventory items"
      />

      {/* Add/Edit Item Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => { setIsModalOpen(false); setEditingItem(null); }}
        title={editingItem ? 'Edit Item' : 'Add New Item'}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Item Name *</label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              required
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">SKU</label>
              <input
                type="text"
                value={formData.sku}
                onChange={(e) => setFormData({ ...formData, sku: e.target.value })}
                className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Category</label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              >
                <option value="Network Equipment">Network Equipment</option>
                <option value="Cables">Cables</option>
                <option value="Accessories">Accessories</option>
                <option value="Tools">Tools</option>
              </select>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Unit Price (AFN)</label>
            <input
              type="number"
              value={formData.unit_price}
              onChange={(e) => setFormData({ ...formData, unit_price: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              min="0"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Description</label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              rows={2}
            />
          </div>
          
          <div className="flex justify-end gap-3 pt-4">
            <button
              type="button"
              onClick={() => { setIsModalOpen(false); setEditingItem(null); }}
              className="px-4 py-2 text-slate-400 hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium rounded-xl hover:from-cyan-600 hover:to-blue-700 transition-all"
            >
              {editingItem ? 'Update' : 'Create'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Stock Movement Modal */}
      <Modal
        isOpen={isStockModalOpen}
        onClose={() => setIsStockModalOpen(false)}
        title="Stock Movement"
      >
        <form onSubmit={handleStockMovement} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Movement Type</label>
            <div className="flex gap-4">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  name="movement_type"
                  value="IN"
                  checked={stockFormData.movement_type === 'IN'}
                  onChange={() => setStockFormData({ ...stockFormData, movement_type: 'IN' })}
                  className="text-cyan-500 focus:ring-cyan-500"
                />
                <span className="text-green-400">Stock IN (Receive)</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  name="movement_type"
                  value="OUT"
                  checked={stockFormData.movement_type === 'OUT'}
                  onChange={() => setStockFormData({ ...stockFormData, movement_type: 'OUT' })}
                  className="text-cyan-500 focus:ring-cyan-500"
                />
                <span className="text-red-400">Stock OUT (Issue)</span>
              </label>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Item *</label>
            <select
              value={stockFormData.item_id}
              onChange={(e) => setStockFormData({ ...stockFormData, item_id: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              required
            >
              <option value="">Select Item</option>
              {items.map((item) => (
                <option key={item.id} value={item.id}>{item.name} ({item.sku})</option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Branch *</label>
            <select
              value={stockFormData.branch_id}
              onChange={(e) => setStockFormData({ ...stockFormData, branch_id: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              required
            >
              <option value="">Select Branch</option>
              {branches.map((branch) => (
                <option key={branch.id} value={branch.id}>{branch.name}</option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Quantity *</label>
            <input
              type="number"
              value={stockFormData.quantity}
              onChange={(e) => setStockFormData({ ...stockFormData, quantity: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              required
              min="1"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Notes</label>
            <textarea
              value={stockFormData.notes}
              onChange={(e) => setStockFormData({ ...stockFormData, notes: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              rows={2}
              placeholder="PO number, reason, etc."
            />
          </div>
          
          <div className="flex justify-end gap-3 pt-4">
            <button
              type="button"
              onClick={() => setIsStockModalOpen(false)}
              className="px-4 py-2 text-slate-400 hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className={`px-6 py-2 font-medium rounded-xl transition-all ${
                stockFormData.movement_type === 'IN'
                  ? 'bg-green-600 hover:bg-green-700 text-white'
                  : 'bg-red-600 hover:bg-red-700 text-white'
              }`}
            >
              {stockFormData.movement_type === 'IN' ? 'Receive Stock' : 'Issue Stock'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default InventoryView;
