import React, { useState, useEffect, useRef } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { playSuccessChime, playErrorSound } from '@/lib/notifications';
import StatCard from '../StatCard';
import Modal from '../Modal';
import { MoneyIcon, CashIcon, PartnerIcon, AlertIcon, PlusIcon, PrintIcon, CheckIcon } from '../ui/Icons';

interface BudgetBucket {
  id: string;
  name: string;
  percentage: number;
  current_balance: number;
}

interface Partner {
  id: string;
  name: string;
  email: string;
  revenue_share_percent: number;
  total_earnings: number;
  withdrawn: number;
}

interface CashHandover {
  id: string;
  handover_number: string;
  branch_id: string;
  handed_by: string;
  amount: number;
  status: string;
  confirmed_at: string;
  created_at: string;
  branch?: { name: string };
  hander?: { name: string };
}

interface PurchaseOrder {
  id: string;
  po_number: string;
  bucket_name: string;
  status: string;
  total_amount: number;
  items_description: string;
  notes: string;
  created_at: string;
}

interface StockRequest {
  id: string;
  item_name: string;
  quantity: number;
  reason: string;
  status: string;
  created_at: string;
  requester?: { name: string };
}

interface PurchaseHistory {
  id: string;
  po_id: string;
  bucket_name: string;
  amount: number;
  items_description: string;
  created_at: string;
  purchase_order?: { po_number: string };
}

const AccountsDashboard: React.FC = () => {
  const { currentUser } = useAuth();
  const [loading, setLoading] = useState(true);
  const [buckets, setBuckets] = useState<BudgetBucket[]>([]);
  const [partners, setPartners] = useState<Partner[]>([]);
  const [handovers, setHandovers] = useState<CashHandover[]>([]);
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>([]);
  const [stockRequests, setStockRequests] = useState<StockRequest[]>([]);
  const [purchaseHistory, setPurchaseHistory] = useState<PurchaseHistory[]>([]);
  const [employees, setEmployees] = useState<any[]>([]);
  
  const [isPOModalOpen, setIsPOModalOpen] = useState(false);
  const [isSalaryModalOpen, setIsSalaryModalOpen] = useState(false);
  const [isWithdrawalModalOpen, setIsWithdrawalModalOpen] = useState(false);
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false);
  const [selectedPartner, setSelectedPartner] = useState<Partner | null>(null);
  const [selectedRequest, setSelectedRequest] = useState<StockRequest | null>(null);

  const [poForm, setPOForm] = useState({ 
    item_name: '', 
    quantity: '', 
    unit_price: '', 
    bucket_name: 'DEV',
    notes: '' 
  });
  const [salaryForm, setSalaryForm] = useState({ employee_id: '', amount: '', type: 'salary', notes: '' });
  const [withdrawalForm, setWithdrawalForm] = useState({ amount: '' });

  const printRef = useRef<HTMLDivElement>(null);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US').format(amount) + ' AFN';
  };

  const fetchData = async () => {
    setLoading(true);
    try {
      // Fetch budget buckets
      const { data: bucketsData } = await supabase.from('budget_buckets').select('*');
      setBuckets(bucketsData || []);

      // Fetch partners
      const { data: partnersData } = await supabase.from('partners').select('*').eq('is_active', true);
      setPartners(partnersData || []);

      // Fetch recent handovers
      const { data: handoversData } = await supabase
        .from('cash_handovers')
        .select('*, branch:branches(name), hander:users!cash_handovers_handed_by_fkey(name)')
        .order('created_at', { ascending: false })
        .limit(20);
      setHandovers(handoversData || []);

      // Fetch purchase orders
      const { data: posData } = await supabase
        .from('purchase_orders')
        .select('*')
        .order('created_at', { ascending: false });
      setPurchaseOrders(posData || []);

      // Fetch stock requests from inventory
      const { data: requestsData } = await supabase
        .from('stock_requests')
        .select('*, requester:users!stock_requests_requested_by_fkey(name)')
        .eq('status', 'pending')
        .order('created_at', { ascending: false });
      setStockRequests(requestsData || []);

      // Fetch purchase history
      const { data: historyData } = await supabase
        .from('purchase_history')
        .select('*, purchase_order:purchase_orders(po_number)')
        .order('created_at', { ascending: false })
        .limit(50);
      setPurchaseHistory(historyData || []);

      // Fetch employees
      const { data: employeesData } = await supabase
        .from('users')
        .select('*')
        .eq('is_active', true);
      setEmployees(employeesData || []);

    } catch (error) {
      console.error('Error fetching data:', error);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchData();

    // Subscribe to real-time updates
    const channel = supabase
      .channel('accounts-updates')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'cash_handovers' }, () => {
        fetchData();
        playSuccessChime();
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'purchase_orders' }, () => {
        fetchData();
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'stock_requests' }, () => {
        fetchData();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const totalRevenue = buckets.reduce((sum, b) => sum + Number(b.current_balance), 0);
  const taxBucket = buckets.find(b => b.name === 'TAX');
  const devBucket = buckets.find(b => b.name === 'DEV');
  const revenueBucket = buckets.find(b => b.name === 'REVENUE');

  const todayHandovers = handovers.filter(h => 
    h.status === 'confirmed' && 
    new Date(h.confirmed_at || h.created_at).toDateString() === new Date().toDateString()
  );
  const todayTotal = todayHandovers.reduce((sum, h) => sum + Number(h.amount), 0);

  const pendingPOs = purchaseOrders.filter(po => po.status === 'pending');

  const handleCreatePO = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const totalAmount = parseInt(poForm.quantity) * parseFloat(poForm.unit_price);
      const poNumber = `PO-${new Date().getFullYear()}-${String(purchaseOrders.length + 1).padStart(3, '0')}`;
      
      const { error } = await supabase.from('purchase_orders').insert({
        po_number: poNumber,
        requested_by: currentUser?.id || 'eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee',
        bucket_name: poForm.bucket_name,
        status: 'pending',
        total_amount: totalAmount,
        items_description: `${poForm.item_name} x${poForm.quantity} @ ${poForm.unit_price}/unit`,
        notes: poForm.notes,
      });

      if (error) throw error;

      // If this was from a stock request, update the request status
      if (selectedRequest) {
        await supabase
          .from('stock_requests')
          .update({ status: 'po_created' })
          .eq('id', selectedRequest.id);
      }

      // Create notification for Admin
      await supabase.from('notifications').insert({
        user_id: 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
        title: 'New PO Pending Approval',
        message: `Purchase Order ${poNumber} for ${formatCurrency(totalAmount)} from ${poForm.bucket_name} bucket requires your approval.`,
        type: 'po',
      });

      // Log the action
      await supabase.from('audit_logs').insert({
        user_id: currentUser?.id || 'eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee',
        action: 'CREATE_PO',
        entity_type: 'purchase_order',
        new_data: { po_number: poNumber, amount: totalAmount, bucket: poForm.bucket_name }
      });

      playSuccessChime();
      setIsPOModalOpen(false);
      setPOForm({ item_name: '', quantity: '', unit_price: '', bucket_name: 'DEV', notes: '' });
      setSelectedRequest(null);
      fetchData();
    } catch (error) {
      console.error('Error creating PO:', error);
      playErrorSound();
    }
  };

  const handleCreatePOFromRequest = (request: StockRequest) => {
    setSelectedRequest(request);
    setPOForm({
      item_name: request.item_name,
      quantity: String(request.quantity),
      unit_price: '',
      bucket_name: 'DEV',
      notes: `Stock request from Inventory: ${request.reason}`
    });
    setIsPOModalOpen(true);
  };

  const handleProcessSalary = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const employee = employees.find(emp => emp.id === salaryForm.employee_id);
      
      await supabase.from('audit_logs').insert({
        user_id: currentUser?.id || 'eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee',
        action: `PROCESS_${salaryForm.type.toUpperCase()}`,
        entity_type: 'salary',
        new_data: { 
          employee_id: salaryForm.employee_id, 
          employee_name: employee?.name,
          amount: parseFloat(salaryForm.amount),
          type: salaryForm.type,
          notes: salaryForm.notes
        }
      });

      playSuccessChime();
      alert(`${salaryForm.type === 'salary' ? 'Salary' : salaryForm.type === 'bonus' ? 'Bonus' : 'Advance'} of ${formatCurrency(parseFloat(salaryForm.amount))} processed for ${employee?.name}.`);
      setIsSalaryModalOpen(false);
      setSalaryForm({ employee_id: '', amount: '', type: 'salary', notes: '' });
    } catch (error) {
      console.error('Error processing salary:', error);
      playErrorSound();
    }
  };

  const handlePartnerWithdrawal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPartner) return;
    
    try {
      const amount = parseFloat(withdrawalForm.amount);
      const available = selectedPartner.total_earnings - selectedPartner.withdrawn;
      
      if (amount > available) {
        playErrorSound();
        alert('Amount exceeds available balance!');
        return;
      }

      await supabase
        .from('partners')
        .update({ withdrawn: selectedPartner.withdrawn + amount })
        .eq('id', selectedPartner.id);

      await supabase.from('audit_logs').insert({
        user_id: currentUser?.id || 'eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee',
        action: 'PARTNER_WITHDRAWAL',
        entity_type: 'partner',
        entity_id: selectedPartner.id,
        new_data: { partner_name: selectedPartner.name, amount }
      });

      playSuccessChime();
      setIsWithdrawalModalOpen(false);
      setSelectedPartner(null);
      setWithdrawalForm({ amount: '' });
      fetchData();
    } catch (error) {
      console.error('Error processing withdrawal:', error);
      playErrorSound();
    }
  };

  const handlePrintHistory = () => {
    const printContent = document.getElementById('purchase-history-print');
    if (printContent) {
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(`
          <html>
            <head>
              <title>Purchase History - Work.PWA</title>
              <style>
                body { font-family: Arial, sans-serif; padding: 20px; }
                table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                th { background-color: #f4f4f4; }
                h1 { color: #333; }
                .header { display: flex; justify-content: space-between; margin-bottom: 20px; }
              </style>
            </head>
            <body>
              <div class="header">
                <h1>Purchase History Report</h1>
                <p>Generated: ${new Date().toLocaleString()}</p>
              </div>
              ${printContent.innerHTML}
            </body>
          </html>
        `);
        printWindow.document.close();
        printWindow.print();
      }
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Budget Buckets */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-slate-800 to-slate-900 border border-slate-700 rounded-2xl p-6">
          <p className="text-sm text-slate-400 mb-1">Total Revenue</p>
          <p className="text-3xl font-bold text-white">{formatCurrency(totalRevenue)}</p>
          <p className="text-xs text-slate-500 mt-2">All buckets combined</p>
        </div>
        <div className="bg-gradient-to-br from-red-900/30 to-red-950/30 border border-red-500/30 rounded-2xl p-6">
          <p className="text-sm text-red-400 mb-1">TAX Bucket (10%)</p>
          <p className="text-3xl font-bold text-red-400">{formatCurrency(Number(taxBucket?.current_balance || 0))}</p>
          <p className="text-xs text-red-400/60 mt-2">Government taxes</p>
        </div>
        <div className="bg-gradient-to-br from-blue-900/30 to-blue-950/30 border border-blue-500/30 rounded-2xl p-6">
          <p className="text-sm text-blue-400 mb-1">DEV Bucket (20%)</p>
          <p className="text-3xl font-bold text-blue-400">{formatCurrency(Number(devBucket?.current_balance || 0))}</p>
          <p className="text-xs text-blue-400/60 mt-2">Development fund</p>
        </div>
        <div className="bg-gradient-to-br from-green-900/30 to-green-950/30 border border-green-500/30 rounded-2xl p-6">
          <p className="text-sm text-green-400 mb-1">REVENUE Bucket (70%)</p>
          <p className="text-3xl font-bold text-green-400">{formatCurrency(Number(revenueBucket?.current_balance || 0))}</p>
          <p className="text-xs text-green-400/60 mt-2">Partner distributions</p>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Today's Collections"
          value={formatCurrency(todayTotal)}
          subtitle={`${todayHandovers.length} handovers`}
          icon={<CashIcon size={24} />}
          color="cyan"
        />
        <StatCard
          title="Pending POs"
          value={pendingPOs.length}
          subtitle="Awaiting Admin approval"
          icon={<AlertIcon size={24} />}
          color={pendingPOs.length > 0 ? 'yellow' : 'green'}
        />
        <StatCard
          title="Active Partners"
          value={partners.length}
          subtitle="Revenue sharing"
          icon={<PartnerIcon size={24} />}
          color="purple"
        />
        <StatCard
          title="Stock Requests"
          value={stockRequests.length}
          subtitle="From Inventory"
          icon={<MoneyIcon size={24} />}
          color={stockRequests.length > 0 ? 'orange' : 'green'}
        />
      </div>

      {/* Stock Requests from Inventory */}
      {stockRequests.length > 0 && (
        <div className="bg-orange-500/10 border border-orange-500/30 rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-orange-500/30">
            <h3 className="font-semibold text-orange-400">Stock Requests from Inventory - Create PO</h3>
          </div>
          <div className="divide-y divide-orange-500/20">
            {stockRequests.map(request => (
              <div key={request.id} className="p-4 flex items-center justify-between">
                <div>
                  <p className="font-medium text-white">{request.item_name} x{request.quantity}</p>
                  <p className="text-sm text-slate-400">{request.reason}</p>
                  <p className="text-xs text-slate-500">From: {request.requester?.name || 'Inventory'}</p>
                </div>
                <button
                  onClick={() => handleCreatePOFromRequest(request)}
                  className="px-4 py-2 bg-orange-600 text-white text-sm font-medium rounded-lg hover:bg-orange-700"
                >
                  Create PO
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex flex-wrap gap-3">
        <button
          onClick={() => setIsPOModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium rounded-xl hover:opacity-90"
        >
          <PlusIcon size={20} />
          Create Purchase Order
        </button>
        <button
          onClick={() => setIsSalaryModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-green-500 to-emerald-600 text-white font-medium rounded-xl hover:opacity-90"
        >
          <MoneyIcon size={20} />
          Process Salary/Bonus
        </button>
        <button
          onClick={() => setIsHistoryModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-purple-500 to-pink-600 text-white font-medium rounded-xl hover:opacity-90"
        >
          <PrintIcon size={20} />
          Purchase History
        </button>
      </div>

      {/* Partner Shares */}
      <div className="bg-slate-800/50 border border-slate-700 rounded-2xl overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-700">
          <h3 className="font-semibold text-white">Partner Revenue Shares (70% of Revenue)</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4">
          {partners.map(partner => {
            const available = partner.total_earnings - partner.withdrawn;
            return (
              <div key={partner.id} className="bg-slate-900 border border-slate-700 rounded-xl p-4">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <p className="font-medium text-white">{partner.name}</p>
                    <p className="text-sm text-cyan-400">{partner.revenue_share_percent}% share</p>
                  </div>
                  <span className="px-2 py-1 text-xs bg-green-500/20 text-green-400 rounded-full">Active</span>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Total Earnings:</span>
                    <span className="text-white font-medium">{formatCurrency(Number(partner.total_earnings))}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Withdrawn:</span>
                    <span className="text-orange-400">{formatCurrency(Number(partner.withdrawn))}</span>
                  </div>
                  <div className="flex justify-between border-t border-slate-700 pt-2">
                    <span className="text-slate-400">Available:</span>
                    <span className="text-green-400 font-bold">{formatCurrency(available)}</span>
                  </div>
                </div>
                <button
                  onClick={() => { setSelectedPartner(partner); setIsWithdrawalModalOpen(true); }}
                  className="w-full mt-4 py-2 bg-slate-700 text-white text-sm font-medium rounded-lg hover:bg-slate-600 transition-all disabled:opacity-50"
                  disabled={available <= 0}
                >
                  Process Withdrawal
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Pending Purchase Orders */}
      {pendingPOs.length > 0 && (
        <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-yellow-500/30">
            <h3 className="font-semibold text-yellow-400">Pending Purchase Orders (Awaiting Admin Approval)</h3>
          </div>
          <div className="divide-y divide-yellow-500/20">
            {pendingPOs.map(po => (
              <div key={po.id} className="p-4 flex items-center justify-between">
                <div>
                  <p className="font-medium text-white">{po.po_number}</p>
                  <p className="text-sm text-slate-400">{po.items_description}</p>
                  <span className={`text-xs px-2 py-0.5 rounded ${
                    po.bucket_name === 'TAX' ? 'bg-red-500/20 text-red-400' :
                    po.bucket_name === 'DEV' ? 'bg-blue-500/20 text-blue-400' :
                    'bg-green-500/20 text-green-400'
                  }`}>
                    Bucket: {po.bucket_name}
                  </span>
                </div>
                <div className="text-right">
                  <p className="font-bold text-yellow-400">{formatCurrency(Number(po.total_amount))}</p>
                  <p className="text-xs text-slate-500">{new Date(po.created_at).toLocaleDateString()}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Recent Cash Collections */}
      <div className="bg-slate-800/50 border border-slate-700 rounded-2xl overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-700">
          <h3 className="font-semibold text-white">Recent Cash Collections</h3>
        </div>
        <div className="divide-y divide-slate-700/50">
          {handovers.length === 0 ? (
            <p className="p-4 text-slate-400 text-center">No handovers yet</p>
          ) : (
            handovers.slice(0, 10).map(handover => (
              <div key={handover.id} className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                    handover.status === 'confirmed' ? 'bg-green-500/20' : 'bg-yellow-500/20'
                  }`}>
                    <CheckIcon size={20} className={handover.status === 'confirmed' ? 'text-green-400' : 'text-yellow-400'} />
                  </div>
                  <div>
                    <p className="font-medium text-white">{handover.handover_number}</p>
                    <p className="text-sm text-slate-400">
                      {handover.branch?.name} • {handover.hander?.name}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-green-400">+{formatCurrency(Number(handover.amount))}</p>
                  <div className="text-xs text-slate-500 mt-1">
                    <span className="text-red-400">TAX: {formatCurrency(Number(handover.amount) * 0.1)}</span>
                    <span className="mx-1">|</span>
                    <span className="text-blue-400">DEV: {formatCurrency(Number(handover.amount) * 0.2)}</span>
                    <span className="mx-1">|</span>
                    <span className="text-green-400">REV: {formatCurrency(Number(handover.amount) * 0.7)}</span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Create PO Modal */}
      <Modal isOpen={isPOModalOpen} onClose={() => { setIsPOModalOpen(false); setSelectedRequest(null); }} title="Create Purchase Order">
        <form onSubmit={handleCreatePO} className="space-y-4">
          <div className="bg-slate-800 border border-slate-700 rounded-xl p-3 text-sm text-slate-400">
            This PO will be sent to Admin for approval. Once approved, the amount will be deducted from the selected bucket.
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Budget Bucket *</label>
            <select
              value={poForm.bucket_name}
              onChange={(e) => setPOForm({ ...poForm, bucket_name: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white"
              required
            >
              <option value="TAX">TAX ({formatCurrency(Number(taxBucket?.current_balance || 0))} available)</option>
              <option value="DEV">DEV ({formatCurrency(Number(devBucket?.current_balance || 0))} available)</option>
              <option value="REVENUE">REVENUE ({formatCurrency(Number(revenueBucket?.current_balance || 0))} available)</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Item Name *</label>
            <input
              type="text"
              value={poForm.item_name}
              onChange={(e) => setPOForm({ ...poForm, item_name: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white"
              required
              placeholder="e.g., ONU Device"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Quantity *</label>
              <input
                type="number"
                value={poForm.quantity}
                onChange={(e) => setPOForm({ ...poForm, quantity: e.target.value })}
                className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white"
                required
                min="1"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Unit Price (AFN) *</label>
              <input
                type="number"
                value={poForm.unit_price}
                onChange={(e) => setPOForm({ ...poForm, unit_price: e.target.value })}
                className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white"
                required
                min="0"
              />
            </div>
          </div>
          {poForm.quantity && poForm.unit_price && (
            <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-xl p-3">
              <p className="text-cyan-400 font-medium">
                Total: {formatCurrency(parseInt(poForm.quantity) * parseFloat(poForm.unit_price))}
              </p>
            </div>
          )}
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Notes</label>
            <textarea
              value={poForm.notes}
              onChange={(e) => setPOForm({ ...poForm, notes: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white"
              rows={2}
            />
          </div>
          <div className="flex justify-end gap-3 pt-4">
            <button type="button" onClick={() => { setIsPOModalOpen(false); setSelectedRequest(null); }} className="px-4 py-2 text-slate-400">Cancel</button>
            <button type="submit" className="px-6 py-2 bg-cyan-600 text-white font-medium rounded-xl hover:bg-cyan-700">Create PO</button>
          </div>
        </form>
      </Modal>

      {/* Salary Modal */}
      <Modal isOpen={isSalaryModalOpen} onClose={() => setIsSalaryModalOpen(false)} title="Process Salary/Bonus/Advance">
        <form onSubmit={handleProcessSalary} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Employee *</label>
            <select
              value={salaryForm.employee_id}
              onChange={(e) => setSalaryForm({ ...salaryForm, employee_id: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white"
              required
            >
              <option value="">Select Employee</option>
              {employees.map(emp => (
                <option key={emp.id} value={emp.id}>{emp.name} ({emp.role})</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Type *</label>
            <select
              value={salaryForm.type}
              onChange={(e) => setSalaryForm({ ...salaryForm, type: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white"
            >
              <option value="salary">Salary</option>
              <option value="bonus">Bonus</option>
              <option value="advance">Advance</option>
              <option value="penalty">Penalty Deduction</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Amount (AFN) *</label>
            <input
              type="number"
              value={salaryForm.amount}
              onChange={(e) => setSalaryForm({ ...salaryForm, amount: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white"
              required
              min="0"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Notes</label>
            <textarea
              value={salaryForm.notes}
              onChange={(e) => setSalaryForm({ ...salaryForm, notes: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white"
              rows={2}
            />
          </div>
          <div className="flex justify-end gap-3 pt-4">
            <button type="button" onClick={() => setIsSalaryModalOpen(false)} className="px-4 py-2 text-slate-400">Cancel</button>
            <button type="submit" className="px-6 py-2 bg-green-600 text-white font-medium rounded-xl hover:bg-green-700">Process</button>
          </div>
        </form>
      </Modal>

      {/* Withdrawal Modal */}
      <Modal isOpen={isWithdrawalModalOpen} onClose={() => setIsWithdrawalModalOpen(false)} title="Partner Withdrawal">
        <form onSubmit={handlePartnerWithdrawal} className="space-y-4">
          {selectedPartner && (
            <div className="bg-slate-800 border border-slate-700 rounded-xl p-4">
              <p className="text-white font-medium">{selectedPartner.name}</p>
              <p className="text-sm text-slate-400 mt-1">
                Available: <span className="text-green-400 font-bold">
                  {formatCurrency(selectedPartner.total_earnings - selectedPartner.withdrawn)}
                </span>
              </p>
            </div>
          )}
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Withdrawal Amount (AFN) *</label>
            <input
              type="number"
              value={withdrawalForm.amount}
              onChange={(e) => setWithdrawalForm({ ...withdrawalForm, amount: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white"
              required
              min="0"
              max={selectedPartner ? selectedPartner.total_earnings - selectedPartner.withdrawn : 0}
            />
          </div>
          <div className="flex justify-end gap-3 pt-4">
            <button type="button" onClick={() => setIsWithdrawalModalOpen(false)} className="px-4 py-2 text-slate-400">Cancel</button>
            <button type="submit" className="px-6 py-2 bg-green-600 text-white font-medium rounded-xl hover:bg-green-700">Process Withdrawal</button>
          </div>
        </form>
      </Modal>

      {/* Purchase History Modal */}
      <Modal isOpen={isHistoryModalOpen} onClose={() => setIsHistoryModalOpen(false)} title="Purchase History">
        <div className="space-y-4">
          <div className="flex justify-end">
            <button
              onClick={handlePrintHistory}
              className="flex items-center gap-2 px-4 py-2 bg-cyan-600 text-white text-sm font-medium rounded-lg hover:bg-cyan-700"
            >
              <PrintIcon size={16} />
              Print Report
            </button>
          </div>
          
          <div id="purchase-history-print" className="max-h-96 overflow-y-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-800 sticky top-0">
                <tr>
                  <th className="text-left p-3 text-slate-300">PO Number</th>
                  <th className="text-left p-3 text-slate-300">Items</th>
                  <th className="text-left p-3 text-slate-300">Bucket</th>
                  <th className="text-right p-3 text-slate-300">Amount</th>
                  <th className="text-left p-3 text-slate-300">Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700">
                {purchaseHistory.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="p-4 text-center text-slate-400">No purchase history yet</td>
                  </tr>
                ) : (
                  purchaseHistory.map(item => (
                    <tr key={item.id}>
                      <td className="p-3 text-white">{item.purchase_order?.po_number || '-'}</td>
                      <td className="p-3 text-slate-400">{item.items_description}</td>
                      <td className="p-3">
                        <span className={`px-2 py-0.5 text-xs rounded ${
                          item.bucket_name === 'TAX' ? 'bg-red-500/20 text-red-400' :
                          item.bucket_name === 'DEV' ? 'bg-blue-500/20 text-blue-400' :
                          'bg-green-500/20 text-green-400'
                        }`}>
                          {item.bucket_name}
                        </span>
                      </td>
                      <td className="p-3 text-right text-cyan-400 font-medium">{formatCurrency(Number(item.amount))}</td>
                      <td className="p-3 text-slate-500">{new Date(item.created_at).toLocaleDateString()}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default AccountsDashboard;
