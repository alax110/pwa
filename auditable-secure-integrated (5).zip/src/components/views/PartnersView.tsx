import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Partner } from '@/types';
import DataTable from '../DataTable';
import Modal from '../Modal';
import StatCard from '../StatCard';
import { PlusIcon, PartnerIcon, MoneyIcon, EditIcon, TrendUpIcon } from '../ui/Icons';

const PartnersView: React.FC = () => {
  const [partners, setPartners] = useState<Partner[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPartner, setEditingPartner] = useState<Partner | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    revenue_share_percent: '',
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const { data } = await supabase.from('partners').select('*').order('name');
      setPartners(data || []);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const data = {
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        revenue_share_percent: parseFloat(formData.revenue_share_percent),
      };

      if (editingPartner) {
        await supabase.from('partners').update(data).eq('id', editingPartner.id);
      } else {
        await supabase.from('partners').insert(data);
      }

      setIsModalOpen(false);
      setEditingPartner(null);
      resetForm();
      fetchData();
    } catch (error) {
      console.error('Error saving partner:', error);
    }
  };

  const handleEdit = (partner: Partner) => {
    setEditingPartner(partner);
    setFormData({
      name: partner.name,
      email: partner.email || '',
      phone: partner.phone || '',
      revenue_share_percent: String(partner.revenue_share_percent),
    });
    setIsModalOpen(true);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      email: '',
      phone: '',
      revenue_share_percent: '',
    });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US').format(amount) + ' AFN';
  };

  const totalEarnings = partners.reduce((sum, p) => sum + parseFloat(String(p.total_earnings)), 0);
  const totalWithdrawn = partners.reduce((sum, p) => sum + parseFloat(String(p.withdrawn)), 0);
  const totalPending = totalEarnings - totalWithdrawn;
  const totalSharePercent = partners.reduce((sum, p) => sum + parseFloat(String(p.revenue_share_percent)), 0);

  const columns = [
    { key: 'name', label: 'Partner Name' },
    { key: 'email', label: 'Email', render: (item: Partner) => item.email || '-' },
    { 
      key: 'revenue_share_percent', 
      label: 'Share %',
      render: (item: Partner) => (
        <span className="font-medium text-purple-400">{item.revenue_share_percent}%</span>
      )
    },
    { 
      key: 'total_earnings', 
      label: 'Total Earnings',
      render: (item: Partner) => formatCurrency(parseFloat(String(item.total_earnings)))
    },
    { 
      key: 'withdrawn', 
      label: 'Withdrawn',
      render: (item: Partner) => formatCurrency(parseFloat(String(item.withdrawn)))
    },
    { 
      key: 'balance', 
      label: 'Available',
      render: (item: Partner) => {
        const balance = parseFloat(String(item.total_earnings)) - parseFloat(String(item.withdrawn));
        return <span className="font-medium text-green-400">{formatCurrency(balance)}</span>;
      }
    },
    {
      key: 'actions',
      label: 'Actions',
      render: (item: Partner) => (
        <button
          onClick={(e) => { e.stopPropagation(); handleEdit(item); }}
          className="p-1.5 text-slate-400 hover:text-cyan-400 hover:bg-slate-700 rounded-lg transition-all"
        >
          <EditIcon size={16} />
        </button>
      )
    },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <StatCard
          title="Total Partners"
          value={partners.length}
          icon={<PartnerIcon size={24} />}
          color="purple"
        />
        <StatCard
          title="Total Distributed"
          value={formatCurrency(totalEarnings)}
          icon={<MoneyIcon size={24} />}
          color="cyan"
        />
        <StatCard
          title="Withdrawn"
          value={formatCurrency(totalWithdrawn)}
          icon={<TrendUpIcon size={24} />}
          color="blue"
        />
        <StatCard
          title="Pending Withdrawal"
          value={formatCurrency(totalPending)}
          icon={<MoneyIcon size={24} />}
          color="green"
        />
      </div>

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white">Partners</h2>
          <p className="text-sm text-slate-400">Manage revenue sharing partners</p>
        </div>
        <button
          onClick={() => { resetForm(); setEditingPartner(null); setIsModalOpen(true); }}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium rounded-xl hover:from-cyan-600 hover:to-blue-700 transition-all"
        >
          <PlusIcon size={20} />
          Add Partner
        </button>
      </div>

      {/* Revenue Share Allocation */}
      <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-white">Revenue Share Allocation (70% Bucket)</h3>
          <span className={`px-3 py-1 rounded-full text-sm font-medium ${
            totalSharePercent === 100 
              ? 'bg-green-500/20 text-green-400' 
              : 'bg-yellow-500/20 text-yellow-400'
          }`}>
            {totalSharePercent}% Allocated
          </span>
        </div>
        
        {totalSharePercent !== 100 && (
          <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-xl p-3 mb-4">
            <p className="text-sm text-yellow-400">
              Warning: Partner shares should total 100%. Currently at {totalSharePercent}%.
              {totalSharePercent < 100 && ` ${100 - totalSharePercent}% unallocated.`}
              {totalSharePercent > 100 && ` ${totalSharePercent - 100}% over-allocated.`}
            </p>
          </div>
        )}
        
        <div className="space-y-4">
          {partners.map(partner => {
            const balance = parseFloat(String(partner.total_earnings)) - parseFloat(String(partner.withdrawn));
            return (
              <div key={partner.id} className="bg-slate-900 rounded-xl p-4 border border-slate-700">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center text-white font-bold">
                      {partner.name ? partner.name.charAt(0).toUpperCase() : 'P'}
                    </div>

                    <div>
                      <p className="font-medium text-white">{partner.name}</p>
                      <p className="text-xs text-slate-400">{partner.email}</p>
                    </div>
                  </div>
                  <span className="px-3 py-1 bg-purple-500/20 text-purple-400 rounded-full text-lg font-bold">
                    {partner.revenue_share_percent}%
                  </span>
                </div>
                
                <div className="grid grid-cols-3 gap-4 text-center mb-3">
                  <div>
                    <p className="text-xs text-slate-500">Total Earned</p>
                    <p className="text-sm font-bold text-white">{formatCurrency(parseFloat(String(partner.total_earnings)))}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">Withdrawn</p>
                    <p className="text-sm font-bold text-slate-400">{formatCurrency(parseFloat(String(partner.withdrawn)))}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">Available</p>
                    <p className="text-sm font-bold text-green-400">{formatCurrency(balance)}</p>
                  </div>
                </div>
                
                <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full transition-all" 
                    style={{ width: `${partner.revenue_share_percent}%` }} 
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <DataTable
        columns={columns}
        data={partners}
        searchable
        searchPlaceholder="Search partners..."
        emptyMessage="No partners found"
      />

      {/* Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => { setIsModalOpen(false); setEditingPartner(null); }}
        title={editingPartner ? 'Edit Partner' : 'Add New Partner'}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="bg-slate-800 border border-slate-700 rounded-xl p-4 mb-4">
            <p className="text-sm text-slate-400">
              Partners receive a percentage of the REVENUE bucket (70% of all sales). 
              Ensure all partner shares total 100%.
            </p>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Partner Name *</label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              required
              placeholder="e.g., Abdullah Investments"
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Email</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Phone</label>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Revenue Share % *</label>
            <input
              type="number"
              value={formData.revenue_share_percent}
              onChange={(e) => setFormData({ ...formData, revenue_share_percent: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              required
              min="0"
              max="100"
              step="0.01"
              placeholder="e.g., 40"
            />
            <p className="text-xs text-slate-500 mt-1">
              Current total: {totalSharePercent}% | 
              {editingPartner 
                ? ` After edit: ${totalSharePercent - parseFloat(String(editingPartner.revenue_share_percent)) + (parseFloat(formData.revenue_share_percent) || 0)}%`
                : ` After add: ${totalSharePercent + (parseFloat(formData.revenue_share_percent) || 0)}%`
              }
            </p>
          </div>
          
          <div className="flex justify-end gap-3 pt-4">
            <button
              type="button"
              onClick={() => { setIsModalOpen(false); setEditingPartner(null); }}
              className="px-4 py-2 text-slate-400 hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium rounded-xl hover:from-cyan-600 hover:to-blue-700 transition-all"
            >
              {editingPartner ? 'Update' : 'Create'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default PartnersView;
