import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { AuditLog, User } from '@/types';
import DataTable from '../DataTable';
import StatCard from '../StatCard';
import { AuditIcon, UsersIcon, CalendarIcon, SearchIcon } from '../ui/Icons';

const AuditLogView: React.FC = () => {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterEntity, setFilterEntity] = useState('');
  const [filterUser, setFilterUser] = useState('');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [logsRes, usersRes] = await Promise.all([
        supabase.from('audit_log').select('*').order('created_at', { ascending: false }).limit(100),
        supabase.from('users').select('*'),
      ]);
      setLogs(logsRes.data || []);
      setUsers(usersRes.data || []);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getUserName = (id: string) => users.find(u => u.id === id)?.name || 'System';
  const getUserInitial = (id: string) => {
    const name = users.find(u => u.id === id)?.name;
    return name ? name.charAt(0).toUpperCase() : 'S';
  };


  const getActionColor = (action: string) => {
    if (action.includes('create') || action.includes('insert')) return 'text-green-400';
    if (action.includes('update') || action.includes('edit')) return 'text-blue-400';
    if (action.includes('delete') || action.includes('remove')) return 'text-red-400';
    return 'text-slate-400';
  };

  const getEntityBadge = (entity: string) => {
    const colors: Record<string, string> = {
      sales: 'bg-green-500/20 text-green-400 border-green-500/30',
      users: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
      inventory: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
      tasks: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
      complaints: 'bg-red-500/20 text-red-400 border-red-500/30',
      cash_handovers: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
    };
    return colors[entity] || 'bg-slate-500/20 text-slate-400 border-slate-500/30';
  };

  // Generate mock audit data for demo
  const mockLogs: AuditLog[] = [
    { id: '1', user_id: 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', action: 'create_sale', entity_type: 'sales', created_at: new Date().toISOString() },
    { id: '2', user_id: 'cccccccc-cccc-cccc-cccc-cccccccccccc', action: 'update_stock', entity_type: 'inventory', created_at: new Date(Date.now() - 3600000).toISOString() },
    { id: '3', user_id: 'dddddddd-dddd-dddd-dddd-dddddddddddd', action: 'confirm_handover', entity_type: 'cash_handovers', created_at: new Date(Date.now() - 7200000).toISOString() },
    { id: '4', user_id: 'ffffffff-ffff-ffff-ffff-ffffffffffff', action: 'create_complaint', entity_type: 'complaints', created_at: new Date(Date.now() - 10800000).toISOString() },
    { id: '5', user_id: 'a0000000-0000-0000-0000-000000000001', action: 'complete_task', entity_type: 'tasks', created_at: new Date(Date.now() - 14400000).toISOString() },
    { id: '6', user_id: 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', action: 'create_user', entity_type: 'users', created_at: new Date(Date.now() - 18000000).toISOString() },
    { id: '7', user_id: 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', action: 'create_sale', entity_type: 'sales', created_at: new Date(Date.now() - 21600000).toISOString() },
    { id: '8', user_id: 'eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee', action: 'update_bucket', entity_type: 'budget_buckets', created_at: new Date(Date.now() - 25200000).toISOString() },
  ];

  const displayLogs = logs.length > 0 ? logs : mockLogs;

  const filteredLogs = displayLogs.filter(log => {
    if (filterEntity && log.entity_type !== filterEntity) return false;
    if (filterUser && log.user_id !== filterUser) return false;
    return true;
  });

  const uniqueEntities = [...new Set(displayLogs.map(l => l.entity_type))];
  const uniqueUsers = [...new Set(displayLogs.map(l => l.user_id))];

  const columns = [
    {
      key: 'created_at',
      label: 'Time',
      render: (item: AuditLog) => (
        <div>
          <p className="text-sm text-white">{new Date(item.created_at).toLocaleTimeString()}</p>
          <p className="text-xs text-slate-500">{new Date(item.created_at).toLocaleDateString()}</p>
        </div>
      )
    },
    {
      key: 'user_id',
      label: 'User',
      render: (item: AuditLog) => (
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-lg flex items-center justify-center text-white text-xs font-bold">
            {getUserInitial(item.user_id)}
          </div>
          <span className="text-sm text-white">{getUserName(item.user_id)}</span>
        </div>

      )
    },
    {
      key: 'action',
      label: 'Action',
      render: (item: AuditLog) => (
        <span className={`font-medium ${getActionColor(item.action)}`}>
          {item.action.replace(/_/g, ' ')}
        </span>
      )
    },
    {
      key: 'entity_type',
      label: 'Entity',
      render: (item: AuditLog) => (
        <span className={`px-2 py-1 text-xs rounded-full border ${getEntityBadge(item.entity_type)}`}>
          {item.entity_type.replace(/_/g, ' ')}
        </span>
      )
    },
    {
      key: 'entity_id',
      label: 'Reference',
      render: (item: AuditLog) => (
        <span className="text-xs text-slate-500 font-mono">
          {item.entity_id?.slice(0, 8) || '-'}
        </span>
      )
    },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <StatCard
          title="Total Actions"
          value={displayLogs.length}
          icon={<AuditIcon size={24} />}
          color="cyan"
        />
        <StatCard
          title="Active Users"
          value={uniqueUsers.length}
          icon={<UsersIcon size={24} />}
          color="purple"
        />
        <StatCard
          title="Entity Types"
          value={uniqueEntities.length}
          icon={<AuditIcon size={24} />}
          color="blue"
        />
        <StatCard
          title="Today's Actions"
          value={displayLogs.filter(l => new Date(l.created_at).toDateString() === new Date().toDateString()).length}
          icon={<CalendarIcon size={24} />}
          color="green"
        />
      </div>

      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white">Audit Log</h2>
          <p className="text-sm text-slate-400">Complete history of all system actions</p>
        </div>
        
        <div className="flex gap-3">
          <select
            value={filterEntity}
            onChange={(e) => setFilterEntity(e.target.value)}
            className="px-4 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500"
          >
            <option value="">All Entities</option>
            {uniqueEntities.map(entity => (
              <option key={entity} value={entity}>{entity.replace(/_/g, ' ')}</option>
            ))}
          </select>
          
          <select
            value={filterUser}
            onChange={(e) => setFilterUser(e.target.value)}
            className="px-4 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500"
          >
            <option value="">All Users</option>
            {uniqueUsers.map(userId => (
              <option key={userId} value={userId}>{getUserName(userId)}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Info Box */}
      <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-xl p-4">
        <p className="text-sm text-cyan-400">
          <span className="font-medium">Full Audit Trail:</span> Every action in the system is recorded here. 
          No hidden money, no missing stock, no "I forgot", no "he said / she said". 
          Everything is traceable and accountable.
        </p>
      </div>

      {/* Timeline View */}
      <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Recent Activity Timeline</h3>
        <div className="space-y-4">
          {filteredLogs.slice(0, 10).map((log, index) => (
            <div key={log.id} className="flex gap-4">
              <div className="flex flex-col items-center">
                <div className={`w-3 h-3 rounded-full ${
                  log.action.includes('create') ? 'bg-green-500' :
                  log.action.includes('update') ? 'bg-blue-500' :
                  log.action.includes('delete') ? 'bg-red-500' : 'bg-slate-500'
                }`} />
                {index < filteredLogs.slice(0, 10).length - 1 && (
                  <div className="w-0.5 h-full bg-slate-700 mt-1" />
                )}
              </div>
              <div className="flex-1 pb-4">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-sm font-medium text-white">{getUserName(log.user_id)}</span>
                  <span className={`text-sm ${getActionColor(log.action)}`}>
                    {log.action.replace(/_/g, ' ')}
                  </span>
                  <span className={`px-2 py-0.5 text-xs rounded-full border ${getEntityBadge(log.entity_type)}`}>
                    {log.entity_type.replace(/_/g, ' ')}
                  </span>
                </div>
                <p className="text-xs text-slate-500">
                  {new Date(log.created_at).toLocaleString()}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <DataTable
        columns={columns}
        data={filteredLogs}
        searchable
        searchPlaceholder="Search audit log..."
        emptyMessage="No audit entries found"
      />
    </div>
  );
};

export default AuditLogView;
