import React, { useState, useEffect, useRef } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { playSuccessChime, playErrorSound, playHandoverSound } from '@/lib/notifications';
import StatCard from '../StatCard';
import Modal from '../Modal';
import { MoneyIcon, SalesIcon, AlertIcon, PlusIcon, PrintIcon, UsersIcon } from '../ui/Icons';

interface Sale {
  id: string;
  sale_number: string;
  customer_name: string;
  customer_phone: string;
  amount: number;
  is_paid: boolean;
  created_at: string;
  shopkeeper?: { name: string };
}

interface Shopkeeper {
  id: string;
  name: string;
  phone: string;
  balance: number;
}

interface HandoverReceipt {
  handover_number: string;
  branch_name: string;
  sales_person: string;
  total_payable: number;
  amount: number;
  date: string;
}

const BranchSalesDashboard: React.FC = () => {
  const { currentUser } = useAuth();
  const [loading, setLoading] = useState(true);
  const [todaySales, setTodaySales] = useState<Sale[]>([]);
  const [unpaidSales, setUnpaidSales] = useState<Sale[]>([]);
  const [shopkeepers, setShopkeepers] = useState<Shopkeeper[]>([]);
  const [totalPayable, setTotalPayable] = useState(0);
  
  const [isSaleModalOpen, setIsSaleModalOpen] = useState(false);
  const [isHandoverModalOpen, setIsHandoverModalOpen] = useState(false);
  const [isShopkeeperModalOpen, setIsShopkeeperModalOpen] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [isPrintReceiptOpen, setIsPrintReceiptOpen] = useState(false);
  const [selectedSale, setSelectedSale] = useState<Sale | null>(null);
  const [handoverReceipt, setHandoverReceipt] = useState<HandoverReceipt | null>(null);

  const [saleForm, setSaleForm] = useState({
    customer_name: '',
    customer_phone: '',
    amount: '',
    shopkeeper_id: '',
  });
  const [handoverForm, setHandoverForm] = useState({ amount: '' });
  const [shopkeeperForm, setShopkeeperForm] = useState({ name: '', phone: '' });
  const [paymentForm, setPaymentForm] = useState({ amount: '' });

  const printRef = useRef<HTMLDivElement>(null);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US').format(amount) + ' AFN';
  };

  const fetchData = async () => {
    setLoading(true);
    try {
      const branchId = currentUser?.branch_id || '11111111-1111-1111-1111-111111111111';
      const userId = currentUser?.id || 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb';
      const today = new Date().toISOString().split('T')[0];

      // Fetch today's sales by this user
      const { data: todaySalesData } = await supabase
        .from('sales')
        .select('*, shopkeeper:shopkeepers(name)')
        .eq('created_by', userId)
        .gte('created_at', `${today}T00:00:00`)
        .order('created_at', { ascending: false });
      setTodaySales(todaySalesData || []);

      // Fetch unpaid sales by this user (for follow-ups)
      const { data: unpaidData } = await supabase
        .from('sales')
        .select('*, shopkeeper:shopkeepers(name)')
        .eq('created_by', userId)
        .eq('is_paid', false)
        .order('created_at', { ascending: false });
      setUnpaidSales(unpaidData || []);

      // Fetch shopkeepers for this branch
      const { data: shopkeepersData } = await supabase
        .from('shopkeepers')
        .select('*')
        .eq('branch_id', branchId)
        .eq('is_active', true);
      setShopkeepers(shopkeepersData || []);

      // Calculate total payable (paid sales not yet handed over)
      const paidNotHandedOver = (todaySalesData || [])
        .filter(s => s.is_paid)
        .reduce((sum, s) => sum + Number(s.amount), 0);
      setTotalPayable(paidNotHandedOver);

    } catch (error) {
      console.error('Error fetching data:', error);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchData();

    // Subscribe to real-time updates
    const channel = supabase
      .channel('sales-updates')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'sales' }, () => {
        fetchData();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [currentUser]);

  const todayPaidTotal = todaySales.filter(s => s.is_paid).reduce((sum, s) => sum + Number(s.amount), 0);
  const todayUnpaidTotal = todaySales.filter(s => !s.is_paid).reduce((sum, s) => sum + Number(s.amount), 0);

  const handleCreateSale = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const amount = parseFloat(saleForm.amount);
      const saleNumber = `SL-${new Date().getFullYear()}-${String(Date.now()).slice(-6)}`;
      const branchId = currentUser?.branch_id || '11111111-1111-1111-1111-111111111111';
      const userId = currentUser?.id || 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb';

      const { error } = await supabase.from('sales').insert({
        sale_number: saleNumber,
        customer_name: saleForm.customer_name,
        customer_phone: saleForm.customer_phone,
        branch_id: branchId,
        created_by: userId,
        shopkeeper_id: saleForm.shopkeeper_id || null,
        amount: amount,
        tax_amount: amount * 0.1,
        dev_amount: amount * 0.2,
        revenue_amount: amount * 0.7,
        is_paid: false,
      });

      if (error) throw error;

      // If shopkeeper is selected, update their balance
      if (saleForm.shopkeeper_id) {
        const shopkeeper = shopkeepers.find(s => s.id === saleForm.shopkeeper_id);
        if (shopkeeper) {
          await supabase
            .from('shopkeepers')
            .update({ balance: shopkeeper.balance + amount })
            .eq('id', saleForm.shopkeeper_id);
        }
      }

      await supabase.from('audit_logs').insert({
        user_id: userId,
        action: 'CREATE_SALE',
        entity_type: 'sale',
        new_data: { sale_number: saleNumber, amount, customer: saleForm.customer_name }
      });

      playSuccessChime();
      setIsSaleModalOpen(false);
      setSaleForm({ customer_name: '', customer_phone: '', amount: '', shopkeeper_id: '' });
      fetchData();
    } catch (error) {
      console.error('Error creating sale:', error);
      playErrorSound();
    }
  };

  const handleMarkPaid = async (sale: Sale) => {
    try {
      await supabase
        .from('sales')
        .update({ is_paid: true, paid_at: new Date().toISOString() })
        .eq('id', sale.id);

      // Update budget buckets
      const amount = Number(sale.amount);
      const { data: buckets } = await supabase.from('budget_buckets').select('*');
      
      for (const bucket of buckets || []) {
        const addAmount = bucket.name === 'TAX' ? amount * 0.1 :
                         bucket.name === 'DEV' ? amount * 0.2 :
                         amount * 0.7;
        await supabase
          .from('budget_buckets')
          .update({ current_balance: Number(bucket.current_balance) + addAmount })
          .eq('id', bucket.id);
      }

      await supabase.from('audit_logs').insert({
        user_id: currentUser?.id || 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb',
        action: 'MARK_SALE_PAID',
        entity_type: 'sale',
        entity_id: sale.id,
        new_data: { sale_number: sale.sale_number, amount: sale.amount }
      });

      playSuccessChime();
      setIsPaymentModalOpen(false);
      setSelectedSale(null);
      setPaymentForm({ amount: '' });
      fetchData();
    } catch (error) {
      console.error('Error marking sale as paid:', error);
      playErrorSound();
    }
  };

  const handleCashHandover = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const amount = parseFloat(handoverForm.amount);
      if (amount > totalPayable) {
        playErrorSound();
        alert('Handover amount cannot exceed total payable!');
        return;
      }

      const handoverNumber = `CH-${new Date().getFullYear()}-${String(Date.now()).slice(-6)}`;
      const branchId = currentUser?.branch_id || '11111111-1111-1111-1111-111111111111';
      const userId = currentUser?.id || 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb';

      // Get branch name
      const { data: branch } = await supabase
        .from('branches')
        .select('name')
        .eq('id', branchId)
        .single();

      const { error } = await supabase.from('cash_handovers').insert({
        handover_number: handoverNumber,
        branch_id: branchId,
        handed_by: userId,
        total_payable: totalPayable,
        amount: amount,
        remaining_balance: totalPayable - amount,
        status: 'pending',
      });

      if (error) throw error;

      // Create notification for Cashier
      await supabase.from('notifications').insert({
        user_id: 'dddddddd-dddd-dddd-dddd-dddddddddddd',
        title: 'Cash Handover Pending',
        message: `${currentUser?.name || 'Branch Sales'} has submitted ${formatCurrency(amount)} for handover. Please confirm receipt.`,
        type: 'handover',
      });

      await supabase.from('audit_logs').insert({
        user_id: userId,
        action: 'CREATE_HANDOVER',
        entity_type: 'cash_handover',
        new_data: { handover_number: handoverNumber, amount, total_payable: totalPayable }
      });

      // Set receipt for printing
      setHandoverReceipt({
        handover_number: handoverNumber,
        branch_name: branch?.name || 'Main Branch',
        sales_person: currentUser?.name || 'Branch Sales',
        total_payable: totalPayable,
        amount: amount,
        date: new Date().toLocaleString(),
      });

      playHandoverSound();
      setIsHandoverModalOpen(false);
      setHandoverForm({ amount: '' });
      setIsPrintReceiptOpen(true);
      fetchData();
    } catch (error) {
      console.error('Error creating handover:', error);
      playErrorSound();
    }
  };

  const handleAddShopkeeper = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const branchId = currentUser?.branch_id || '11111111-1111-1111-1111-111111111111';
      const userId = currentUser?.id || 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb';

      const { error } = await supabase.from('shopkeepers').insert({
        name: shopkeeperForm.name,
        phone: shopkeeperForm.phone,
        branch_id: branchId,
        created_by: userId,
        balance: 0,
      });

      if (error) throw error;

      playSuccessChime();
      setIsShopkeeperModalOpen(false);
      setShopkeeperForm({ name: '', phone: '' });
      fetchData();
    } catch (error) {
      console.error('Error adding shopkeeper:', error);
      playErrorSound();
    }
  };

  const handlePrintReceipt = () => {
    const printContent = document.getElementById('handover-receipt');
    if (printContent) {
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(`
          <html>
            <head>
              <title>Cash Handover Receipt</title>
              <style>
                body { font-family: Arial, sans-serif; padding: 20px; max-width: 400px; margin: 0 auto; }
                .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 10px; margin-bottom: 20px; }
                .row { display: flex; justify-content: space-between; margin: 10px 0; }
                .label { font-weight: bold; }
                .amount { font-size: 24px; text-align: center; margin: 20px 0; padding: 10px; border: 2px solid #000; }
                .signature { margin-top: 50px; display: flex; justify-content: space-between; }
                .sig-line { width: 45%; text-align: center; border-top: 1px solid #000; padding-top: 5px; }
                .footer { text-align: center; margin-top: 30px; font-size: 12px; color: #666; }
              </style>
            </head>
            <body>
              ${printContent.innerHTML}
            </body>
          </html>
        `);
        printWindow.document.close();
        printWindow.print();
      }
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards - Only Today's Sales and Unpaid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Today's Sales"
          value={formatCurrency(todayPaidTotal + todayUnpaidTotal)}
          subtitle={`${todaySales.length} transactions`}
          icon={<SalesIcon size={24} />}
          color="cyan"
        />
        <StatCard
          title="Today's Paid"
          value={formatCurrency(todayPaidTotal)}
          subtitle="Collected"
          icon={<MoneyIcon size={24} />}
          color="green"
        />
        <StatCard
          title="Unpaid Sales"
          value={formatCurrency(unpaidSales.reduce((sum, s) => sum + Number(s.amount), 0))}
          subtitle={`${unpaidSales.length} pending`}
          icon={<AlertIcon size={24} />}
          color="orange"
        />
        <StatCard
          title="Total Payable"
          value={formatCurrency(totalPayable)}
          subtitle="Ready for handover"
          icon={<MoneyIcon size={24} />}
          color="purple"
        />
      </div>

      {/* Action Buttons */}
      <div className="flex flex-wrap gap-3">
        <button
          onClick={() => setIsSaleModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium rounded-xl hover:opacity-90"
        >
          <PlusIcon size={20} />
          New Sale
        </button>
        <button
          onClick={() => setIsHandoverModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-green-500 to-emerald-600 text-white font-medium rounded-xl hover:opacity-90"
          disabled={totalPayable <= 0}
        >
          <MoneyIcon size={20} />
          Cash Handover
        </button>
        <button
          onClick={() => setIsShopkeeperModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-purple-500 to-pink-600 text-white font-medium rounded-xl hover:opacity-90"
        >
          <UsersIcon size={20} />
          Add Shopkeeper
        </button>
      </div>

      {/* Today's Sales */}
      <div className="bg-slate-800/50 border border-slate-700 rounded-2xl overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-700">
          <h3 className="font-semibold text-white">Today's Sales</h3>
        </div>
        <div className="divide-y divide-slate-700/50">
          {todaySales.length === 0 ? (
            <p className="p-4 text-slate-400 text-center">No sales today yet</p>
          ) : (
            todaySales.map(sale => (
              <div key={sale.id} className="p-4 flex items-center justify-between">
                <div>
                  <p className="font-medium text-white">{sale.sale_number}</p>
                  <p className="text-sm text-slate-400">{sale.customer_name}</p>
                  {sale.shopkeeper && (
                    <p className="text-xs text-cyan-400">via {sale.shopkeeper.name}</p>
                  )}
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <p className="font-bold text-white">{formatCurrency(Number(sale.amount))}</p>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${
                      sale.is_paid ? 'bg-green-500/20 text-green-400' : 'bg-orange-500/20 text-orange-400'
                    }`}>
                      {sale.is_paid ? 'Paid' : 'Unpaid'}
                    </span>
                  </div>
                  {!sale.is_paid && (
                    <button
                      onClick={() => { setSelectedSale(sale); setPaymentForm({ amount: String(sale.amount) }); setIsPaymentModalOpen(true); }}
                      className="px-3 py-1.5 bg-green-600 text-white text-sm rounded-lg hover:bg-green-700"
                    >
                      Mark Paid
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Unpaid Sales for Follow-up */}
      {unpaidSales.length > 0 && (
        <div className="bg-orange-500/10 border border-orange-500/30 rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-orange-500/30">
            <h3 className="font-semibold text-orange-400">Unpaid Sales - Follow Up Required</h3>
          </div>
          <div className="divide-y divide-orange-500/20">
            {unpaidSales.map(sale => (
              <div key={sale.id} className="p-4 flex items-center justify-between">
                <div>
                  <p className="font-medium text-white">{sale.sale_number}</p>
                  <p className="text-sm text-slate-400">{sale.customer_name} - {sale.customer_phone}</p>
                  <p className="text-xs text-slate-500">{new Date(sale.created_at).toLocaleDateString()}</p>
                </div>
                <div className="flex items-center gap-3">
                  <p className="font-bold text-orange-400">{formatCurrency(Number(sale.amount))}</p>
                  <button
                    onClick={() => { setSelectedSale(sale); setPaymentForm({ amount: String(sale.amount) }); setIsPaymentModalOpen(true); }}
                    className="px-3 py-1.5 bg-green-600 text-white text-sm rounded-lg hover:bg-green-700"
                  >
                    Mark Paid
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Shopkeepers */}
      <div className="bg-slate-800/50 border border-slate-700 rounded-2xl overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-700">
          <h3 className="font-semibold text-white">My Shopkeepers</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4">
          {shopkeepers.length === 0 ? (
            <p className="col-span-3 text-slate-400 text-center py-4">No shopkeepers yet</p>
          ) : (
            shopkeepers.map(sk => (
              <div key={sk.id} className="bg-slate-900 border border-slate-700 rounded-xl p-4">
                <p className="font-medium text-white">{sk.name}</p>
                <p className="text-sm text-slate-400">{sk.phone}</p>
                <p className="text-sm text-cyan-400 mt-2">Balance: {formatCurrency(Number(sk.balance))}</p>
              </div>
            ))
          )}
        </div>
      </div>

      {/* New Sale Modal */}
      <Modal isOpen={isSaleModalOpen} onClose={() => setIsSaleModalOpen(false)} title="New Sale">
        <form onSubmit={handleCreateSale} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Customer Name *</label>
            <input
              type="text"
              value={saleForm.customer_name}
              onChange={(e) => setSaleForm({ ...saleForm, customer_name: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Customer Phone</label>
            <input
              type="tel"
              value={saleForm.customer_phone}
              onChange={(e) => setSaleForm({ ...saleForm, customer_phone: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Amount (AFN) *</label>
            <input
              type="number"
              value={saleForm.amount}
              onChange={(e) => setSaleForm({ ...saleForm, amount: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white"
              required
              min="0"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Shopkeeper (Optional)</label>
            <select
              value={saleForm.shopkeeper_id}
              onChange={(e) => setSaleForm({ ...saleForm, shopkeeper_id: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white"
            >
              <option value="">Direct Sale</option>
              {shopkeepers.map(sk => (
                <option key={sk.id} value={sk.id}>{sk.name}</option>
              ))}
            </select>
          </div>
          <div className="flex justify-end gap-3 pt-4">
            <button type="button" onClick={() => setIsSaleModalOpen(false)} className="px-4 py-2 text-slate-400">Cancel</button>
            <button type="submit" className="px-6 py-2 bg-cyan-600 text-white font-medium rounded-xl hover:bg-cyan-700">Create Sale</button>
          </div>
        </form>
      </Modal>

      {/* Cash Handover Modal */}
      <Modal isOpen={isHandoverModalOpen} onClose={() => setIsHandoverModalOpen(false)} title="Cash Handover">
        <form onSubmit={handleCashHandover} className="space-y-4">
          <div className="bg-slate-800 border border-slate-700 rounded-xl p-4">
            <p className="text-slate-400">Total Payable:</p>
            <p className="text-2xl font-bold text-green-400">{formatCurrency(totalPayable)}</p>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Handover Amount (AFN) *</label>
            <input
              type="number"
              value={handoverForm.amount}
              onChange={(e) => setHandoverForm({ amount: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white"
              required
              min="0"
              max={totalPayable}
              placeholder={String(totalPayable)}
            />
          </div>
          <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-xl p-3 text-sm text-yellow-400">
            After handover, get cashier signature on the receipt and submit to Accounts.
          </div>
          <div className="flex justify-end gap-3 pt-4">
            <button type="button" onClick={() => setIsHandoverModalOpen(false)} className="px-4 py-2 text-slate-400">Cancel</button>
            <button type="submit" className="px-6 py-2 bg-green-600 text-white font-medium rounded-xl hover:bg-green-700">Submit Handover</button>
          </div>
        </form>
      </Modal>

      {/* Add Shopkeeper Modal */}
      <Modal isOpen={isShopkeeperModalOpen} onClose={() => setIsShopkeeperModalOpen(false)} title="Add Shopkeeper">
        <form onSubmit={handleAddShopkeeper} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Name *</label>
            <input
              type="text"
              value={shopkeeperForm.name}
              onChange={(e) => setShopkeeperForm({ ...shopkeeperForm, name: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Phone</label>
            <input
              type="tel"
              value={shopkeeperForm.phone}
              onChange={(e) => setShopkeeperForm({ ...shopkeeperForm, phone: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white"
            />
          </div>
          <div className="flex justify-end gap-3 pt-4">
            <button type="button" onClick={() => setIsShopkeeperModalOpen(false)} className="px-4 py-2 text-slate-400">Cancel</button>
            <button type="submit" className="px-6 py-2 bg-purple-600 text-white font-medium rounded-xl hover:bg-purple-700">Add Shopkeeper</button>
          </div>
        </form>
      </Modal>

      {/* Mark Payment Modal */}
      <Modal isOpen={isPaymentModalOpen} onClose={() => { setIsPaymentModalOpen(false); setSelectedSale(null); }} title="Mark as Paid">
        {selectedSale && (
          <div className="space-y-4">
            <div className="bg-slate-800 border border-slate-700 rounded-xl p-4">
              <p className="text-white font-medium">{selectedSale.sale_number}</p>
              <p className="text-slate-400">{selectedSale.customer_name}</p>
              <p className="text-2xl font-bold text-cyan-400 mt-2">{formatCurrency(Number(selectedSale.amount))}</p>
            </div>
            <div className="flex justify-end gap-3 pt-4">
              <button onClick={() => { setIsPaymentModalOpen(false); setSelectedSale(null); }} className="px-4 py-2 text-slate-400">Cancel</button>
              <button onClick={() => handleMarkPaid(selectedSale)} className="px-6 py-2 bg-green-600 text-white font-medium rounded-xl hover:bg-green-700">Confirm Payment</button>
            </div>
          </div>
        )}
      </Modal>

      {/* Print Receipt Modal */}
      <Modal isOpen={isPrintReceiptOpen} onClose={() => setIsPrintReceiptOpen(false)} title="Handover Receipt">
        {handoverReceipt && (
          <div className="space-y-4">
            <div id="handover-receipt" className="bg-white text-black p-6 rounded-xl">
              <div className="header text-center border-b-2 border-black pb-3 mb-4">
                <h2 className="text-xl font-bold">Work.PWA</h2>
                <p className="text-sm">Cash Handover Receipt</p>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="font-medium">Receipt No:</span>
                  <span>{handoverReceipt.handover_number}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Branch:</span>
                  <span>{handoverReceipt.branch_name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Sales Person:</span>
                  <span>{handoverReceipt.sales_person}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Date:</span>
                  <span>{handoverReceipt.date}</span>
                </div>
              </div>
              <div className="text-center my-6 py-4 border-2 border-black">
                <p className="text-sm">Amount Handed Over</p>
                <p className="text-3xl font-bold">{formatCurrency(handoverReceipt.amount)}</p>
              </div>
              <div className="flex justify-between mt-12 pt-4">
                <div className="text-center w-2/5 border-t border-black pt-2">
                  <p className="text-sm">Sales Person</p>
                </div>
                <div className="text-center w-2/5 border-t border-black pt-2">
                  <p className="text-sm">Cashier Signature</p>
                </div>
              </div>
              <p className="text-center text-xs mt-6 text-gray-500">
                Submit this signed receipt to Accounts
              </p>
            </div>
            <button
              onClick={handlePrintReceipt}
              className="w-full py-3 bg-cyan-600 text-white font-medium rounded-xl hover:bg-cyan-700 flex items-center justify-center gap-2"
            >
              <PrintIcon size={20} />
              Print Receipt
            </button>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default BranchSalesDashboard;
