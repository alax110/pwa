import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { PenaltyRule, BonusRule } from '@/types';
import DataTable from '../DataTable';
import Modal from '../Modal';
import StatCard from '../StatCard';
import { PlusIcon, SettingsIcon, EditIcon, AlertIcon, CheckIcon } from '../ui/Icons';

const RulesView: React.FC = () => {
  const [penaltyRules, setPenaltyRules] = useState<PenaltyRule[]>([]);
  const [bonusRules, setBonusRules] = useState<BonusRule[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'penalties' | 'bonuses'>('penalties');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingRule, setEditingRule] = useState<PenaltyRule | BonusRule | null>(null);
  const [formData, setFormData] = useState({
    code: '',
    name: '',
    description: '',
    amount: '',
    is_percentage: false,
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [penaltiesRes, bonusesRes] = await Promise.all([
        supabase.from('penalty_rules').select('*').order('code'),
        supabase.from('bonus_rules').select('*').order('code'),
      ]);
      setPenaltyRules(penaltiesRes.data || []);
      setBonusRules(bonusesRes.data || []);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const table = activeTab === 'penalties' ? 'penalty_rules' : 'bonus_rules';
      const data = {
        code: formData.code,
        name: formData.name,
        description: formData.description,
        amount: parseFloat(formData.amount),
        is_percentage: formData.is_percentage,
      };

      if (editingRule) {
        await supabase.from(table).update(data).eq('id', editingRule.id);
      } else {
        await supabase.from(table).insert(data);
      }

      setIsModalOpen(false);
      setEditingRule(null);
      resetForm();
      fetchData();
    } catch (error) {
      console.error('Error saving rule:', error);
    }
  };

  const handleEdit = (rule: PenaltyRule | BonusRule) => {
    setEditingRule(rule);
    setFormData({
      code: rule.code,
      name: rule.name,
      description: rule.description || '',
      amount: String(rule.amount),
      is_percentage: rule.is_percentage,
    });
    setIsModalOpen(true);
  };

  const handleToggleActive = async (rule: PenaltyRule | BonusRule, type: 'penalty' | 'bonus') => {
    const table = type === 'penalty' ? 'penalty_rules' : 'bonus_rules';
    await supabase.from(table).update({ is_active: !rule.is_active }).eq('id', rule.id);
    fetchData();
  };

  const resetForm = () => {
    setFormData({
      code: '',
      name: '',
      description: '',
      amount: '',
      is_percentage: false,
    });
  };

  const formatAmount = (rule: PenaltyRule | BonusRule) => {
    if (rule.is_percentage) {
      return `${rule.amount}%`;
    }
    return `${rule.amount} AFN`;
  };

  const penaltyColumns = [
    { key: 'code', label: 'Code', render: (item: PenaltyRule) => (
      <span className="font-mono text-red-400">{item.code}</span>
    )},
    { key: 'name', label: 'Name' },
    { key: 'description', label: 'Description', render: (item: PenaltyRule) => item.description || '-' },
    { key: 'amount', label: 'Amount', render: (item: PenaltyRule) => (
      <span className="font-medium text-red-400">{formatAmount(item)}</span>
    )},
    { key: 'is_active', label: 'Status', render: (item: PenaltyRule) => (
      <button
        onClick={(e) => { e.stopPropagation(); handleToggleActive(item, 'penalty'); }}
        className={`px-2 py-1 text-xs rounded-full border ${
          item.is_active 
            ? 'bg-green-500/20 text-green-400 border-green-500/30' 
            : 'bg-slate-500/20 text-slate-400 border-slate-500/30'
        }`}
      >
        {item.is_active ? 'Active' : 'Inactive'}
      </button>
    )},
    { key: 'actions', label: 'Actions', render: (item: PenaltyRule) => (
      <button
        onClick={(e) => { e.stopPropagation(); handleEdit(item); }}
        className="p-1.5 text-slate-400 hover:text-cyan-400 hover:bg-slate-700 rounded-lg transition-all"
      >
        <EditIcon size={16} />
      </button>
    )},
  ];

  const bonusColumns = [
    { key: 'code', label: 'Code', render: (item: BonusRule) => (
      <span className="font-mono text-green-400">{item.code}</span>
    )},
    { key: 'name', label: 'Name' },
    { key: 'description', label: 'Description', render: (item: BonusRule) => item.description || '-' },
    { key: 'amount', label: 'Amount', render: (item: BonusRule) => (
      <span className="font-medium text-green-400">{formatAmount(item)}</span>
    )},
    { key: 'is_active', label: 'Status', render: (item: BonusRule) => (
      <button
        onClick={(e) => { e.stopPropagation(); handleToggleActive(item, 'bonus'); }}
        className={`px-2 py-1 text-xs rounded-full border ${
          item.is_active 
            ? 'bg-green-500/20 text-green-400 border-green-500/30' 
            : 'bg-slate-500/20 text-slate-400 border-slate-500/30'
        }`}
      >
        {item.is_active ? 'Active' : 'Inactive'}
      </button>
    )},
    { key: 'actions', label: 'Actions', render: (item: BonusRule) => (
      <button
        onClick={(e) => { e.stopPropagation(); handleEdit(item); }}
        className="p-1.5 text-slate-400 hover:text-cyan-400 hover:bg-slate-700 rounded-lg transition-all"
      >
        <EditIcon size={16} />
      </button>
    )},
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <StatCard
          title="Penalty Rules"
          value={penaltyRules.length}
          icon={<AlertIcon size={24} />}
          color="red"
        />
        <StatCard
          title="Active Penalties"
          value={penaltyRules.filter(r => r.is_active).length}
          icon={<AlertIcon size={24} />}
          color="orange"
        />
        <StatCard
          title="Bonus Rules"
          value={bonusRules.length}
          icon={<CheckIcon size={24} />}
          color="green"
        />
        <StatCard
          title="Active Bonuses"
          value={bonusRules.filter(r => r.is_active).length}
          icon={<CheckIcon size={24} />}
          color="cyan"
        />
      </div>

      {/* Tabs */}
      <div className="flex items-center justify-between">
        <div className="flex gap-2">
          <button
            onClick={() => setActiveTab('penalties')}
            className={`px-4 py-2 rounded-xl font-medium transition-all ${
              activeTab === 'penalties'
                ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            Penalty Rules
          </button>
          <button
            onClick={() => setActiveTab('bonuses')}
            className={`px-4 py-2 rounded-xl font-medium transition-all ${
              activeTab === 'bonuses'
                ? 'bg-green-500/20 text-green-400 border border-green-500/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            Bonus Rules
          </button>
        </div>
        
        <button
          onClick={() => { resetForm(); setEditingRule(null); setIsModalOpen(true); }}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium rounded-xl hover:from-cyan-600 hover:to-blue-700 transition-all"
        >
          <PlusIcon size={20} />
          Add {activeTab === 'penalties' ? 'Penalty' : 'Bonus'} Rule
        </button>
      </div>

      {/* Info Box */}
      <div className={`border rounded-xl p-4 ${
        activeTab === 'penalties' 
          ? 'bg-red-500/10 border-red-500/30' 
          : 'bg-green-500/10 border-green-500/30'
      }`}>
        <p className={`text-sm ${activeTab === 'penalties' ? 'text-red-400' : 'text-green-400'}`}>
          {activeTab === 'penalties' 
            ? 'Penalty rules are automatically applied by NOC when engineers fail to meet SLAs or cause issues. These deductions affect salary calculations.'
            : 'Bonus rules reward employees for good performance. These are credited to their salary based on completed tasks and referrals.'}
        </p>
      </div>

      {/* Rules Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {(activeTab === 'penalties' ? penaltyRules : bonusRules).map(rule => (
          <div 
            key={rule.id} 
            className={`bg-slate-800/50 border rounded-2xl p-5 ${
              rule.is_active 
                ? activeTab === 'penalties' ? 'border-red-500/30' : 'border-green-500/30'
                : 'border-slate-700 opacity-60'
            }`}
          >
            <div className="flex items-start justify-between mb-3">
              <div>
                <span className={`font-mono text-lg font-bold ${
                  activeTab === 'penalties' ? 'text-red-400' : 'text-green-400'
                }`}>
                  {rule.code}
                </span>
                <h3 className="font-medium text-white">{rule.name}</h3>
              </div>
              <span className={`px-2 py-1 text-xs rounded-full ${
                rule.is_active 
                  ? 'bg-green-500/20 text-green-400' 
                  : 'bg-slate-500/20 text-slate-400'
              }`}>
                {rule.is_active ? 'Active' : 'Inactive'}
              </span>
            </div>
            
            <p className="text-sm text-slate-400 mb-4">{rule.description || 'No description'}</p>
            
            <div className="flex items-center justify-between">
              <span className={`text-2xl font-bold ${
                activeTab === 'penalties' ? 'text-red-400' : 'text-green-400'
              }`}>
                {activeTab === 'penalties' ? '-' : '+'}{formatAmount(rule)}
              </span>
              <button
                onClick={() => handleEdit(rule)}
                className="p-2 text-slate-400 hover:text-cyan-400 hover:bg-slate-700 rounded-lg transition-all"
              >
                <EditIcon size={18} />
              </button>
            </div>
          </div>
        ))}
      </div>

      <DataTable
        columns={activeTab === 'penalties' ? penaltyColumns : bonusColumns}
        data={activeTab === 'penalties' ? penaltyRules : bonusRules}
        emptyMessage={`No ${activeTab} rules found`}
      />

      {/* Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => { setIsModalOpen(false); setEditingRule(null); }}
        title={`${editingRule ? 'Edit' : 'Add'} ${activeTab === 'penalties' ? 'Penalty' : 'Bonus'} Rule`}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Code *</label>
              <input
                type="text"
                value={formData.code}
                onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                required
                placeholder={activeTab === 'penalties' ? 'P4' : 'B4'}
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Amount *</label>
              <input
                type="number"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                required
                min="0"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Name *</label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              required
              placeholder="e.g., Late Installation"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Description</label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              rows={2}
            />
          </div>
          
          <div className="flex items-center gap-3">
            <input
              type="checkbox"
              id="is_percentage"
              checked={formData.is_percentage}
              onChange={(e) => setFormData({ ...formData, is_percentage: e.target.checked })}
              className="w-4 h-4 rounded border-slate-600 bg-slate-800 text-cyan-500 focus:ring-cyan-500"
            />
            <label htmlFor="is_percentage" className="text-sm text-slate-300">
              Amount is a percentage (of salary)
            </label>
          </div>
          
          <div className="flex justify-end gap-3 pt-4">
            <button
              type="button"
              onClick={() => { setIsModalOpen(false); setEditingRule(null); }}
              className="px-4 py-2 text-slate-400 hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium rounded-xl hover:from-cyan-600 hover:to-blue-700 transition-all"
            >
              {editingRule ? 'Update' : 'Create'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default RulesView;
