import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { User, UserRole, Branch } from '@/types';
import DataTable from '../DataTable';
import Modal from '../Modal';
import { PlusIcon, EditIcon, TrashIcon } from '../ui/Icons';

const UsersView: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [selectedUserForPassword, setSelectedUserForPassword] = useState<User | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    role: 'engineer' as UserRole,
    branch_id: '',
    phone: '',
  });

  const [passwordFormData, setPasswordFormData] = useState({
    newPassword: '',
    confirmPassword: '',
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [usersRes, branchesRes] = await Promise.all([
        supabase.from('users').select('*').order('created_at', { ascending: false }),
        supabase.from('branches').select('*'),
      ]);
      setUsers(usersRes.data || []);
      setBranches(branchesRes.data || []);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setSaving(true);

    try {
      if (editingUser) {
        // Update existing user
        const { data, error } = await supabase.functions.invoke('auth', {
          body: {
            action: 'update_user',
            user_id: editingUser.id,
            updates: {
              name: formData.name,
              email: formData.email,
              role: formData.role,
              branch_id: formData.branch_id || null,
              phone: formData.phone,
            }
          }
        });

        if (error || data?.error) {
          throw new Error(data?.error || 'Failed to update user');
        }

        setSuccess('User updated successfully!');
      } else {
        // Create new user with password
        if (!formData.password) {
          throw new Error('Password is required for new users');
        }
        
        if (formData.password !== formData.confirmPassword) {
          throw new Error('Passwords do not match');
        }

        if (formData.password.length < 6) {
          throw new Error('Password must be at least 6 characters');
        }

        const { data, error } = await supabase.functions.invoke('auth', {
          body: {
            action: 'register',
            email: formData.email,
            password: formData.password,
            name: formData.name,
            role: formData.role,
            branch_id: formData.branch_id || null,
          }
        });

        if (error || data?.error) {
          throw new Error(data?.error || 'Failed to create user');
        }

        // Update phone if provided
        if (formData.phone && data?.user?.id) {
          await supabase.from('users').update({ phone: formData.phone }).eq('id', data.user.id);
        }

        setSuccess('User created successfully! They can now login with their email and password.');
      }

      setTimeout(() => {
        setIsModalOpen(false);
        setEditingUser(null);
        resetForm();
        fetchData();
      }, 1500);
    } catch (err: any) {
      setError(err.message || 'An error occurred');
    } finally {
      setSaving(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setSaving(true);

    try {
      if (passwordFormData.newPassword !== passwordFormData.confirmPassword) {
        throw new Error('Passwords do not match');
      }

      if (passwordFormData.newPassword.length < 6) {
        throw new Error('Password must be at least 6 characters');
      }

      const { data, error } = await supabase.functions.invoke('auth', {
        body: {
          action: 'reset_password',
          email: selectedUserForPassword?.email,
          password: passwordFormData.newPassword,
        }
      });

      if (error || data?.error) {
        throw new Error(data?.error || 'Failed to reset password');
      }

      setSuccess('Password reset successfully!');
      setTimeout(() => {
        setIsPasswordModalOpen(false);
        setSelectedUserForPassword(null);
        setPasswordFormData({ newPassword: '', confirmPassword: '' });
      }, 1500);
    } catch (err: any) {
      setError(err.message || 'An error occurred');
    } finally {
      setSaving(false);
    }
  };

  const handleEdit = (user: User) => {
    setEditingUser(user);
    setFormData({
      name: user.name || '',
      email: user.email || '',
      password: '',
      confirmPassword: '',
      role: user.role,
      branch_id: user.branch_id || '',
      phone: user.phone || '',
    });
    setError('');
    setSuccess('');
    setIsModalOpen(true);
  };

  const handlePasswordReset = (user: User) => {
    setSelectedUserForPassword(user);
    setPasswordFormData({ newPassword: '', confirmPassword: '' });
    setError('');
    setSuccess('');
    setIsPasswordModalOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (id === 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa') {
      alert('Cannot delete the system administrator account.');
      return;
    }

    if (confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
      try {
        const { data, error } = await supabase.functions.invoke('auth', {
          body: {
            action: 'delete_user',
            user_id: id,
          }
        });

        if (error || data?.error) {
          throw new Error(data?.error || 'Failed to delete user');
        }

        fetchData();
      } catch (err: any) {
        alert('Error deleting user: ' + (err.message || 'Unknown error'));
      }
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      email: '',
      password: '',
      confirmPassword: '',
      role: 'engineer',
      branch_id: '',
      phone: '',
    });
    setError('');
    setSuccess('');
  };

  const getRoleBadge = (role: UserRole) => {
    const colors: Record<UserRole, string> = {
      admin: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
      branch_sales: 'bg-green-500/20 text-green-400 border-green-500/30',
      inventory: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
      cashier: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
      accounts: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
      noc: 'bg-red-500/20 text-red-400 border-red-500/30',
      engineer: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
    };
    const labels: Record<UserRole, string> = {
      admin: 'Admin',
      branch_sales: 'Branch Sales',
      inventory: 'Inventory',
      cashier: 'Cashier',
      accounts: 'Accounts',
      noc: 'NOC',
      engineer: 'Engineer',
    };
    return (
      <span className={`px-2 py-1 text-xs rounded-full border ${colors[role]}`}>
        {labels[role]}
      </span>
    );
  };

  const columns = [
    { key: 'name', label: 'Name' },
    { key: 'email', label: 'Email' },
    { 
      key: 'role', 
      label: 'Role',
      render: (item: User) => getRoleBadge(item.role)
    },
    { 
      key: 'branch_id', 
      label: 'Branch',
      render: (item: User) => {
        const branch = branches.find(b => b.id === item.branch_id);
        return branch?.name || '-';
      }
    },
    { key: 'phone', label: 'Phone', render: (item: User) => item.phone || '-' },
    {
      key: 'is_active',
      label: 'Status',
      render: (item: User) => (
        <span className={`px-2 py-1 text-xs rounded-full ${
          item.is_active 
            ? 'bg-green-500/20 text-green-400 border border-green-500/30' 
            : 'bg-red-500/20 text-red-400 border border-red-500/30'
        }`}>
          {item.is_active ? 'Active' : 'Inactive'}
        </span>
      )
    },
    {
      key: 'actions',
      label: 'Actions',
      render: (item: User) => (
        <div className="flex items-center gap-2">
          <button
            onClick={(e) => { e.stopPropagation(); handlePasswordReset(item); }}
            className="p-1.5 text-slate-400 hover:text-yellow-400 hover:bg-slate-700 rounded-lg transition-all"
            title="Reset Password"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
            </svg>
          </button>
          <button
            onClick={(e) => { e.stopPropagation(); handleEdit(item); }}
            className="p-1.5 text-slate-400 hover:text-cyan-400 hover:bg-slate-700 rounded-lg transition-all"
            title="Edit User"
          >
            <EditIcon size={16} />
          </button>
          <button
            onClick={(e) => { e.stopPropagation(); handleDelete(item.id); }}
            className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-slate-700 rounded-lg transition-all"
            title="Delete User"
            disabled={item.id === 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'}
          >
            <TrashIcon size={16} />
          </button>
        </div>
      )
    },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white">Users Management</h2>
          <p className="text-sm text-slate-400">Manage system users and their roles. Create users with username and password.</p>
        </div>
        <button
          onClick={() => { resetForm(); setEditingUser(null); setIsModalOpen(true); }}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium rounded-xl hover:from-cyan-600 hover:to-blue-700 transition-all"
        >
          <PlusIcon size={20} />
          Add User
        </button>
      </div>

      {/* Info Banner */}
      <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-xl p-4">
        <div className="flex items-start gap-3">
          <svg className="w-5 h-5 text-cyan-400 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <div>
            <p className="text-cyan-400 font-medium">User Authentication</p>
            <p className="text-slate-400 text-sm mt-1">
              When you create a new user, they will be able to login with their email and password. 
              You can reset passwords using the key icon in the actions column.
            </p>
          </div>
        </div>
      </div>

      <DataTable
        columns={columns}
        data={users}
        searchable
        searchPlaceholder="Search users..."
        emptyMessage="No users found"
      />

      {/* Create/Edit User Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => { setIsModalOpen(false); setEditingUser(null); resetForm(); }}
        title={editingUser ? 'Edit User' : 'Create New User'}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-sm">
              {error}
            </div>
          )}
          
          {success && (
            <div className="p-3 bg-green-500/10 border border-green-500/30 rounded-xl text-green-400 text-sm">
              {success}
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Full Name *</label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              placeholder="Enter full name"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Email Address *</label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              placeholder="user@example.com"
              required
            />
          </div>

          {!editingUser && (
            <>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Password *</label>
                <input
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  placeholder="Minimum 6 characters"
                  required={!editingUser}
                  minLength={6}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Confirm Password *</label>
                <input
                  type="password"
                  value={formData.confirmPassword}
                  onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                  className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  placeholder="Confirm password"
                  required={!editingUser}
                />
              </div>
            </>
          )}
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Role *</label>
            <select
              value={formData.role}
              onChange={(e) => setFormData({ ...formData, role: e.target.value as UserRole })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
            >
              <option value="admin">Admin</option>
              <option value="branch_sales">Branch Sales</option>
              <option value="inventory">Inventory</option>
              <option value="cashier">Cashier</option>
              <option value="accounts">Accounts</option>
              <option value="noc">NOC</option>
              <option value="engineer">Engineer</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Branch</label>
            <select
              value={formData.branch_id}
              onChange={(e) => setFormData({ ...formData, branch_id: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
            >
              <option value="">No Branch (HQ)</option>
              {branches.map((branch) => (
                <option key={branch.id} value={branch.id}>{branch.name}</option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Phone</label>
            <input
              type="tel"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              placeholder="+93 700 000 000"
            />
          </div>
          
          <div className="flex justify-end gap-3 pt-4">
            <button
              type="button"
              onClick={() => { setIsModalOpen(false); setEditingUser(null); resetForm(); }}
              className="px-4 py-2 text-slate-400 hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium rounded-xl hover:from-cyan-600 hover:to-blue-700 transition-all disabled:opacity-50"
            >
              {saving ? 'Saving...' : editingUser ? 'Update User' : 'Create User'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Reset Password Modal */}
      <Modal
        isOpen={isPasswordModalOpen}
        onClose={() => { setIsPasswordModalOpen(false); setSelectedUserForPassword(null); }}
        title="Reset Password"
      >
        <form onSubmit={handleResetPassword} className="space-y-4">
          {error && (
            <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-sm">
              {error}
            </div>
          )}
          
          {success && (
            <div className="p-3 bg-green-500/10 border border-green-500/30 rounded-xl text-green-400 text-sm">
              {success}
            </div>
          )}

          <div className="p-3 bg-slate-800 border border-slate-700 rounded-xl">
            <p className="text-sm text-slate-400">Resetting password for:</p>
            <p className="text-white font-medium">{selectedUserForPassword?.name}</p>
            <p className="text-slate-400 text-sm">{selectedUserForPassword?.email}</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">New Password *</label>
            <input
              type="password"
              value={passwordFormData.newPassword}
              onChange={(e) => setPasswordFormData({ ...passwordFormData, newPassword: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              placeholder="Minimum 6 characters"
              required
              minLength={6}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Confirm New Password *</label>
            <input
              type="password"
              value={passwordFormData.confirmPassword}
              onChange={(e) => setPasswordFormData({ ...passwordFormData, confirmPassword: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              placeholder="Confirm new password"
              required
            />
          </div>

          <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-xl p-3">
            <p className="text-yellow-400 text-sm">
              This will log out the user from all devices and require them to login with the new password.
            </p>
          </div>
          
          <div className="flex justify-end gap-3 pt-4">
            <button
              type="button"
              onClick={() => { setIsPasswordModalOpen(false); setSelectedUserForPassword(null); }}
              className="px-4 py-2 text-slate-400 hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-2 bg-gradient-to-r from-yellow-500 to-orange-600 text-white font-medium rounded-xl hover:from-yellow-600 hover:to-orange-700 transition-all disabled:opacity-50"
            >
              {saving ? 'Resetting...' : 'Reset Password'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default UsersView;
