import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { playSuccessChime, playTaskSound } from '@/lib/notifications';
import StatCard from '../StatCard';
import Modal from '../Modal';
import { UsersIcon, AlertIcon, TaskIcon, ClockIcon, CheckIcon, PlusIcon } from '../ui/Icons';

const NOCDashboard: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const [engineers, setEngineers] = useState<any[]>([]);
  const [presentToday, setPresentToday] = useState<any[]>([]);
  const [complaints, setComplaints] = useState<any[]>([]);
  const [tasks, setTasks] = useState<any[]>([]);
  const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);
  const [selectedComplaint, setSelectedComplaint] = useState<any>(null);
  const [assignForm, setAssignForm] = useState({ engineer_id: '', deadline_hours: '2', penalty_amount: '500' });

  const formatCurrency = (amount: number) => new Intl.NumberFormat('en-US').format(amount) + ' AFN';

  const fetchData = async () => {
    setLoading(true);
    try {
      const today = new Date().toISOString().split('T')[0];
      const { data: engineersData } = await supabase.from('users').select('*').eq('role', 'engineer').eq('is_active', true);
      setEngineers(engineersData || []);
      const { data: attendanceData } = await supabase.from('attendance').select('*, user:users(name)').eq('date', today);
      setPresentToday(attendanceData || []);
      const { data: complaintsData } = await supabase.from('complaints').select('*, assignee:users!complaints_assigned_to_fkey(name)').in('status', ['open', 'assigned', 'in_progress']).order('created_at', { ascending: false });
      setComplaints(complaintsData || []);
      const { data: tasksData } = await supabase.from('tasks').select('*, assignee:users!tasks_assigned_to_fkey(name)').in('status', ['pending', 'in_progress']).order('created_at', { ascending: false });
      setTasks(tasksData || []);
    } catch (error) { console.error('Error:', error); }
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
    const channel = supabase.channel('noc-updates')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'complaints' }, () => { fetchData(); playTaskSound(); })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'attendance' }, () => fetchData())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, []);

  const handleAssignComplaint = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedComplaint) return;
    try {
      await supabase.from('complaints').update({
        assigned_to: assignForm.engineer_id,
        deadline_hours: parseInt(assignForm.deadline_hours),
        penalty_amount: parseFloat(assignForm.penalty_amount),
        status: 'assigned'
      }).eq('id', selectedComplaint.id);
      await supabase.from('notifications').insert({
        user_id: assignForm.engineer_id,
        title: 'New Complaint Assigned',
        message: `Complaint ${selectedComplaint.complaint_number} assigned. Deadline: ${assignForm.deadline_hours} hours. Penalty if late: ${formatCurrency(parseFloat(assignForm.penalty_amount))}`,
        type: 'complaint',
      });
      playSuccessChime();
      setIsAssignModalOpen(false);
      setSelectedComplaint(null);
      fetchData();
    } catch (error) { console.error('Error:', error); }
  };

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-500"></div></div>;

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-orange-600/20 to-red-600/20 border border-orange-500/30 rounded-2xl p-6">
        <h2 className="text-2xl font-bold text-white">NOC Dashboard</h2>
        <p className="text-slate-400 mt-1">Monitor engineers, assign complaints with deadlines and penalties.</p>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Engineers Present" value={presentToday.length} subtitle={`of ${engineers.length} total`} icon={<UsersIcon size={24} />} color="green" />
        <StatCard title="Open Complaints" value={complaints.filter(c => c.status === 'open').length} subtitle="Unassigned" icon={<AlertIcon size={24} />} color={complaints.filter(c => c.status === 'open').length > 0 ? 'red' : 'green'} />
        <StatCard title="In Progress" value={complaints.filter(c => c.status === 'in_progress').length} subtitle="Being resolved" icon={<TaskIcon size={24} />} color="yellow" />
        <StatCard title="Pending Tasks" value={tasks.filter(t => t.status === 'pending').length} subtitle="Awaiting action" icon={<ClockIcon size={24} />} color="purple" />
      </div>
      <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-4">
        <h3 className="font-semibold text-white mb-4">Engineers Attendance Today</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {engineers.map(eng => {
            const isPresent = presentToday.some(a => a.user_id === eng.id);
            return (
              <div key={eng.id} className={`p-3 rounded-xl border ${isPresent ? 'bg-green-500/10 border-green-500/30' : 'bg-red-500/10 border-red-500/30'}`}>
                <p className="font-medium text-white">{eng.name}</p>
                <p className="text-xs text-slate-400">{eng.area || 'No area'}</p>
                <span className={`text-xs ${isPresent ? 'text-green-400' : 'text-red-400'}`}>{isPresent ? 'Present' : 'Absent'}</span>
              </div>
            );
          })}
        </div>
      </div>
      {complaints.filter(c => c.status === 'open').length > 0 && (
        <div className="bg-red-500/10 border border-red-500/30 rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-red-500/30"><h3 className="font-semibold text-red-400">Open Complaints - Assign to Engineer</h3></div>
          <div className="divide-y divide-red-500/20">
            {complaints.filter(c => c.status === 'open').map(complaint => (
              <div key={complaint.id} className="p-4 flex items-center justify-between">
                <div>
                  <p className="font-medium text-white">{complaint.complaint_number}</p>
                  <p className="text-sm text-slate-400">{complaint.customer_name} - {complaint.category}</p>
                  <p className="text-xs text-slate-500">{complaint.description?.substring(0, 50)}...</p>
                </div>
                <button onClick={() => { setSelectedComplaint(complaint); setIsAssignModalOpen(true); }} className="px-4 py-2 bg-orange-600 text-white text-sm font-medium rounded-lg hover:bg-orange-700">Assign</button>
              </div>
            ))}
          </div>
        </div>
      )}
      <div className="bg-slate-800/50 border border-slate-700 rounded-2xl overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-700"><h3 className="font-semibold text-white">Active Complaints & Tasks</h3></div>
        <div className="divide-y divide-slate-700/50">
          {[...complaints.filter(c => c.status !== 'open'), ...tasks].slice(0, 10).map((item, idx) => (
            <div key={idx} className="p-4 flex items-center justify-between">
              <div>
                <p className="font-medium text-white">{item.complaint_number || item.task_number}</p>
                <p className="text-sm text-slate-400">Assigned to: {item.assignee?.name || 'Unassigned'}</p>
              </div>
              <span className={`px-2 py-1 text-xs rounded-full ${item.status === 'in_progress' ? 'bg-blue-500/20 text-blue-400' : 'bg-yellow-500/20 text-yellow-400'}`}>{item.status}</span>
            </div>
          ))}
        </div>
      </div>
      <Modal isOpen={isAssignModalOpen} onClose={() => setIsAssignModalOpen(false)} title="Assign Complaint">
        <form onSubmit={handleAssignComplaint} className="space-y-4">
          {selectedComplaint && <div className="bg-slate-800 border border-slate-700 rounded-xl p-4"><p className="text-white font-medium">{selectedComplaint.complaint_number}</p><p className="text-slate-400 text-sm">{selectedComplaint.customer_name} - {selectedComplaint.category}</p></div>}
          <div><label className="block text-sm font-medium text-slate-300 mb-2">Engineer *</label><select value={assignForm.engineer_id} onChange={(e) => setAssignForm({ ...assignForm, engineer_id: e.target.value })} className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white" required><option value="">Select Engineer</option>{presentToday.map(a => <option key={a.user_id} value={a.user_id}>{a.user?.name}</option>)}</select></div>
          <div className="grid grid-cols-2 gap-4">
            <div><label className="block text-sm font-medium text-slate-300 mb-2">Deadline (hours) *</label><input type="number" value={assignForm.deadline_hours} onChange={(e) => setAssignForm({ ...assignForm, deadline_hours: e.target.value })} className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white" required min="1" /></div>
            <div><label className="block text-sm font-medium text-slate-300 mb-2">Penalty (AFN) *</label><input type="number" value={assignForm.penalty_amount} onChange={(e) => setAssignForm({ ...assignForm, penalty_amount: e.target.value })} className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white" required min="0" /></div>
          </div>
          <div className="flex justify-end gap-3 pt-4"><button type="button" onClick={() => setIsAssignModalOpen(false)} className="px-4 py-2 text-slate-400">Cancel</button><button type="submit" className="px-6 py-2 bg-orange-600 text-white font-medium rounded-xl hover:bg-orange-700">Assign</button></div>
        </form>
      </Modal>
    </div>
  );
};

export default NOCDashboard;
