import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Complaint, User, Branch } from '@/types';
import DataTable from '../DataTable';
import Modal from '../Modal';
import StatCard from '../StatCard';
import { PlusIcon, ComplaintIcon, CheckIcon, AlertIcon } from '../ui/Icons';

const ComplaintsView: React.FC = () => {
  const { currentUser } = useAuth();
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [engineers, setEngineers] = useState<User[]>([]);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    customer_name: '',
    customer_phone: '',
    branch_id: '',
    category: 'Connectivity',
    description: '',
    priority: 'normal',
    assigned_to: '',
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [complaintsRes, engineersRes, branchesRes] = await Promise.all([
        supabase.from('complaints').select('*').order('created_at', { ascending: false }),
        supabase.from('users').select('*').eq('role', 'engineer'),
        supabase.from('branches').select('*'),
      ]);

      setComplaints(complaintsRes.data || []);
      setEngineers(engineersRes.data || []);
      setBranches(branchesRes.data || []);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await supabase.from('complaints').insert({
        complaint_number: `CMP-${Date.now()}`,
        customer_name: formData.customer_name,
        customer_phone: formData.customer_phone,
        branch_id: formData.branch_id,
        category: formData.category,
        description: formData.description,
        priority: formData.priority,
        assigned_to: formData.assigned_to || null,
        status: formData.assigned_to ? 'assigned' : 'open',
        created_by: currentUser?.id,
      });

      // Create task if engineer assigned
      if (formData.assigned_to) {
        await supabase.from('tasks').insert({
          task_number: `TSK-${Date.now()}`,
          task_type: 'complaint',
          title: `Complaint: ${formData.category} - ${formData.customer_name}`,
          description: formData.description,
          branch_id: formData.branch_id,
          assigned_to: formData.assigned_to,
          assigned_by: currentUser?.id,
          status: 'pending',
          priority: formData.priority,
        });
      }

      setIsModalOpen(false);
      resetForm();
      fetchData();
    } catch (error) {
      console.error('Error creating complaint:', error);
    }
  };

  const handleStatusChange = async (complaint: Complaint, newStatus: string) => {
    try {
      const updateData: any = { status: newStatus };
      if (newStatus === 'resolved' || newStatus === 'closed') {
        updateData.resolved_at = new Date().toISOString();
      }
      
      await supabase.from('complaints').update(updateData).eq('id', complaint.id);
      fetchData();
    } catch (error) {
      console.error('Error updating complaint:', error);
    }
  };

  const handleAssign = async (complaint: Complaint, engineerId: string) => {
    try {
      await supabase
        .from('complaints')
        .update({ assigned_to: engineerId, status: 'assigned' })
        .eq('id', complaint.id);

      // Create task
      await supabase.from('tasks').insert({
        task_number: `TSK-${Date.now()}`,
        task_type: 'complaint',
        title: `Complaint: ${complaint.category} - ${complaint.customer_name}`,
        description: complaint.description,
        branch_id: complaint.branch_id,
        assigned_to: engineerId,
        assigned_by: currentUser?.id,
        status: 'pending',
        priority: complaint.priority,
      });

      fetchData();
    } catch (error) {
      console.error('Error assigning complaint:', error);
    }
  };

  const resetForm = () => {
    setFormData({
      customer_name: '',
      customer_phone: '',
      branch_id: '',
      category: 'Connectivity',
      description: '',
      priority: 'normal',
      assigned_to: '',
    });
  };

  const getEngineerName = (id: string) => engineers.find(e => e.id === id)?.name || 'Unassigned';
  const getBranchName = (id: string) => branches.find(b => b.id === id)?.name || '-';

  const openComplaints = complaints.filter(c => c.status === 'open');
  const assignedComplaints = complaints.filter(c => c.status === 'assigned' || c.status === 'in_progress');
  const resolvedComplaints = complaints.filter(c => c.status === 'resolved' || c.status === 'closed');

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      open: 'bg-red-500/20 text-red-400 border-red-500/30',
      assigned: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
      in_progress: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
      resolved: 'bg-green-500/20 text-green-400 border-green-500/30',
      closed: 'bg-slate-500/20 text-slate-400 border-slate-500/30',
    };
    return colors[status] || colors.open;
  };

  const getPriorityColor = (priority: string) => {
    const colors: Record<string, string> = {
      low: 'text-slate-400',
      normal: 'text-blue-400',
      high: 'text-orange-400',
      urgent: 'text-red-400',
    };
    return colors[priority] || colors.normal;
  };

  const columns = [
    { key: 'complaint_number', label: 'Complaint #' },
    { key: 'customer_name', label: 'Customer' },
    { key: 'category', label: 'Category' },
    { 
      key: 'priority', 
      label: 'Priority',
      render: (item: Complaint) => (
        <span className={`capitalize font-medium ${getPriorityColor(item.priority)}`}>
          {item.priority}
        </span>
      )
    },
    { 
      key: 'assigned_to', 
      label: 'Assigned To',
      render: (item: Complaint) => item.assigned_to ? getEngineerName(item.assigned_to) : (
        <select
          onClick={(e) => e.stopPropagation()}
          onChange={(e) => handleAssign(item, e.target.value)}
          className="bg-slate-800 border border-slate-700 rounded-lg px-2 py-1 text-xs text-white"
        >
          <option value="">Assign...</option>
          {engineers.map(eng => (
            <option key={eng.id} value={eng.id}>{eng.name}</option>
          ))}
        </select>
      )
    },
    { 
      key: 'status', 
      label: 'Status',
      render: (item: Complaint) => (
        <span className={`px-2 py-1 text-xs rounded-full border ${getStatusColor(item.status)}`}>
          {item.status.replace('_', ' ')}
        </span>
      )
    },
    {
      key: 'actions',
      label: 'Actions',
      render: (item: Complaint) => (
        <div className="flex items-center gap-2">
          {item.status === 'in_progress' && (
            <button
              onClick={(e) => { e.stopPropagation(); handleStatusChange(item, 'resolved'); }}
              className="px-2 py-1 text-xs bg-green-500/20 text-green-400 rounded-lg hover:bg-green-500/30 transition-all"
            >
              Resolve
            </button>
          )}
          {item.status === 'resolved' && (
            <button
              onClick={(e) => { e.stopPropagation(); handleStatusChange(item, 'closed'); }}
              className="px-2 py-1 text-xs bg-slate-500/20 text-slate-400 rounded-lg hover:bg-slate-500/30 transition-all"
            >
              Close
            </button>
          )}
        </div>
      )
    },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <StatCard
          title="Total Complaints"
          value={complaints.length}
          icon={<ComplaintIcon size={24} />}
          color="cyan"
        />
        <StatCard
          title="Open"
          value={openComplaints.length}
          icon={<AlertIcon size={24} />}
          color="red"
        />
        <StatCard
          title="In Progress"
          value={assignedComplaints.length}
          icon={<ComplaintIcon size={24} />}
          color="yellow"
        />
        <StatCard
          title="Resolved"
          value={resolvedComplaints.length}
          icon={<CheckIcon size={24} />}
          color="green"
        />
      </div>

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white">Complaints</h2>
          <p className="text-sm text-slate-400">Manage customer complaints and issues</p>
        </div>
        <button
          onClick={() => { resetForm(); setIsModalOpen(true); }}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium rounded-xl hover:from-cyan-600 hover:to-blue-700 transition-all"
        >
          <PlusIcon size={20} />
          New Complaint
        </button>
      </div>

      {/* Open Complaints Alert */}
      {openComplaints.length > 0 && (
        <div className="bg-red-500/10 border border-red-500/30 rounded-2xl p-4">
          <div className="flex items-center gap-3 mb-3">
            <AlertIcon size={24} className="text-red-400" />
            <h3 className="font-medium text-red-400">{openComplaints.length} Open Complaints Need Attention</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {openComplaints.slice(0, 3).map(complaint => (
              <div key={complaint.id} className="bg-slate-900 border border-slate-700 rounded-xl p-3">
                <div className="flex items-start justify-between mb-2">
                  <span className="text-xs text-slate-500">{complaint.complaint_number}</span>
                  <span className={`text-xs font-medium ${getPriorityColor(complaint.priority)}`}>
                    {complaint.priority}
                  </span>
                </div>
                <p className="text-sm text-white font-medium mb-1">{complaint.customer_name}</p>
                <p className="text-xs text-slate-400 mb-2">{complaint.category}</p>
                <select
                  onChange={(e) => handleAssign(complaint, e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2 py-1.5 text-xs text-white"
                >
                  <option value="">Assign Engineer...</option>
                  {engineers.map(eng => (
                    <option key={eng.id} value={eng.id}>{eng.name}</option>
                  ))}
                </select>
              </div>
            ))}
          </div>
        </div>
      )}

      <DataTable
        columns={columns}
        data={complaints}
        searchable
        searchPlaceholder="Search complaints..."
        emptyMessage="No complaints found"
      />

      {/* New Complaint Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Create New Complaint"
        size="lg"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Customer Name *</label>
              <input
                type="text"
                value={formData.customer_name}
                onChange={(e) => setFormData({ ...formData, customer_name: e.target.value })}
                className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Phone</label>
              <input
                type="tel"
                value={formData.customer_phone}
                onChange={(e) => setFormData({ ...formData, customer_phone: e.target.value })}
                className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Category</label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              >
                <option value="Connectivity">Connectivity</option>
                <option value="Speed">Speed Issues</option>
                <option value="Billing">Billing</option>
                <option value="Equipment">Equipment</option>
                <option value="Other">Other</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Priority</label>
              <select
                value={formData.priority}
                onChange={(e) => setFormData({ ...formData, priority: e.target.value })}
                className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              >
                <option value="low">Low</option>
                <option value="normal">Normal</option>
                <option value="high">High</option>
                <option value="urgent">Urgent</option>
              </select>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Branch</label>
            <select
              value={formData.branch_id}
              onChange={(e) => setFormData({ ...formData, branch_id: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              required
            >
              <option value="">Select Branch</option>
              {branches.map((branch) => (
                <option key={branch.id} value={branch.id}>{branch.name}</option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Description *</label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
              rows={3}
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Assign Engineer (Optional)</label>
            <select
              value={formData.assigned_to}
              onChange={(e) => setFormData({ ...formData, assigned_to: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
            >
              <option value="">Assign Later</option>
              {engineers.map((eng) => (
                <option key={eng.id} value={eng.id}>{eng.name}</option>
              ))}
            </select>
          </div>
          
          <div className="flex justify-end gap-3 pt-4">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 text-slate-400 hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium rounded-xl hover:from-cyan-600 hover:to-blue-700 transition-all"
            >
              Create Complaint
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default ComplaintsView;
