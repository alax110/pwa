import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { usePWA } from '@/hooks/usePWA';
import { MenuIcon, SearchIcon, RefreshIcon } from './ui/Icons';

interface HeaderProps {
  title: string;
  onMenuClick: () => void;
  onRefresh?: () => void;
}

const Header: React.FC<HeaderProps> = ({ title, onMenuClick, onRefresh }) => {
  const { currentUser } = useAuth();
  const { 
    isInstallable, 
    isInstalled, 
    installApp, 
    isPushSupported,
    isPushSubscribed,
    notificationPermission,
    subscribeToPush,
    unsubscribeFromPush,
    showNotification
  } = usePWA();
  
  const [showNotifDropdown, setShowNotifDropdown] = useState(false);
  const [installing, setInstalling] = useState(false);

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  };

  const handleInstall = async () => {
    setInstalling(true);
    const success = await installApp();
    setInstalling(false);
    if (success) {
      showNotification('Work.PWA Installed!', {
        body: 'You can now access Work.PWA from your home screen.',
      });
    }
  };

  const handleToggleNotifications = async () => {
    if (isPushSubscribed) {
      await unsubscribeFromPush();
      showNotification('Notifications Disabled', {
        body: 'You will no longer receive push notifications.',
      });
    } else {
      const subscription = await subscribeToPush();
      if (subscription) {
        showNotification('Notifications Enabled!', {
          body: 'You will now receive important updates.',
        });
      }
    }
    setShowNotifDropdown(false);
  };

  const handleTestNotification = async () => {
    await showNotification('Test Notification', {
      body: 'Push notifications are working correctly!',
      tag: 'test',
    });
    setShowNotifDropdown(false);
  };

  return (
    <header className="bg-slate-900 border-b border-slate-800 px-4 lg:px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button
            onClick={onMenuClick}
            className="lg:hidden p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-all"
          >
            <MenuIcon size={24} />
          </button>
          
          <div>
            <h1 className="text-xl font-bold text-white">{title}</h1>
            <p className="text-sm text-slate-500">
              {getGreeting()}, {currentUser?.name ? currentUser.name.split(' ')[0] : 'User'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Install App Button */}
          {isInstallable && !isInstalled && (
            <button
              onClick={handleInstall}
              disabled={installing}
              className="flex items-center gap-2 px-3 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-sm font-medium rounded-xl hover:from-cyan-600 hover:to-blue-700 transition-all disabled:opacity-50"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
              </svg>
              <span className="hidden sm:inline">{installing ? 'Installing...' : 'Install App'}</span>
            </button>
          )}

          {/* Installed Badge */}
          {isInstalled && (
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-green-500/20 text-green-400 text-sm rounded-xl border border-green-500/30">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <span className="hidden sm:inline">Installed</span>
            </div>
          )}

          {/* Notifications Button */}
          {isPushSupported && (
            <div className="relative">
              <button
                onClick={() => setShowNotifDropdown(!showNotifDropdown)}
                className={`p-2 rounded-xl transition-all ${
                  isPushSubscribed 
                    ? 'text-cyan-400 bg-cyan-500/20 hover:bg-cyan-500/30' 
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                </svg>
                {isPushSubscribed && (
                  <span className="absolute top-1 right-1 w-2 h-2 bg-cyan-400 rounded-full"></span>
                )}
              </button>

              {/* Notification Dropdown */}
              {showNotifDropdown && (
                <div className="absolute right-0 mt-2 w-64 bg-slate-800 border border-slate-700 rounded-xl shadow-xl z-50 overflow-hidden">
                  <div className="p-3 border-b border-slate-700">
                    <h4 className="font-medium text-white">Push Notifications</h4>
                    <p className="text-xs text-slate-400 mt-1">
                      {notificationPermission === 'granted' 
                        ? 'Notifications are enabled' 
                        : notificationPermission === 'denied'
                        ? 'Notifications are blocked'
                        : 'Enable to receive updates'}
                    </p>
                  </div>
                  <div className="p-2">
                    <button
                      onClick={handleToggleNotifications}
                      className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-all ${
                        isPushSubscribed 
                          ? 'text-red-400 hover:bg-red-500/10' 
                          : 'text-cyan-400 hover:bg-cyan-500/10'
                      }`}
                    >
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        {isPushSubscribed ? (
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9M3 3l18 18" />
                        ) : (
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                        )}
                      </svg>
                      <span>{isPushSubscribed ? 'Disable Notifications' : 'Enable Notifications'}</span>
                    </button>
                    
                    {isPushSubscribed && (
                      <button
                        onClick={handleTestNotification}
                        className="w-full flex items-center gap-3 px-3 py-2 text-slate-300 hover:bg-slate-700 rounded-lg transition-all"
                      >
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                        </svg>
                        <span>Test Notification</span>
                      </button>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Search */}
          <div className="hidden md:flex items-center gap-2 px-4 py-2 bg-slate-800 rounded-xl border border-slate-700">
            <SearchIcon size={18} className="text-slate-500" />
            <input
              type="text"
              placeholder="Search..."
              className="bg-transparent text-sm text-white placeholder-slate-500 focus:outline-none w-48"
            />
          </div>

          {/* Refresh */}
          {onRefresh && (
            <button
              onClick={onRefresh}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-all"
            >
              <RefreshIcon size={20} />
            </button>
          )}

          {/* Date/Time */}
          <div className="hidden lg:block text-right">
            <p className="text-sm font-medium text-white">
              {new Date().toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
            </p>
            <p className="text-xs text-slate-500">
              {new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
            </p>
          </div>
        </div>
      </div>

      {/* Click outside to close dropdown */}
      {showNotifDropdown && (
        <div 
          className="fixed inset-0 z-40" 
          onClick={() => setShowNotifDropdown(false)}
        />
      )}
    </header>
  );
};

export default Header;
